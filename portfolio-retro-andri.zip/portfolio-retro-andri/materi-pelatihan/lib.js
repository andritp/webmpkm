'use strict';

const {
  AlignmentType, BorderStyle, Footer, LevelFormat, PageNumber, Paragraph, ShadingType,
  Table, TableCell, TableRow, TextRun, WidthType, HeadingLevel, PageBreak,
} = require('docx');

const COLORS = { navy: '141D5C', navyMid: '22307F', gold: 'C8961A', goldSoft: 'FFF4D1', blueSoft: 'EEF2FF', greenSoft: 'E3F6EA', redSoft: 'FDECEC', muted: '5B6185', line: 'D7DBEA' };
const FONT = 'Calibri';

const STYLES = {
  default: { document: { run: { font: FONT, size: 22, color: '1B1F3B' }, paragraph: { spacing: { after: 100, line: 264 } } } },
  paragraphStyles: [
    { id: 'Heading1', name: 'Heading 1', basedOn: 'Normal', next: 'Normal', quickFormat: true,
      run: { size: 34, bold: true, color: COLORS.navy, font: FONT }, paragraph: { spacing: { before: 0, after: 140 }, outlineLevel: 0 } },
    { id: 'Heading2', name: 'Heading 2', basedOn: 'Normal', next: 'Normal', quickFormat: true,
      run: { size: 26, bold: true, color: COLORS.navyMid, font: FONT }, paragraph: { spacing: { before: 180, after: 80 }, outlineLevel: 1 } },
  ],
};

const NUMBERING = {
  config: [
    { reference: 'bullets', levels: [{ level: 0, format: LevelFormat.BULLET, text: '•', alignment: AlignmentType.LEFT,
      style: { paragraph: { indent: { left: 440, hanging: 260 } } } }] },
    ...Array.from({ length: 12 }, (_, index) => ({
      reference: `steps${index}`,
      levels: [{ level: 0, format: LevelFormat.DECIMAL, text: '%1.', alignment: AlignmentType.LEFT,
        style: { paragraph: { indent: { left: 440, hanging: 300 } }, run: { bold: true, color: COLORS.navyMid } } }],
    })),
  ],
};

/** Parses **bold** markers into runs so content can be written as plain strings. */
function runs(text, base = {}) {
  return String(text).split(/(\*\*[^*]+\*\*)/).filter(Boolean).map((part) => (
    part.startsWith('**') ? new TextRun({ ...base, text: part.slice(2, -2), bold: true }) : new TextRun({ ...base, text: part })
  ));
}

const h1 = (text, options = {}) => new Paragraph({ heading: HeadingLevel.HEADING_1, pageBreakBefore: Boolean(options.newPage), keepNext: true, children: [new TextRun(text)] });
const h2 = (text) => new Paragraph({ heading: HeadingLevel.HEADING_2, keepNext: true, children: [new TextRun(text)] });
const p = (text, options = {}) => new Paragraph({ ...options, children: runs(text, options.run) });
const muted = (text) => p(text, { run: { color: COLORS.muted, italics: true, size: 20 } });
const bullet = (text) => new Paragraph({ numbering: { reference: 'bullets', level: 0 }, children: runs(text) });
const bullets = (items) => items.map(bullet);
let stepListCounter = 0;
/** Each call starts a fresh 1., 2., 3. sequence. */
function steps(items) {
  const reference = `steps${stepListCounter++ % 12}`;
  return items.map((text) => new Paragraph({ numbering: { reference, level: 0 }, children: runs(text) }));
}
const pageBreak = () => new Paragraph({ children: [new PageBreak()] });
const spacer = (after = 120) => new Paragraph({ spacing: { after }, children: [] });
const rule = () => new Paragraph({ border: { bottom: { style: BorderStyle.SINGLE, size: 8, color: COLORS.gold, space: 4 } }, spacing: { after: 160 }, children: [] });

const cellBorders = { top: { style: BorderStyle.SINGLE, size: 4, color: COLORS.line }, bottom: { style: BorderStyle.SINGLE, size: 4, color: COLORS.line },
  left: { style: BorderStyle.SINGLE, size: 4, color: COLORS.line }, right: { style: BorderStyle.SINGLE, size: 4, color: COLORS.line } };

/** Shaded single-cell box for tips, examples and warnings. */
function box(title, lines, { fill = COLORS.blueSoft, width = 9000, accent = COLORS.navyMid } = {}) {
  const children = [];
  if (title) children.push(new Paragraph({ spacing: { after: 60 }, children: [new TextRun({ text: title, bold: true, color: accent })] }));
  lines.forEach((line) => children.push(typeof line === 'string' ? new Paragraph({ spacing: { after: 40 }, children: runs(line) }) : line));
  return new Table({
    width: { size: width, type: WidthType.DXA }, columnWidths: [width],
    // cantSplit keeps a whole tip/example box on one page instead of breaking it mid-way.
    rows: [new TableRow({ cantSplit: true, children: [new TableCell({
      width: { size: width, type: WidthType.DXA }, shading: { fill, type: ShadingType.CLEAR, color: 'auto' },
      borders: { ...cellBorders, left: { style: BorderStyle.SINGLE, size: 24, color: accent } },
      margins: { top: 120, bottom: 120, left: 200, right: 200 }, children,
    })] })],
  });
}

/** Simple grid table; first row is the header. */
function grid(rows, columnWidths, { headerFill = COLORS.navy } = {}) {
  const total = columnWidths.reduce((sum, value) => sum + value, 0);
  return new Table({
    width: { size: total, type: WidthType.DXA }, columnWidths,
    rows: rows.map((cells, rowIndex) => new TableRow({ tableHeader: rowIndex === 0, cantSplit: true, children: cells.map((text, cellIndex) => new TableCell({
      width: { size: columnWidths[cellIndex], type: WidthType.DXA }, borders: cellBorders,
      shading: rowIndex === 0 ? { fill: headerFill, type: ShadingType.CLEAR, color: 'auto' } : (rowIndex % 2 === 0 ? { fill: 'F6F7FB', type: ShadingType.CLEAR, color: 'auto' } : undefined),
      margins: { top: 60, bottom: 60, left: 120, right: 120 },
      children: [new Paragraph({ spacing: { after: 0 }, children: runs(text, rowIndex === 0 ? { bold: true, color: 'FFFFFF' } : {}) })],
    })) })),
  });
}

function footer(label) {
  return new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [
    new TextRun({ text: `${label}  ·  Kelompok 1 MK-PM Universitas Terbuka × AYTINDESO  ·  Hal. `, size: 16, color: COLORS.muted }),
    new TextRun({ children: [PageNumber.CURRENT], size: 16, color: COLORS.muted }),
  ] })] });
}

const fs = require('fs');
const path = require('path');
const { ImageRun } = require('docx');

/** "UT × AYTINDESO" logo row; the dark AYTINDESO badge keeps its white lettering readable on white paper. */
function logoRow(scale = 1) {
  const image = (file, width, height) => new ImageRun({
    type: 'png', data: fs.readFileSync(path.join(__dirname, 'assets', file)),
    transformation: { width: Math.round(width * scale), height: Math.round(height * scale) },
  });
  return new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 200 }, children: [
    image('logo-ut.png', 100, 80),
    new TextRun({ text: '   ×   ', bold: true, color: COLORS.gold, size: Math.round(36 * scale) }),
    image('logo-aytindeso.png', 190, 52),
  ] });
}

/** Cover block: logos, kicker, big title, subtitle, and program line. */
function cover(kicker, title, subtitle) {
  return [
    spacer(900),
    logoRow(),
    spacer(500),
    new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 120 }, children: [new TextRun({ text: kicker.toUpperCase(), bold: true, color: COLORS.gold, size: 22, characterSpacing: 60 })] }),
    new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 200 }, children: [new TextRun({ text: title, bold: true, color: COLORS.navy, size: 56 })] }),
    new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 600 }, children: [new TextRun({ text: subtitle, color: COLORS.muted, size: 26, italics: true })] }),
    new Paragraph({ alignment: AlignmentType.CENTER, border: { top: { style: BorderStyle.SINGLE, size: 8, color: COLORS.gold, space: 8 } }, spacing: { before: 400, after: 60 },
      children: [new TextRun({ text: 'Program Pelatihan Kesiapan Kerja bagi Pemuda Karang Taruna', bold: true, color: COLORS.navyMid })] }),
    new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: 'Kecamatan Jatisampurna, Kota Bekasi · Kelompok 1 MK-PM Universitas Terbuka · 2026', color: COLORS.muted, size: 20 })] }),
    pageBreak(),
  ];
}

module.exports = { COLORS, STYLES, NUMBERING, runs, h1, h2, p, muted, bullet, bullets, steps, pageBreak, spacer, rule, box, grid, footer, cover, logoRow };
