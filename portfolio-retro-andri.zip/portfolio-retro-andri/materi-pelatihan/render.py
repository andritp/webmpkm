"""Renders every page of a PDF to PNG thumbnails for visual review."""
import sys
import pymupdf

pdf_path = sys.argv[1]
prefix = sys.argv[2]
zoom = float(sys.argv[3]) if len(sys.argv) > 3 else 0.9
doc = pymupdf.open(pdf_path)
for index, page in enumerate(doc, start=1):
    page.get_pixmap(matrix=pymupdf.Matrix(zoom, zoom)).save(f"{prefix}-{index}.png")
print(f"{pdf_path}: {len(doc)} pages")
