'use strict';

const fs = require('fs');
const { Document, Packer, Paragraph, TextRun, AlignmentType, BorderStyle, TabStopType, Footer } = require('docx');
// Template and example pages carry no footer, so the participant's own CV stays clean.
const NO_FOOTER = { default: new Footer({ children: [] }) };
const { COLORS, STYLES, NUMBERING, h1, h2, p, muted, bullets, steps, pageBreak, spacer, box, grid, footer, cover } = require('./lib');

const A4 = { width: 11906, height: 16838 };
const MARGIN = { top: 1134, bottom: 1134, left: 1134, right: 1134 };

/** CV section title with a thin rule underneath (ATS-friendly: plain text, no tables). */
const cvSection = (title) => new Paragraph({
  spacing: { before: 220, after: 100 },
  border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: COLORS.navy, space: 2 } },
  children: [new TextRun({ text: title.toUpperCase(), bold: true, color: COLORS.navy, size: 22, characterSpacing: 20 })],
});
/** Role line: bold title on the left, period aligned right. */
const roleLine = (left, right) => new Paragraph({
  spacing: { after: 20 }, tabStops: [{ type: TabStopType.RIGHT, position: 9638 }],
  children: [new TextRun({ text: left, bold: true }), new TextRun({ text: `\t${right}`, color: COLORS.muted })],
});
const placeLine = (text) => new Paragraph({ spacing: { after: 60 }, children: [new TextRun({ text, italics: true, color: COLORS.muted })] });

function cvPage({ name, contact, summary, education, experience, skills, certificates, languages }) {
  return [
    new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 40 }, children: [new TextRun({ text: name, bold: true, size: 40, color: COLORS.navy })] }),
    new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 120 }, children: [new TextRun({ text: contact, size: 20, color: COLORS.muted })] }),
    cvSection('Ringkasan Profil'), p(summary),
    cvSection('Pendidikan'), ...education.flatMap((item) => [roleLine(item.title, item.period), placeLine(item.place), ...(item.notes ? bullets(item.notes) : [])]),
    cvSection('Pengalaman'), ...experience.flatMap((item) => [roleLine(item.title, item.period), placeLine(item.place), ...bullets(item.points)]),
    cvSection('Keterampilan'), ...bullets(skills),
    cvSection('Sertifikat & Pelatihan'), ...bullets(certificates),
    cvSection('Bahasa'), p(languages),
  ];
}

const guide = [
  h1('Panduan Mengisi Template CV'),
  p('CV (Curriculum Vitae) adalah **ringkasan diri kamu dalam 1 halaman**: siapa kamu, apa yang sudah kamu pelajari, dan apa yang bisa kamu kerjakan. Rekruter biasanya hanya membaca CV sekitar **6–10 detik** pada pandangan pertama, jadi CV harus rapi, jelas, dan langsung ke inti.'),
  h2('Cara memakai template ini'),
  ...steps([
    'Simpan dulu file ini dengan nama baru, misalnya **CV_Nama Lengkap.docx**.',
    'Buka halaman **"Template CV"** (setelah halaman panduan). Ganti semua teks dalam tanda **[kurung siku]** dengan data kamu, lalu hapus tanda kurungnya.',
    'Hapus bagian yang memang belum kamu punya (misalnya Sertifikat), jangan diisi asal-asalan.',
    'Lihat **"Contoh CV"** (halaman terakhir) sebagai gambaran CV yang sudah jadi.',
    'Hapus halaman panduan dan contoh sebelum dikirim, sisakan 1 halaman CV milikmu.',
    'Simpan sebagai **PDF**: File → Save As / Simpan Sebagai → pilih format PDF. Kirim versi PDF, bukan Word.',
  ]),
  h2('6 bagian wajib dalam CV'),
  grid([
    ['Bagian', 'Isi', 'Contoh singkat'],
    ['Data diri', 'Nama, kota domisili, nomor WhatsApp aktif, email profesional, link LinkedIn', 'Bekasi · 0812-xxxx-xxxx · rizky.pratama@gmail.com'],
    ['Ringkasan profil', '2–3 kalimat: siapa kamu, keahlian utama, posisi yang dituju', 'Lulusan SMK TKJ yang teliti dan siap bekerja di bidang IT support.'],
    ['Pendidikan', 'Sekolah/kampus terakhir, jurusan, tahun, nilai bila bagus', 'SMK Negeri 1 Bekasi — TKJ (2021–2024)'],
    ['Pengalaman', 'Kerja, magang/PKL, organisasi (Karang Taruna termasuk!), kepanitiaan', 'Sie Acara HUT RI Karang Taruna'],
    ['Keterampilan', 'Hard skill (teknis) + soft skill yang relevan', 'Microsoft Excel, komunikasi, kerja tim'],
    ['Sertifikat', 'Pelatihan, kursus online, sertifikasi', 'Pelatihan Kesiapan Kerja — UT (2026)'],
  ], [1900, 3900, 3838]),
  spacer(),
  box('Tips agar CV dilirik rekruter', [
    'Cukup **1 halaman**. Font **Calibri/Arial ukuran 10–12**, rata kiri, banyak ruang kosong.',
    'Tulis pengalaman dari yang **terbaru** dan mulai dengan **kata kerja + hasil**: "Mengatur 50 peserta lomba 17 Agustus", bukan "Bertugas di acara".',
    'Belum punya pengalaman kerja? Isi dengan **PKL, organisasi, kepanitiaan, usaha kecil, atau proyek sekolah**.',
    'Pakai **email profesional** (nama.anda@gmail.com). Hindari email seperti cowokkeren99@gmail.com.',
    'Foto **tidak wajib**. Kalau diminta, pakai foto formal, latar polos, berpakaian rapi.',
  ], { fill: COLORS.goldSoft, accent: COLORS.gold }),
  spacer(),
  h2('Kesalahan yang sering terjadi'),
  grid([
    ['Hindari', 'Lebih baik'],
    ['CV 3–4 halaman berisi semua hal', '1 halaman, hanya yang relevan dengan posisi'],
    ['Data pribadi berlebihan: agama, berat badan, nama orang tua', 'Cukup nama, domisili, kontak, LinkedIn'],
    ['Salah ketik nama perusahaan atau typo', 'Baca ulang 2 kali, minta teman mengecek'],
    ['Mengirim file Word dengan nama "CV baru final2.docx"', 'Kirim PDF dengan nama "CV_Rizky Pratama.pdf"'],
    ['Desain penuh warna dan tabel rumit', 'Desain sederhana agar terbaca sistem rekrutmen (ATS)'],
  ], [4819, 4819], { headerFill: COLORS.navyMid }),
];

const blankCv = cvPage({
  name: '[NAMA LENGKAP]',
  contact: '[Kota Domisili] · [Nomor WhatsApp] · [email@gmail.com] · [linkedin.com/in/nama-kamu]',
  summary: '[Tulis 2–3 kalimat: latar belakang pendidikan, 2–3 keahlian utama, dan posisi/bidang kerja yang kamu tuju.]',
  education: [{ title: '[Jurusan / Program Studi]', period: '[Tahun Masuk – Tahun Lulus]', place: '[Nama Sekolah / Kampus], [Kota]', notes: ['[Nilai rata-rata / prestasi bila ada]'] }],
  experience: [
    { title: '[Posisi / Peran]', period: '[Bulan Tahun – Bulan Tahun]', place: '[Nama Perusahaan / Organisasi], [Kota]', points: ['[Kata kerja + apa yang dikerjakan + hasilnya]', '[Tanggung jawab atau pencapaian lain]'] },
    { title: '[Peran di Organisasi / PKL / Kepanitiaan]', period: '[Bulan Tahun – Bulan Tahun]', place: '[Nama Organisasi], [Kota]', points: ['[Kegiatan yang kamu pegang dan hasilnya]'] },
  ],
  skills: ['**Hard skill:** [contoh: Microsoft Word & Excel, mengetik cepat, mengemudi SIM A]', '**Soft skill:** [contoh: komunikasi, kerja tim, disiplin, teliti]'],
  certificates: ['[Nama pelatihan / sertifikat] — [Penyelenggara] ([Tahun])'],
  languages: '[Bahasa Indonesia (aktif), Bahasa Inggris (dasar/menengah)]',
});

const exampleCv = cvPage({
  name: 'RIZKY PRATAMA',
  contact: 'Jatisampurna, Kota Bekasi · 0812-3456-7890 · rizky.pratama@gmail.com · linkedin.com/in/rizky-pratama',
  summary: 'Lulusan SMK jurusan Teknik Komputer dan Jaringan yang teliti, cepat belajar, dan terbiasa bekerja dalam tim. Berpengalaman PKL sebagai teknisi jaringan dan aktif di Karang Taruna. Siap berkontribusi sebagai staf IT support atau admin.',
  education: [{ title: 'Teknik Komputer dan Jaringan', period: '2021 – 2024', place: 'SMK Negeri 1 Kota Bekasi', notes: ['Nilai rata-rata ujian sekolah 85,4'] }],
  experience: [
    { title: 'Teknisi Jaringan (Praktik Kerja Lapangan)', period: 'Jan 2024 – Mar 2024', place: 'PT Jaringan Nusantara, Bekasi', points: ['Membantu instalasi dan perbaikan jaringan Wi-Fi di 12 lokasi pelanggan.', 'Mencatat laporan gangguan harian dan menyelesaikan rata-rata 5 tiket per hari.'] },
    { title: 'Sie Acara — Lomba HUT RI ke-80', period: 'Jul 2025 – Agu 2025', place: 'Karang Taruna Kelurahan Jatisampurna', points: ['Menyusun jadwal dan mengoordinasikan 8 jenis lomba untuk lebih dari 150 peserta.', 'Mengelola pendaftaran peserta memakai Google Form dan Excel.'] },
  ],
  skills: ['**Hard skill:** Microsoft Word, Excel (rumus dasar, tabel), instalasi jaringan LAN/Wi-Fi, troubleshooting komputer', '**Soft skill:** komunikasi, kerja tim, disiplin waktu, teliti'],
  certificates: ['Pelatihan Kesiapan Kerja bagi Pemuda Karang Taruna — Universitas Terbuka (2026)', 'Junior Network Administrator — BNSP (2024)'],
  languages: 'Bahasa Indonesia (aktif), Bahasa Inggris (dasar)',
});

const doc = new Document({
  creator: 'Kelompok 1 MK-PM Universitas Terbuka', title: 'Template Curriculum Vitae (CV)', styles: STYLES, numbering: NUMBERING,
  sections: [
    { properties: { page: { size: A4, margin: MARGIN } }, footers: { default: footer('Template CV') },
      children: [...cover('Materi pelatihan', 'Template Curriculum Vitae (CV)', 'Panduan, template siap isi, dan contoh CV yang sudah jadi'), ...guide] },
    { properties: { page: { size: A4, margin: MARGIN } }, footers: NO_FOOTER, children: [muted('TEMPLATE CV — ganti semua teks [dalam kurung siku] dengan data kamu, lalu hapus baris petunjuk ini.'), ...blankCv] },
    { properties: { page: { size: A4, margin: MARGIN } }, footers: NO_FOOTER, children: [muted('CONTOH CV — data fiktif, hanya sebagai gambaran CV yang sudah jadi.'), ...exampleCv] },
  ],
});

fs.mkdirSync('out', { recursive: true });
Packer.toBuffer(doc).then((buffer) => {
  fs.writeFileSync('out/Template-CV.docx', buffer);
  console.log('out/Template-CV.docx');
});
