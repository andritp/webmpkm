'use strict';

const fs = require('fs');
const { Document, Packer, Paragraph, TextRun, AlignmentType, Footer, TabStopType } = require('docx');
const { COLORS, STYLES, NUMBERING, h1, h2, p, muted, bullets, steps, pageBreak, spacer, box, grid, footer, cover } = require('./lib');

const A4 = { width: 11906, height: 16838 };
const MARGIN = { top: 1134, bottom: 1020, left: 1418, right: 1134 };
const NO_FOOTER = { default: new Footer({ children: [] }) };

/** Plain business-letter paragraph: justified body text, no extra styling. */
const line = (text, options = {}) => new Paragraph({ spacing: { after: options.after ?? 0, line: 276 }, alignment: options.align, children: [new TextRun({ text, bold: options.bold })] });
const body = (text) => new Paragraph({ spacing: { after: 110, line: 276 }, alignment: AlignmentType.JUSTIFIED, children: [new TextRun(text)] });

function letter(data) {
  return [
    line(data.cityDate, { align: AlignmentType.RIGHT, after: 240 }),
    line(`Perihal: ${data.subject}`, { bold: true }),
    line(`Lampiran: ${data.attachmentCount}`, { after: 240 }),
    line('Kepada Yth.'),
    line(data.recipient),
    line(data.company),
    line(data.address, { after: 240 }),
    line('Dengan hormat,', { after: 160 }),
    body(data.opening),
    ...data.identity.map(([label, value]) => new Paragraph({ spacing: { after: 0, line: 276 }, indent: { left: 400 }, tabStops: [{ type: TabStopType.LEFT, position: 2700 }], children: [new TextRun(`${label}	: ${value}`)] })),
    spacer(160),
    body(data.qualification),
    body(data.motivation),
    line('Sebagai bahan pertimbangan, bersama surat ini saya lampirkan:', { after: 60 }),
    ...bullets(data.attachments),
    body(data.closing),
    line('Hormat saya,', { after: 680 }),
    line(data.name, { bold: true }),
  ];
}

const guide = [
  h1('Panduan Menulis Surat Lamaran Kerja'),
  p('Surat lamaran adalah **perkenalan pertama** kamu kepada perusahaan. Kalau CV menjawab "apa yang sudah kamu lakukan", surat lamaran menjawab **"kenapa kamu cocok untuk posisi ini"**. Cukup **1 halaman**, sopan, dan disesuaikan untuk setiap perusahaan.'),
  h2('Struktur surat lamaran (urut dari atas)'),
  grid([
    ['No', 'Bagian', 'Isi'],
    ['1', 'Tempat & tanggal', 'Kota dan tanggal surat dibuat, di kanan atas'],
    ['2', 'Perihal & lampiran', 'Posisi yang dilamar dan jumlah berkas yang dilampirkan'],
    ['3', 'Tujuan surat', 'Yth. HRD / Bagian Personalia, nama perusahaan, alamat'],
    ['4', 'Pembuka', 'Salam + posisi yang dilamar + dari mana kamu tahu lowongannya'],
    ['5', 'Data diri singkat', 'Nama, tempat/tanggal lahir, pendidikan, alamat, nomor HP, email'],
    ['6', 'Isi / kualifikasi', 'Keahlian dan pengalaman yang cocok dengan syarat lowongan'],
    ['7', 'Motivasi', 'Alasan tertarik pada perusahaan dan apa yang bisa kamu berikan'],
    ['8', 'Lampiran', 'Daftar berkas: CV, ijazah, transkrip, KTP, sertifikat, foto'],
    ['9', 'Penutup', 'Harapan untuk wawancara + terima kasih + tanda tangan dan nama'],
  ], [700, 2400, 6538]),
  spacer(),
  h2('Langkah membuat surat dari template ini'),
  ...steps([
    'Baca **iklan lowongan** dengan teliti. Catat nama posisi, nama perusahaan, alamat, dan syarat yang diminta.',
    'Buka halaman **"Template Surat Lamaran"**. Ganti semua teks dalam **[kurung siku]**.',
    'Di paragraf kualifikasi, sebutkan **2–3 keahlian yang sama dengan syarat lowongan**. Contoh: lowongan minta "menguasai Excel", tulis pengalamanmu memakai Excel.',
    'Sesuaikan daftar lampiran dengan berkas yang benar-benar kamu kirim.',
    'Baca ulang. Pastikan **nama perusahaan dan posisi tidak salah** (kesalahan paling fatal karena menyalin surat lama).',
    'Simpan sebagai **PDF** dengan nama file **Surat Lamaran_Nama_Posisi.pdf**.',
  ]),
  box('Ingat!', [
    'Satu surat untuk satu perusahaan. **Jangan memakai surat yang sama** untuk semua lowongan tanpa diubah.',
    'Gunakan bahasa **formal dan sopan**, hindari singkatan seperti "sy", "yg", "trims".',
    'Tidak perlu menceritakan riwayat hidup lengkap. Cukup yang **berhubungan dengan posisi**.',
  ], { fill: COLORS.redSoft, accent: 'A3131A' }),
  h1('Mengirim Lamaran Lewat Email', { newPage: true }),
  p('Sekarang sebagian besar lamaran dikirim lewat email. Isi email cukup singkat, karena surat lamaran lengkap dan CV dilampirkan dalam bentuk PDF.'),
  ...steps([
    'Isi kolom **Kepada** dengan alamat email HRD sesuai iklan. Periksa ejaannya.',
    'Tulis **subjek** sesuai format yang diminta. Kalau tidak ada format, gunakan: **Lamaran Kerja_Posisi_Nama Lengkap**.',
    'Tulis isi email singkat (lihat contoh di bawah).',
    'Lampirkan file **PDF**: surat lamaran, CV, dan berkas lain. Ukuran total sebaiknya di bawah 5 MB.',
    'Kirim ke email sendiri dulu untuk mengecek, lalu kirim ke perusahaan pada **jam kerja** (08.00–16.00).',
  ]),
  box('Contoh isi email lamaran', [
    '**Subjek:** Lamaran Kerja_Staf Administrasi_Rizky Pratama',
    'Yth. Bapak/Ibu HRD PT Maju Bersama,',
    'Dengan hormat, saya Rizky Pratama bermaksud melamar posisi Staf Administrasi sesuai informasi lowongan di LinkedIn. Bersama email ini saya lampirkan surat lamaran, CV, dan berkas pendukung dalam format PDF.',
    'Besar harapan saya dapat mengikuti tahap seleksi berikutnya. Atas perhatian Bapak/Ibu, saya ucapkan terima kasih.',
    'Hormat saya,',
    'Rizky Pratama — 0812-3456-7890',
  ]),
  spacer(),
  h2('Checklist sebelum mengirim'),
  grid([
    ['Cek', 'Sudah?'],
    ['Nama perusahaan, posisi, dan alamat sudah benar', '☐'],
    ['Tidak ada salah ketik (sudah dibaca ulang)', '☐'],
    ['Nomor HP dan email aktif serta benar', '☐'],
    ['Semua lampiran sudah PDF dan namanya rapi', '☐'],
    ['Subjek email sesuai format lowongan', '☐'],
    ['Dikirim pada jam kerja', '☐'],
  ], [7638, 2000], { headerFill: COLORS.navyMid }),
];

const template = letter({
  cityDate: '[Kota], [Tanggal Bulan Tahun]',
  subject: 'Lamaran Pekerjaan sebagai [Nama Posisi]',
  attachmentCount: '[jumlah] berkas',
  recipient: 'Bapak/Ibu HRD [Nama Perusahaan]',
  company: '[Nama Perusahaan]',
  address: '[Alamat Perusahaan]',
  opening: 'Berdasarkan informasi lowongan kerja yang saya peroleh dari [sumber informasi, misalnya LinkedIn / website perusahaan / teman] pada tanggal [tanggal], saya bermaksud melamar posisi [Nama Posisi] di [Nama Perusahaan]. Adapun data diri saya sebagai berikut:',
  identity: [['Nama', '[Nama Lengkap]'], ['Tempat, tgl. lahir', '[Kota, Tanggal Lahir]'], ['Pendidikan', '[Jurusan – Nama Sekolah/Kampus (Tahun Lulus)]'], ['Alamat', '[Alamat Domisili]'], ['No. HP / WhatsApp', '[Nomor Aktif]'], ['Email', '[email@gmail.com]']],
  qualification: '[Ceritakan 2–3 keahlian atau pengalaman yang sesuai dengan syarat lowongan. Contoh: Saya memiliki pengalaman ... selama ... dan terbiasa menggunakan ... . Saya juga pribadi yang ... .]',
  motivation: '[Tulis alasan kamu tertarik pada perusahaan/posisi ini dan apa yang bisa kamu berikan. Contoh: Saya tertarik bergabung karena ... dan siap belajar serta berkontribusi untuk ... .]',
  attachments: ['Curriculum Vitae (CV)', 'Fotokopi ijazah dan transkrip nilai', 'Fotokopi KTP', '[Sertifikat pendukung]'],
  closing: 'Besar harapan saya untuk dapat mengikuti tahap seleksi selanjutnya dan menjelaskan kemampuan saya secara langsung. Atas perhatian Bapak/Ibu, saya ucapkan terima kasih.',
  name: '[Nama Lengkap]',
});

const example = letter({
  cityDate: 'Bekasi, 14 Oktober 2026',
  subject: 'Lamaran Pekerjaan sebagai Staf Administrasi',
  attachmentCount: '4 berkas',
  recipient: 'Bapak/Ibu HRD PT Maju Bersama',
  company: 'PT Maju Bersama',
  address: 'Jl. Raya Jatiasih No. 25, Kota Bekasi',
  opening: 'Berdasarkan informasi lowongan kerja yang saya peroleh dari LinkedIn pada tanggal 12 Oktober 2026, saya bermaksud melamar posisi Staf Administrasi di PT Maju Bersama. Adapun data diri saya sebagai berikut:',
  identity: [['Nama', 'Rizky Pratama'], ['Tempat, tgl. lahir', 'Bekasi, 7 Maret 2006'], ['Pendidikan', 'SMK Teknik Komputer dan Jaringan (2024)'], ['Alamat', 'Jatisampurna, Kota Bekasi'], ['No. HP / WhatsApp', '0812-3456-7890'], ['Email', 'rizky.pratama@gmail.com']],
  qualification: 'Saya terbiasa menggunakan Microsoft Word dan Excel untuk membuat laporan dan mengolah data. Saat menjadi panitia lomba HUT RI di Karang Taruna, saya mengelola pendaftaran lebih dari 150 peserta menggunakan Google Form dan Excel. Saya pribadi yang teliti, disiplin waktu, dan mudah bekerja sama dalam tim.',
  motivation: 'Saya tertarik bergabung dengan PT Maju Bersama karena perusahaan ini dikenal memberi kesempatan berkembang bagi lulusan baru. Saya siap belajar dengan cepat dan membantu kelancaran administrasi perusahaan.',
  attachments: ['Curriculum Vitae (CV)', 'Fotokopi ijazah dan transkrip nilai', 'Fotokopi KTP', 'Sertifikat Pelatihan Kesiapan Kerja'],
  closing: 'Besar harapan saya untuk dapat mengikuti tahap seleksi selanjutnya dan menjelaskan kemampuan saya secara langsung. Atas perhatian Bapak/Ibu, saya ucapkan terima kasih.',
  name: 'Rizky Pratama',
});

const doc = new Document({
  creator: 'Kelompok 1 MK-PM Universitas Terbuka', title: 'Template Surat Lamaran Kerja', styles: STYLES, numbering: NUMBERING,
  sections: [
    { properties: { page: { size: A4, margin: MARGIN } }, footers: { default: footer('Template Surat Lamaran') },
      children: [...cover('Materi pelatihan', 'Template Surat Lamaran Kerja', 'Panduan, template siap isi, contoh surat, dan contoh email lamaran'), ...guide] },
    { properties: { page: { size: A4, margin: MARGIN } }, footers: NO_FOOTER, children: [muted('TEMPLATE SURAT LAMARAN — ganti semua teks [dalam kurung siku], lalu hapus baris petunjuk ini.'), ...template] },
    { properties: { page: { size: A4, margin: MARGIN } }, footers: NO_FOOTER, children: [muted('CONTOH SURAT LAMARAN — data fiktif, hanya sebagai gambaran.'), ...example] },
  ],
});

fs.mkdirSync('out', { recursive: true });
Packer.toBuffer(doc).then((buffer) => {
  fs.writeFileSync('out/Template-Surat-Lamaran-Kerja.docx', buffer);
  console.log('out/Template-Surat-Lamaran-Kerja.docx');
});
