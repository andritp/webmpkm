'use strict';

const fs = require('fs');
const { Document, Packer, BorderStyle, Paragraph, Table, TableCell, TableRow, WidthType } = require('docx');
const { COLORS, STYLES, NUMBERING, h1, h2, p, muted, bullets, steps, spacer, box, grid, footer, cover } = require('./lib');

const A5 = { width: 8391, height: 11906 };
// 720 twips = 1.27 cm margins: still printer-safe, but gains enough height/width
// that each chapter fits its pages without leaving one orphan box behind.
const MARGIN = { top: 720, bottom: 720, left: 720, right: 720 };
const WIDTH = A5.width - MARGIN.left - MARGIN.right;
const half = [Math.floor(WIDTH / 2), WIDTH - Math.floor(WIDTH / 2)];

/** Interview question with a sample answer, the core "tanya-jawab" format promised in the proposal. */
const qa = (question, answer, tip) => [
  p(`**T: ${question}**`, { spacing: { before: 120, after: 40 }, keepNext: true }),
  box(null, [`**Contoh jawaban:** ${answer}`, ...(tip ? [`**Tips:** ${tip}`] : [])], { width: WIDTH, fill: COLORS.blueSoft }),
];

const intro = [
  h1('Cara Memakai Buku Saku Ini'),
  p('Buku saku ini adalah **bekal praktis** setelah pelatihan. Bacalah sedikit-sedikit, ulangi bagian yang paling kamu butuhkan, dan pakai **daftar periksa** di akhir buku sebelum melamar kerja.'),
  grid([
    ['Bab', 'Isi'],
    ['1', 'Kenali dirimu: keahlian dan minat'],
    ['2', 'Mencari lowongan dengan aman'],
    ['3', 'Menyiapkan berkas lamaran'],
    ['4', 'Tanya-jawab tes dan wawancara kerja'],
    ['5', 'Budaya dan etika di tempat kerja'],
    ['6', 'Hari pertama kerja dan daftar periksa'],
    ['7', 'Catatan pribadi'],
  ], [900, WIDTH - 900]),
  spacer(),
  box('Ingat', ['Mencari kerja itu **proses**, bukan sekali jadi. Ditolak itu wajar. Yang penting terus belajar, perbaiki berkas, dan coba lagi.'], { width: WIDTH, fill: COLORS.goldSoft, accent: COLORS.gold }),
];

const chapter1 = [
  h1('Bab 1 · Kenali Dirimu', { newPage: true }),
  p('Sebelum melamar, kamu perlu tahu **apa yang kamu bisa** dan **pekerjaan apa yang cocok**. Perusahaan mencari orang yang tepat, bukan sekadar yang paling pintar.'),
  h2('Hard skill dan soft skill'),
  grid([
    ['Hard skill (bisa diukur)', 'Soft skill (sikap dan cara kerja)'],
    ['Mengetik, Microsoft Word & Excel', 'Komunikasi yang sopan dan jelas'],
    ['Mengemudi (punya SIM)', 'Kerja sama tim'],
    ['Menjahit, memasak, servis motor', 'Disiplin dan tepat waktu'],
    ['Desain dengan Canva', 'Jujur dan bertanggung jawab'],
    ['Instalasi jaringan / komputer', 'Mau belajar dan terbuka pada masukan'],
  ], half),
  h2('Latihan: tulis 3 kekuatanmu'),
  ...steps([
    'Ingat kegiatan yang pernah kamu lakukan: sekolah, PKL, Karang Taruna, membantu usaha keluarga.',
    'Tulis apa yang kamu kerjakan di sana. Contoh: "mengatur pendaftaran lomba 17 Agustus".',
    'Ubah jadi keahlian: "teliti mengelola data peserta" dan "mampu bekerja dalam tim".',
  ]),
  box('Contoh', ['Kegiatan: menjaga warung orang tua.', 'Keahlian yang bisa ditulis: **melayani pelanggan, menghitung uang dengan teliti, mencatat stok barang**.'], { width: WIDTH }),
];

const chapter2 = [
  h1('Bab 2 · Mencari Lowongan dengan Aman', { newPage: true }),
  h2('Tempat mencari lowongan'),
  ...bullets([
    '**Situs dan aplikasi lowongan:** LinkedIn, Jobstreet, Glints, KitaLulus.',
    '**Situs resmi pemerintah:** Karirhub Kemnaker dan informasi Dinas Tenaga Kerja Kota Bekasi.',
    '**Website dan media sosial resmi perusahaan** (bagian "Karier").',
    '**Bursa kerja (job fair)** di kampus, sekolah, atau mal.',
    '**Jaringan pertemanan:** Karang Taruna, alumni sekolah, keluarga.',
  ]),
  h2('Waspada lowongan palsu!'),
  p('Lowongan palsu biasanya terlihat terlalu menggiurkan. Tolak dan laporkan bila menemukan tanda berikut:'),
  grid([
    ['Tanda bahaya', 'Yang benar'],
    ['Diminta **membayar** biaya pendaftaran atau seragam', 'Perusahaan resmi **tidak memungut biaya** apa pun dari pelamar'],
    ['Gaji sangat tinggi untuk pekerjaan mudah', 'Gaji wajar sesuai posisi dan pengalaman'],
    ['Email gratisan, nama perusahaan tidak jelas', 'Email berdomain perusahaan, alamat kantor jelas'],
    ['Wawancara di hotel atau rumah, mendadak', 'Jadwal resmi, lokasi kantor atau video call resmi'],
    ['Meminta data pribadi berlebihan (PIN, OTP, selfie KTP)', 'Hanya meminta berkas lamaran standar'],
  ], half, { headerFill: 'A3131A' }),
  spacer(),
  box('Langkah mengecek lowongan', ['1. Cari nama perusahaan di Google dan Google Maps.', '2. Cek website dan media sosial resminya.', '3. Tanyakan ke teman atau grup Karang Taruna bila ragu.'], { width: WIDTH }),
];

const chapter3 = [
  h1('Bab 3 · Menyiapkan Berkas Lamaran', { newPage: true }),
  p('Siapkan berkas **sebelum** ada lowongan, supaya kamu bisa melamar dengan cepat.'),
  h2('Berkas yang biasanya diminta'),
  ...bullets(['Surat lamaran kerja', 'CV (Curriculum Vitae) 1 halaman', 'Scan ijazah dan transkrip nilai', 'Scan KTP', 'Sertifikat pelatihan (termasuk sertifikat pelatihan ini!)', 'Pas foto formal (bila diminta)', 'SKCK dan surat keterangan sehat (biasanya saat diterima)']),
  h2('Simpan dengan rapi di HP'),
  ...steps([
    'Buat folder **"Berkas Lamaran"** di Google Drive atau galeri HP.',
    'Scan berkas dengan aplikasi pemindai (misalnya fitur scan di Google Drive), simpan sebagai **PDF**.',
    'Beri nama yang jelas: **CV_Rizky Pratama.pdf**, **Ijazah_Rizky Pratama.pdf**.',
  ]),
  box('Pakai template dari pelatihan', ['Unduh **Template CV** dan **Template Surat Lamaran Kerja** di menu **Materi** web pelatihan. Di dalamnya ada panduan langkah demi langkah dan contoh yang sudah jadi.'], { width: WIDTH, fill: COLORS.goldSoft, accent: COLORS.gold }),
];

const chapter4 = [
  h1('Bab 4 · Tanya-Jawab Tes dan Wawancara', { newPage: true }),
  h2('Tahapan rekrutmen yang umum'),
  ...steps(['Seleksi berkas (CV dan surat lamaran)', 'Tes tertulis atau psikotes', 'Wawancara HRD', 'Wawancara user (calon atasan)', 'Tes kesehatan dan tawaran kerja (offering)']),
  h2('Persiapan H-1 wawancara'),
  ...bullets(['Cari tahu profil perusahaan: produk, lokasi, dan nilai perusahaan.', 'Siapkan pakaian rapi: kemeja berkerah, celana/rok bahan, sepatu tertutup.', 'Cek lokasi dan rute, rencanakan **datang 15 menit lebih awal**.', 'Untuk wawancara online: cek sinyal, baterai, kamera, dan latar yang rapi.', 'Siapkan map berisi CV dan berkas fotokopi.']),
  h2('Metode STAR untuk menjawab'),
  grid([
    ['Huruf', 'Artinya', 'Contoh'],
    ['S', 'Situation — situasinya', 'Saat lomba 17 Agustus di Karang Taruna...'],
    ['T', 'Task — tugasmu', '...saya bertugas mengurus pendaftaran peserta.'],
    ['A', 'Action — yang kamu lakukan', 'Saya membuat Google Form dan rekap Excel.'],
    ['R', 'Result — hasilnya', '150 peserta terdata rapi dan acara tepat waktu.'],
  ], [900, 2400, WIDTH - 3300]),
  h2('Pertanyaan yang sering muncul'),
  ...qa('Coba ceritakan tentang diri Anda.', 'Nama saya Rizky, lulusan SMK jurusan TKJ tahun 2024. Saya pernah PKL sebagai teknisi jaringan dan aktif di Karang Taruna sebagai panitia acara. Saya senang bekerja teliti dan dalam tim, dan sekarang saya ingin berkembang sebagai staf IT support.', 'Jawab sekitar 1 menit: pendidikan, pengalaman, keahlian, lalu tujuan. Jangan menceritakan masalah pribadi.'),
  ...qa('Apa kelebihan Anda?', 'Saya teliti dan disiplin waktu. Contohnya saat mengurus pendaftaran lomba, tidak ada data peserta yang tertukar dan semua selesai sebelum acara.', 'Selalu sertakan contoh nyata.'),
  ...qa('Apa kekurangan Anda?', 'Dulu saya kurang percaya diri berbicara di depan banyak orang. Sekarang saya berlatih dengan menjadi MC acara Karang Taruna dan sudah jauh lebih baik.', 'Sebutkan kekurangan yang wajar, lalu jelaskan usaha memperbaikinya.'),
  ...qa('Mengapa Anda ingin bekerja di perusahaan ini?', 'Saya melihat perusahaan ini berkembang dan memberi kesempatan belajar bagi lulusan baru. Keahlian saya di bidang komputer cocok dengan posisi yang dibuka.', 'Pelajari profil perusahaan sebelum wawancara.'),
  ...qa('Anda belum punya pengalaman kerja, mengapa kami harus memilih Anda?', 'Walaupun belum bekerja penuh waktu, saya punya pengalaman PKL dan organisasi. Saya cepat belajar, mau menerima arahan, dan siap bekerja keras.', 'Ubah pengalaman organisasi dan PKL menjadi nilai lebih.'),
  ...qa('Bagaimana jika Anda berbeda pendapat dengan rekan kerja?', 'Saya akan mendengarkan pendapatnya dulu, lalu menyampaikan pendapat saya dengan sopan disertai alasan. Kalau belum sepakat, saya minta arahan atasan.', null),
  ...qa('Bersedia bekerja dengan sistem shift atau lembur?', 'Bersedia, selama sesuai aturan perusahaan. Saya sudah terbiasa mengatur waktu.', 'Jawab jujur sesuai kondisi kamu.'),
  ...qa('Berapa gaji yang Anda harapkan?', 'Saya berharap gaji sesuai standar perusahaan dan UMK Kota Bekasi untuk posisi ini. Saya terbuka untuk berdiskusi.', 'Cari tahu kisaran gaji dan UMK sebelum wawancara.'),
  ...qa('Apakah ada yang ingin Anda tanyakan?', 'Boleh saya tahu seperti apa tugas sehari-hari di posisi ini dan apa yang diharapkan dari karyawan baru dalam 3 bulan pertama?', 'Selalu siapkan 1–2 pertanyaan. Hindari langsung bertanya soal gaji dan libur.'),
];

const chapter5 = [
  h1('Bab 5 · Budaya dan Etika Kerja', { newPage: true }),
  p('Kemampuan membuatmu **diterima**, tetapi sikap yang membuatmu **bertahan dan berkembang**.'),
  grid([
    ['Lakukan', 'Hindari'],
    ['Datang tepat waktu, kabari atasan bila terlambat', 'Terlambat tanpa kabar atau titip absen'],
    ['Berpakaian rapi sesuai aturan', 'Berpakaian asal atau terlalu santai'],
    ['Selesaikan tugas sesuai tenggat; bertanya bila belum paham', 'Menunda tugas, menyalahkan orang lain, diam lalu salah'],
    ['Jaga kerahasiaan data; sopan kepada semua orang', 'Bergosip, mengunggah urusan kantor ke media sosial'],
    ['Memakai HP seperlunya saat bekerja', 'Asyik main HP saat jam kerja'],
  ], half),
  h2('Contoh situasi'),
  box(null, [
    '**Kamu sakit:** kabari atasan sebelum jam masuk lewat pesan yang sopan, lalu kirim surat dokter bila diminta. Contoh pesan: "Selamat pagi, Pak Budi. Mohon maaf, hari ini saya izin tidak masuk karena demam. Surat dokter akan saya kirimkan. Terima kasih."',
    '**Kamu melakukan kesalahan:** segera akui, laporkan ke atasan, dan tawarkan cara memperbaikinya. Jujur lebih dihargai daripada menutupi kesalahan.',
  ], { width: WIDTH, fill: COLORS.greenSoft, accent: '1F9D55' }),
];

const chapter6 = [
  h1('Bab 6 · Hari Pertama dan Daftar Periksa', { newPage: true }),
  h2('Tips hari pertama kerja'),
  ...bullets(['Datang lebih awal dan perkenalkan diri dengan ramah.', 'Bawa buku catatan untuk mencatat arahan dan nama rekan kerja.', 'Pelajari aturan perusahaan: jam kerja, istirahat, dan cara izin.', 'Jangan malu bertanya. Karyawan baru memang diharapkan banyak belajar.']),
  h2('Daftar periksa siap kerja'),
  grid([
    ['Sudah siap?', 'Cek'],
    ['CV 1 halaman dalam format PDF', '☐'],
    ['Surat lamaran yang bisa disesuaikan', '☐'],
    ['Scan ijazah, KTP, dan sertifikat', '☐'],
    ['Email profesional dan nomor WhatsApp aktif', '☐'],
    ['Profil LinkedIn lengkap dengan foto rapi', '☐'],
    ['Sudah latihan menjawab pertanyaan wawancara', '☐'],
    ['Pakaian wawancara siap', '☐'],
    ['Tahu cara mengecek lowongan palsu', '☐'],
  ], [WIDTH - 900, 900], { headerFill: COLORS.navyMid }),
  spacer(240),
  box('Penutup', ['Setiap lamaran yang kamu kirim adalah latihan. Teruslah memperbaiki diri, jaga semangat, dan saling dukung sesama pemuda Karang Taruna.', '**Belajar Bersama, Tumbuh Bersama.**'], { width: WIDTH, fill: COLORS.goldSoft, accent: COLORS.gold }),
  muted('Disusun oleh Kelompok 1 MK-PM Universitas Terbuka untuk Program Pelatihan Kesiapan Kerja Pemuda Karang Taruna Kecamatan Jatisampurna, 2026.'),
];

/** Ruled lines so the printed pocket book has a notes page like a real notebook.
 * Word merges adjacent paragraph borders, so ruled lines are drawn as borderless
 * table rows whose bottom border stays visible row by row. */
const notesLines = new Table({
  width: { size: WIDTH, type: WidthType.DXA }, columnWidths: [WIDTH],
  rows: Array.from({ length: 10 }, () => new TableRow({ cantSplit: true, children: [new TableCell({
    width: { size: WIDTH, type: WidthType.DXA },
    borders: {
      top: { style: BorderStyle.NONE }, left: { style: BorderStyle.NONE }, right: { style: BorderStyle.NONE },
      bottom: { style: BorderStyle.SINGLE, size: 4, color: COLORS.line },
    },
    margins: { top: 60, bottom: 60, left: 0, right: 0 },
    children: [new Paragraph({ spacing: { after: 0 }, children: [] })],
  })] })),
});

const notes = [
  h1('Catatan', { newPage: true }),
  p('Tulis di sini hal-hal yang ingin kamu ingat: jadwal lamaran, nama perusahaan yang sudah dihubungi, atau catatan dari wawancara.'),
  notesLines,
];

const doc = new Document({
  creator: 'Kelompok 1 MK-PM Universitas Terbuka', title: 'Buku Saku Job Ready: Bekal Menuju Dunia Kerja', styles: STYLES, numbering: NUMBERING,
  sections: [{
    properties: { page: { size: A5, margin: MARGIN } }, footers: { default: footer('Buku Saku Job Ready') },
    children: [
      ...cover('Buku saku', 'Job Ready', 'Bekal Menuju Dunia Kerja: tanya-jawab seputar lamaran, wawancara, dan etika kerja'),
      ...intro, ...chapter1, ...chapter2, ...chapter3, ...chapter4, ...chapter5, ...chapter6, ...notes,
    ],
  }],
});

fs.mkdirSync('out', { recursive: true });
Packer.toBuffer(doc).then((buffer) => {
  fs.writeFileSync('out/Buku-Saku-Job-Ready.docx', buffer);
  console.log('out/Buku-Saku-Job-Ready.docx');
});
