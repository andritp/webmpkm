'use strict';

const fs = require('fs');
const { Document, Packer } = require('docx');
const { COLORS, STYLES, NUMBERING, h1, h2, p, muted, bullets, steps, spacer, box, grid, footer, cover } = require('./lib');

const A5 = { width: 8391, height: 11906 };
// 720 twips = 1.27 cm margins: matches the pocket book so both print alike.
const MARGIN = { top: 720, bottom: 720, left: 720, right: 720 };
const WIDTH = A5.width - MARGIN.left - MARGIN.right;
const LINKEDIN_BLUE = '0A66C2';

const example = (title, lines) => box(title, lines, { width: WIDTH, fill: COLORS.blueSoft, accent: LINKEDIN_BLUE });
const tip = (lines) => box('Tips', lines, { width: WIDTH, fill: COLORS.goldSoft, accent: COLORS.gold });

const intro = [
  h1('Kenapa Perlu LinkedIn?'),
  p('LinkedIn adalah **media sosial khusus dunia kerja**. Di sini kamu bisa memajang profil seperti CV online, mencari lowongan, melamar langsung, dan terhubung dengan HRD atau orang yang bekerja di perusahaan impianmu.'),
  ...bullets(['Banyak perusahaan membuka lowongan **hanya** lewat LinkedIn.', 'Rekruter bisa **menemukan profilmu** walaupun kamu belum melamar.', 'Gratis dan bisa dibuat dari HP dalam 15–30 menit.']),
  h2('Yang perlu disiapkan'),
  grid([
    ['Siapkan', 'Keterangan'],
    ['Email aktif', 'Sebaiknya email profesional, misalnya nama.kamu@gmail.com'],
    ['Foto formal', 'Wajah jelas, rapi, latar polos (tidak harus studio)'],
    ['CV kamu', 'Untuk menyalin data pendidikan, pengalaman, dan keahlian'],
    ['Sertifikat', 'Termasuk sertifikat pelatihan ini'],
  ], [2200, WIDTH - 2200]),
  spacer(),
  muted('Catatan: tampilan dan nama tombol LinkedIn bisa sedikit berbeda tergantung versi aplikasi dan pilihan bahasa (Indonesia/Inggris). Di panduan ini nama tombol ditulis dalam dua bahasa bila perlu.'),
];

const createAccount = [
  h1('Langkah 1 · Membuat Akun', { newPage: true }),
  ...steps([
    'Unduh aplikasi **LinkedIn** di Play Store / App Store, atau buka **linkedin.com** di browser.',
    'Ketuk **"Bergabung sekarang" (Join now)**.',
    'Masukkan **email** dan buat **kata sandi** minimal 8 karakter (gabungan huruf, angka, dan simbol).',
    'Isi **nama depan dan nama belakang** sesuai KTP. Jangan pakai nama panggilan atau emoji.',
    'Isi **lokasi**: misalnya Bekasi, Jawa Barat, Indonesia.',
    'Isi **jabatan terakhir**. Kalau belum bekerja, pilih status **pelajar/mahasiswa** atau tulis posisi yang kamu tuju, misalnya "Staf Administrasi".',
    'Buka email dan masukkan **kode verifikasi** yang dikirim LinkedIn.',
    'Ikuti langkah awal (pilih minat, unggah foto). Langkah yang belum siap boleh dilewati dan diisi nanti.',
  ]),
  tip(['Simpan email dan kata sandi di tempat aman. Jangan pernah memberikan **kode OTP** LinkedIn kepada siapa pun, termasuk yang mengaku "HRD".']),
];

const profile = [
  h1('Langkah 2 · Melengkapi Profil', { newPage: true }),
  p('Buka profil dengan mengetuk **foto profil kecil → "Lihat profil" (View profile)**. Ketuk ikon **pensil** untuk mengedit setiap bagian, atau **"Tambahkan bagian profil" (Add profile section)** untuk menambah bagian baru.'),
  h2('a. Foto profil dan foto latar'),
  ...bullets(['Foto profil: wajah terlihat jelas (sekitar 60% bingkai), senyum, pakaian rapi, latar polos.', 'Foto latar (banner): boleh pakai desain sederhana dari Canva bertuliskan bidang yang kamu minati.']),
  h2('b. Headline (judul di bawah nama)'),
  p('Headline adalah **kalimat pertama yang dibaca rekruter**. Tulis keahlian dan tujuan kariermu, bukan hanya "Pengangguran" atau "Mencari kerja".'),
  example('Contoh headline', ['Lulusan SMK TKJ | Siap Bekerja sebagai IT Support | Jaringan & Troubleshooting Komputer', 'Staf Administrasi | Microsoft Excel & Word | Teliti dan Disiplin', 'Pemuda Karang Taruna Jatisampurna | Tertarik di Bidang Customer Service']),
  h2('c. Info / Tentang (About)'),
  p('Tulis 3–5 kalimat: siapa kamu, keahlian utama, pengalaman singkat, dan pekerjaan yang dicari.'),
  example('Contoh bagian Tentang', ['Saya lulusan SMK jurusan Teknik Komputer dan Jaringan yang teliti dan cepat belajar. Saya berpengalaman PKL sebagai teknisi jaringan dan aktif di Karang Taruna sebagai panitia acara. Saya terbiasa menggunakan Microsoft Excel dan Google Form untuk mengelola data. Saat ini saya terbuka untuk peluang kerja sebagai staf IT support atau administrasi di wilayah Bekasi dan sekitarnya.']),
  h2('d. Pengalaman (Experience)'),
  ...steps([
    'Ketuk **"+" di bagian Pengalaman**.',
    'Isi **jabatan** (misalnya "Teknisi Jaringan – PKL"), **jenis pekerjaan** (Magang/Internship), **nama perusahaan**, **lokasi**, dan **tanggal mulai–selesai**.',
    'Di **deskripsi**, tulis 2–3 hal yang kamu kerjakan dan hasilnya.',
    'Tambahkan juga pengalaman **organisasi** (Karang Taruna) dan **kepanitiaan**. Itu sangat berharga!',
  ]),
  h2('e. Pendidikan, keahlian, dan sertifikat'),
  ...bullets([
    '**Pendidikan (Education):** nama sekolah/kampus, jurusan, tahun masuk–lulus.',
    '**Keahlian (Skills):** tambahkan 5–10, misalnya Microsoft Excel, Komunikasi, Kerja Tim, Customer Service.',
    '**Lisensi & sertifikasi (Licenses & certifications):** tambahkan sertifikat pelatihan ini: nama "Pelatihan Kesiapan Kerja bagi Pemuda Karang Taruna", penerbit "Universitas Terbuka", tanggal terbit, dan nomor sertifikat.',
    '**URL profil:** rapikan lewat menu **"Edit public profile & URL"** menjadi misalnya **linkedin.com/in/rizky-pratama**, lalu cantumkan link ini di CV dan surat lamaran.',
  ]),
];

const jobs = [
  h1('Langkah 3 · Mencari dan Melamar Kerja', { newPage: true }),
  ...steps([
    'Ketuk tab **"Pekerjaan" (Jobs)**.',
    'Ketik **kata kunci posisi** (misalnya "admin", "staf gudang", "customer service") dan **lokasi** (misalnya "Bekasi").',
    'Gunakan **filter**: tanggal posting, tingkat pengalaman (Entry level / Magang), dan jenis kerja.',
    'Buka lowongan, baca **deskripsi dan syaratnya** dengan teliti.',
    'Kalau ada tombol **"Lamaran Mudah" (Easy Apply)**, kamu bisa melamar langsung dengan mengunggah CV PDF dan menjawab beberapa pertanyaan.',
    'Kalau tombolnya **"Lamar" (Apply)**, kamu akan diarahkan ke website perusahaan.',
    'Aktifkan **"Notifikasi lowongan" (Job alert)** supaya diberi tahu bila ada lowongan baru yang cocok.',
  ]),
  h2('Tunjukkan bahwa kamu siap bekerja'),
  p('Aktifkan fitur **"Terbuka untuk bekerja" (Open to work)** dari halaman profil. Pilih posisi dan lokasi yang dicari. Kamu bisa memilih agar tanda ini **hanya terlihat oleh rekruter**.'),
  h2('Membangun jaringan'),
  ...bullets(['Terhubung dengan teman, alumni sekolah, anggota Karang Taruna, dan pemateri pelatihan.', 'Saat mengirim permintaan koneksi ke orang yang belum dikenal, **tambahkan catatan singkat yang sopan**.']),
  example('Contoh catatan koneksi', ['Halo Bu Sari, saya Rizky, peserta Pelatihan Kesiapan Kerja Karang Taruna Jatisampurna. Saya tertarik belajar tentang dunia HRD. Izin terhubung, terima kasih.']),
];

const safety = [
  h1('Langkah 4 · Aman di LinkedIn', { newPage: true }),
  grid([
    ['Lakukan', 'Hindari'],
    ['Aktifkan **verifikasi dua langkah** di Pengaturan → Masuk & keamanan', 'Memberikan kode OTP atau kata sandi kepada siapa pun'],
    ['Cek profil perekrut dan perusahaannya sebelum membalas', 'Mentransfer uang untuk "biaya seleksi" atau "pelatihan"'],
    ['Melamar lewat tombol resmi atau website perusahaan', 'Mengirim foto KTP dan data pribadi lewat chat ke orang tak dikenal'],
    ['Menulis dan berkomentar dengan sopan', 'Mengunggah keluhan tentang kantor atau atasan'],
  ], [Math.floor(WIDTH / 2), WIDTH - Math.floor(WIDTH / 2)]),
  h2('Checklist profil LinkedIn lengkap'),
  grid([
    ['Bagian profil', 'Cek'],
    ['Foto profil formal dan foto latar', '☐'],
    ['Headline berisi keahlian dan tujuan karier', '☐'],
    ['Bagian Tentang 3–5 kalimat', '☐'],
    ['Pengalaman (PKL, kerja, organisasi)', '☐'],
    ['Pendidikan terakhir', '☐'],
    ['Minimal 5 keahlian', '☐'],
    ['Sertifikat pelatihan ditambahkan', '☐'],
    ['URL profil sudah dirapikan', '☐'],
    ['Fitur "Terbuka untuk bekerja" aktif', '☐'],
  ], [WIDTH - 900, 900], { headerFill: COLORS.navyMid }),
  spacer(240),
  box('Setelah profil lengkap', ['Kirim link profil LinkedIn kamu di menu **Setor Tugas** pada web pelatihan, supaya panitia bisa memverifikasi akunmu.', '**Belajar Bersama, Tumbuh Bersama.**'], { width: WIDTH, fill: COLORS.goldSoft, accent: COLORS.gold }),
];

const doc = new Document({
  creator: 'Kelompok 1 MK-PM Universitas Terbuka', title: 'Panduan Membuat Akun LinkedIn', styles: STYLES, numbering: NUMBERING,
  sections: [{
    properties: { page: { size: A5, margin: MARGIN } }, footers: { default: footer('Panduan LinkedIn') },
    children: [...cover('Materi pelatihan', 'Panduan Membuat Akun LinkedIn', 'Langkah demi langkah dari daftar akun sampai melamar kerja'), ...intro, ...createAccount, ...profile, ...jobs, ...safety],
  }],
});

fs.mkdirSync('out', { recursive: true });
Packer.toBuffer(doc).then((buffer) => {
  fs.writeFileSync('out/Panduan-Membuat-Akun-LinkedIn.docx', buffer);
  console.log('out/Panduan-Membuat-Akun-LinkedIn.docx');
});
