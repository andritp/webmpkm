<?php
declare(strict_types=1);

require __DIR__ . '/../inc/scoring.php';
require __DIR__ . '/../inc/features.php';

$failures = 0;
$passes = 0;

function same(mixed $expected, mixed $actual, string $label): void
{
    global $failures, $passes;
    if ($expected === $actual) {
        $passes++;
        return;
    }
    $failures++;
    fwrite(STDERR, "FAIL: {$label}\n  expected: " . var_export($expected, true) . "\n  actual:   " . var_export($actual, true) . "\n");
}

// Certificate number
same('001/MKPM-UT/KT-JTS/2026', formatCertificateNumber(1, 2026), 'certificate number padded');
same('125/MKPM-UT/KT-JTS/2026', formatCertificateNumber(125, 2026), 'certificate number 3 digits');

// LinkedIn URL
same(true, isValidLinkedinUrl('https://www.linkedin.com/in/budi-santoso'), 'standard profile url');
same(true, isValidLinkedinUrl('https://id.linkedin.com/in/budi-santoso-123/'), 'country subdomain');
same(true, isValidLinkedinUrl('linkedin.com/in/budi'), 'missing scheme accepted');
same(false, isValidLinkedinUrl('https://facebook.com/in/budi'), 'other domain rejected');
same(false, isValidLinkedinUrl('https://www.linkedin.com/company/acme'), 'company page rejected');
same(false, isValidLinkedinUrl('https://evil.com/?q=linkedin.com/in/x'), 'domain spoof rejected');
same('https://www.linkedin.com/in/budi', normalizeLinkedinUrl('linkedin.com/in/budi'), 'normalize adds scheme and www');

// Upload validation
$allowed = ['pdf', 'docx'];
$ok = ['name' => 'CV Budi.pdf', 'size' => 2000, 'error' => UPLOAD_ERR_OK, 'tmp_name' => 'x'];
same(null, validateUploadMeta($ok, $allowed, 5000), 'valid upload');
same('File terlalu besar (maksimal 4,9 KB).', validateUploadMeta(['size' => 6000] + $ok, $allowed, 5000), 'too large');
same('Format file harus: PDF, DOCX.', validateUploadMeta(['name' => 'virus.exe'] + $ok, $allowed, 5000), 'bad extension');
same('Format file harus: PDF, DOCX.', validateUploadMeta(['name' => 'cv.pdf.php'] + $ok, $allowed, 5000), 'double extension');
same('Pilih file terlebih dahulu.', validateUploadMeta(['error' => UPLOAD_ERR_NO_FILE] + $ok, $allowed, 5000), 'no file');
same('pdf', fileExtension('Laporan.Final.PDF'), 'extension lowercased');

// Survey summary
$aspects = ['materi' => 'Materi', 'waktu' => 'Waktu'];
$rows = [['materi' => 5, 'waktu' => 3], ['materi' => 4, 'waktu' => 3], ['materi' => 5, 'waktu' => 2]];
$summary = summarizeSurvey($rows, $aspects);
same(4.67, $summary['materi']['average'], 'materi average');
same([1 => 0, 2 => 0, 3 => 0, 4 => 1, 5 => 2], $summary['materi']['distribution'], 'materi distribution');
same(2.67, $summary['waktu']['average'], 'waktu average');
same(null, summarizeSurvey([], $aspects)['materi']['average'], 'empty survey');
same('Sangat Baik', satisfactionLabel(4.5), 'label 4.5');
same('Baik', satisfactionLabel(3.6), 'label 3.6');
same('Cukup', satisfactionLabel(2.6), 'label 2.6');
same('Kurang', satisfactionLabel(2.0), 'label 2.0');

// Timer
same(false, isTimeExpired(1000, 1000 + 14 * 60, 15, 10), 'within time');
same(true, isTimeExpired(1000, 1000 + 15 * 60, 15, 10), 'time up');
same(true, isTimeExpired(1000, 1000 + 15 * 60 - 5, 15, 10), 'grace window counts as expired');
same(false, isTimeExpired(1000, 99999, 0, 10), 'timer disabled');

// Review and certificate eligibility
same(true, canViewReview(3), 'review after 3 post attempts');
same(false, canViewReview(2), 'no review while attempts remain');
same(true, isEligibleForCertificate(true, true), 'post + survey -> certificate');
same(false, isEligibleForCertificate(true, false), 'missing survey');

// Survey input: every aspect needs a rating AND a comment; general feedback is required too
$surveyAspects = [
    ['id' => 1, 'label' => 'Materi mudah dipahami', 'comment_prompt' => 'Apa yang perlu diperjelas?'],
    ['id' => 2, 'label' => 'Pemateri ramah', 'comment_prompt' => 'Ceritakan sikap pemateri'],
];
$validSurvey = [
    'rating' => [1 => '5', 2 => '4'],
    'comment' => [1 => 'Materi CV sangat jelas', 2 => 'Pemateri sabar menjawab'],
    'saran' => 'Tambah sesi simulasi wawancara',
];
$result = validateSurveyInput($surveyAspects, $validSurvey);
same([], $result['errors'], 'complete survey has no errors');
same([1 => ['rating' => 5, 'comment' => 'Materi CV sangat jelas'], 2 => ['rating' => 4, 'comment' => 'Pemateri sabar menjawab']], $result['data']['answers'], 'answers mapped by aspect id');

$result = validateSurveyInput($surveyAspects, ['comment' => [1 => 'ok banget', 2 => '   ']] + $validSurvey);
same(['comment.2' => 'Saran untuk "Pemateri ramah" wajib diisi (minimal 5 karakter).'], $result['errors'], 'blank aspect comment rejected');

$result = validateSurveyInput($surveyAspects, ['comment' => [1 => 'ok', 2 => 'Pemateri sabar']] + $validSurvey);
same(['comment.1'], array_keys($result['errors']), 'too-short comment rejected');

$result = validateSurveyInput($surveyAspects, ['rating' => [1 => '6']] + $validSurvey);
same(['rating.1', 'rating.2'], array_keys($result['errors']), 'invalid and missing ratings rejected');

$result = validateSurveyInput($surveyAspects, ['saran' => ''] + $validSurvey);
same(['saran'], array_keys($result['errors']), 'general feedback required');

// Aspect editor input
same([], validateAspectInput(['label' => 'Panitia sigap membantu', 'comment_prompt' => 'Apa kendalamu?'])['errors'], 'valid aspect');
same(['Pertanyaan wajib diisi.'], validateAspectInput(['label' => ' ', 'comment_prompt' => 'x'])['errors'], 'blank aspect label');
same('Tuliskan saranmu untuk aspek ini', validateAspectInput(['label' => 'Aspek baru', 'comment_prompt' => ''])['data']['comment_prompt'], 'default comment prompt');

// Login rate limiting: block after N failures inside the window, older failures expire
same(false, isRateLimited([], 1000, 5, 600), 'no failures -> allowed');
same(false, isRateLimited([900, 950, 960, 970], 1000, 5, 600), '4 failures -> allowed');
same(true, isRateLimited([900, 950, 960, 970, 990], 1000, 5, 600), '5 failures in window -> blocked');
same(false, isRateLimited([100, 200, 300, 400, 990], 1000, 5, 600), 'old failures expire');

echo "{$passes} passed, {$failures} failed\n";
exit($failures > 0 ? 1 : 0);
