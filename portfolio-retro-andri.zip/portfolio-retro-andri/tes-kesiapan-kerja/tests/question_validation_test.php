<?php
declare(strict_types=1);

require __DIR__ . '/../inc/question_validation.php';

$failures = 0;
$passes = 0;

function check(bool $condition, string $label): void
{
    global $failures, $passes;
    if ($condition) {
        $passes++;
        return;
    }
    $failures++;
    fwrite(STDERR, "FAIL: {$label}\n");
}

$topics = ['cv' => 'Curriculum Vitae', 'linkedin' => 'LinkedIn'];
$valid = [
    'topic' => 'cv',
    'text' => 'Bagian wajib CV adalah…',
    'option_a' => 'Data diri',
    'option_b' => 'Zodiak',
    'option_c' => 'Makanan favorit',
    'option_d' => 'Nama hewan peliharaan',
    'answer' => 'a',
];

$result = validateQuestionInput($valid, $topics);
check($result['errors'] === [], 'valid input has no errors');
check($result['data']['options'] === ['a' => 'Data diri', 'b' => 'Zodiak', 'c' => 'Makanan favorit', 'd' => 'Nama hewan peliharaan'], 'options mapped a-d');
check($result['data']['answer'] === 'a', 'answer kept');

$result = validateQuestionInput(['text' => '   '] + $valid, $topics);
check(in_array('Pertanyaan wajib diisi.', $result['errors'], true), 'blank text rejected');

$result = validateQuestionInput(['option_c' => ''] + $valid, $topics);
check(in_array('Pilihan C wajib diisi.', $result['errors'], true), 'empty option rejected');

$result = validateQuestionInput(['answer' => 'e'] + $valid, $topics);
check(in_array('Pilih kunci jawaban (A–D).', $result['errors'], true), 'invalid answer rejected');

$result = validateQuestionInput(['topic' => 'astrologi'] + $valid, $topics);
check(in_array('Pilih materi yang valid.', $result['errors'], true), 'unknown topic rejected');

$result = validateQuestionInput(['option_b' => 'Data diri'] + $valid, $topics);
check(in_array('Setiap pilihan jawaban harus berbeda.', $result['errors'], true), 'duplicate options rejected');

$result = validateQuestionInput(['text' => '  Spasi di tepi  '] + $valid, $topics);
check($result['data']['text'] === 'Spasi di tepi', 'text trimmed');

echo "{$passes} passed, {$failures} failed\n";
exit($failures > 0 ? 1 : 0);
