<?php
declare(strict_types=1);

require __DIR__ . '/../inc/xlsx.php';

$failures = 0;
$passes = 0;

function ok(bool $condition, string $label): void
{
    global $failures, $passes;
    if ($condition) {
        $passes++;
        return;
    }
    $failures++;
    fwrite(STDERR, "FAIL: {$label}\n");
}

$path = buildXlsxFile([
    'Data Peserta' => [
        'title' => 'Hasil Pre-test & Post-test',
        'columns' => [['No', 5, 'int'], ['Nama', 24, 'text'], ['WhatsApp', 16, 'text'], ['N-gain', 9, 'decimal']],
        'rows' => [
            [1, 'Siti <Nur> & "Haliza"', '6281299000002', 0.83],
            [2, 'Budi', '6281299000003', null],
        ],
    ],
]);

ok(is_file($path), 'xlsx file created');
$zip = new ZipArchive();
ok($zip->open($path) === true, 'xlsx is a valid zip');
foreach (['[Content_Types].xml', 'xl/workbook.xml', 'xl/styles.xml', 'xl/worksheets/sheet1.xml', '_rels/.rels', 'xl/_rels/workbook.xml.rels'] as $part) {
    ok($zip->locateName($part) !== false, "contains {$part}");
}
$sheet = (string) $zip->getFromName('xl/worksheets/sheet1.xml');
$workbook = (string) $zip->getFromName('xl/workbook.xml');
$zip->close();

ok(simplexml_load_string($sheet) !== false, 'sheet xml is well-formed');
ok(str_contains($sheet, 'Siti &lt;Nur&gt; &amp; &quot;Haliza&quot;'), 'special characters escaped');
ok(str_contains($sheet, '<t xml:space="preserve">6281299000002</t>'), 'phone kept as text');
ok(str_contains($sheet, '<v>0.83</v>'), 'decimal stored as number');
ok(str_contains($sheet, '<pane '), 'header row frozen');
ok(str_contains($sheet, '<autoFilter '), 'autofilter enabled');
ok(str_contains($sheet, 'width="24"'), 'column width applied');
ok(str_contains($workbook, 'name="Data Peserta"'), 'sheet name set');
ok(columnLetter(1) === 'A' && columnLetter(26) === 'Z' && columnLetter(27) === 'AA', 'column letters');
ok(sanitizeSheetName('Daftar: Hadir/Sesi [1]?') === 'Daftar Hadir Sesi 1', 'sheet name sanitized');
unlink($path);

echo "{$passes} passed, {$failures} failed\n";
exit($failures > 0 ? 1 : 0);
