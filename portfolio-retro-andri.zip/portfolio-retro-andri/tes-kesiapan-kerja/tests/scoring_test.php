<?php
declare(strict_types=1);

require __DIR__ . '/../inc/scoring.php';

$failures = 0;
$passes = 0;

function assertSame(mixed $expected, mixed $actual, string $label): void
{
    global $failures, $passes;
    if ($expected === $actual) {
        $passes++;
        return;
    }
    $failures++;
    fwrite(STDERR, "FAIL: {$label}\n  expected: " . var_export($expected, true) . "\n  actual:   " . var_export($actual, true) . "\n");
}

$questions = [
    ['id' => 1, 'topic' => 'dunia_kerja', 'answer' => 'b'],
    ['id' => 2, 'topic' => 'dunia_kerja', 'answer' => 'a'],
    ['id' => 3, 'topic' => 'cv', 'answer' => 'c'],
    ['id' => 4, 'topic' => 'cv', 'answer' => 'd'],
];

// scoreAnswers: all correct
$result = scoreAnswers($questions, [1 => 'b', 2 => 'a', 3 => 'c', 4 => 'd']);
assertSame(4, $result['correct'], 'all correct -> correct count');
assertSame(100, $result['score'], 'all correct -> score 100');

// scoreAnswers: half correct, one unanswered
$result = scoreAnswers($questions, [1 => 'b', 2 => 'c', 3 => 'c']);
assertSame(2, $result['correct'], 'half correct -> correct count');
assertSame(50, $result['score'], 'half correct -> score 50');
assertSame(['dunia_kerja' => 50, 'cv' => 50], $result['by_topic'], 'per-topic score');

// scoreAnswers: invalid option ignored, never counted as correct
$result = scoreAnswers($questions, [1 => 'z', 2 => 'a']);
assertSame(1, $result['correct'], 'invalid option not counted');

// scoreAnswers: rounding to integer
$three = array_slice($questions, 0, 3);
$result = scoreAnswers($three, [1 => 'b']);
assertSame(33, $result['score'], '1 of 3 rounds to 33');

// calculateNormalizedGain (Hake): (post - pre) / (100 - pre)
assertSame(0.5, calculateNormalizedGain(40, 70), 'gain 40 -> 70 = 0.5');
assertSame(1.0, calculateNormalizedGain(50, 100), 'gain 50 -> 100 = 1.0');
assertSame(-0.25, calculateNormalizedGain(60, 50), 'negative gain');
assertSame(null, calculateNormalizedGain(100, 100), 'pre 100 -> undefined gain');

// categorizeGain
assertSame('Tinggi', categorizeGain(0.75), 'gain 0.75 -> Tinggi');
assertSame('Sedang', categorizeGain(0.7), 'gain 0.7 -> Sedang (boundary)');
assertSame('Sedang', categorizeGain(0.3), 'gain 0.3 -> Sedang (boundary)');
assertSame('Rendah', categorizeGain(0.29), 'gain 0.29 -> Rendah');
assertSame('-', categorizeGain(null), 'null gain -> dash');

// normalizePhone: pairs pre/post records for the same participant
assertSame('6281234567890', normalizePhone('0812-3456-7890'), 'leading 0 -> 62');
assertSame('6281234567890', normalizePhone('+62 812 3456 7890'), 'plus 62 kept');
assertSame('6281234567890', normalizePhone('81234567890'), 'missing prefix -> 62');
assertSame('', normalizePhone('abc'), 'no digits -> empty');

// calculateItemAnalysis: percent of participants answering each question correctly, per test type
$submissions = [
    ['test_type' => 'pre', 'answers' => [1 => 'b', 2 => 'x', 3 => 'c', 4 => 'a']],
    ['test_type' => 'pre', 'answers' => [1 => 'a', 2 => 'x', 3 => 'c', 4 => 'a']],
    ['test_type' => 'post', 'answers' => [1 => 'b', 2 => 'a', 3 => 'c', 4 => 'd']],
];
$items = calculateItemAnalysis($questions, $submissions);
assertSame(['pre' => 50, 'post' => 100], $items[1], 'item 1: 1/2 pre, 1/1 post');
assertSame(['pre' => 0, 'post' => 100], $items[2], 'item 2: 0/2 pre, 1/1 post');
assertSame(['pre' => 0, 'post' => 100], $items[4], 'item 4');
$emptyItems = calculateItemAnalysis($questions, []);
assertSame(['pre' => null, 'post' => null], $emptyItems[1], 'no submissions -> null');

// maxAttempts: pre-test once, post-test up to three times
assertSame(1, maxAttempts('pre'), 'pre-test allows 1 attempt');
assertSame(3, maxAttempts('post'), 'post-test allows 3 attempts');
assertSame(2, remainingAttempts('post', 1), 'post after 1 attempt -> 2 left');
assertSame(0, remainingAttempts('post', 3), 'post after 3 attempts -> 0 left');
assertSame(0, remainingAttempts('pre', 1), 'pre after 1 attempt -> 0 left');
assertSame(0, remainingAttempts('post', 5), 'never negative');

// pickBestAttempts: keeps the highest score per phone + test type; ties go to the latest attempt
$rows = [
    ['id' => 1, 'phone' => '62811', 'test_type' => 'pre', 'attempt' => 1, 'score' => 40],
    ['id' => 2, 'phone' => '62811', 'test_type' => 'post', 'attempt' => 1, 'score' => 60],
    ['id' => 3, 'phone' => '62811', 'test_type' => 'post', 'attempt' => 2, 'score' => 85],
    ['id' => 4, 'phone' => '62811', 'test_type' => 'post', 'attempt' => 3, 'score' => 70],
    ['id' => 5, 'phone' => '62822', 'test_type' => 'post', 'attempt' => 1, 'score' => 50],
    ['id' => 6, 'phone' => '62822', 'test_type' => 'post', 'attempt' => 2, 'score' => 50],
];
$best = pickBestAttempts($rows);
$bestIds = array_map(static fn (array $row): int => $row['id'], $best);
sort($bestIds);
assertSame([1, 3, 6], $bestIds, 'best attempt per participant and type');
$byKey = [];
foreach ($best as $row) {
    $byKey[$row['phone'] . $row['test_type']] = $row;
}
assertSame(3, $byKey['62811post']['attempt_count'], 'attempt count attached');
assertSame([60, 85, 70], $byKey['62811post']['attempt_scores'], 'all attempt scores in order');

echo "{$passes} passed, {$failures} failed\n";
exit($failures > 0 ? 1 : 0);
