#!/usr/bin/env bash
# End-to-end smoke test against a running instance.
# Usage: BASE_URL=http://localhost:8091 ADMIN_PASS=secret bash tests/e2e_smoke.sh
# Creates a throwaway participant (phone 08199990xxxx) and removes nothing; clean up via the admin panel afterwards.
set -u

BASE="${BASE_URL:?set BASE_URL}"
ADMIN_PASS="${ADMIN_PASS:?set ADMIN_PASS}"
WORK="$(mktemp -d)"
# Native curl on Windows cannot read MSYS paths such as /tmp/..., so hand it a mixed-style path.
CURL_WORK="$(command -v cygpath >/dev/null && cygpath -m "$WORK" || echo "$WORK")"
PHONE="0819999$(printf '%05d' $((RANDOM % 100000)))"
P="$WORK/participant.jar"; A="$WORK/admin.jar"
PASS=0; FAIL=0

check() { # label, condition-exit-code
  if [ "$2" -eq 0 ]; then PASS=$((PASS + 1)); echo "  ok   $1"; else FAIL=$((FAIL + 1)); echo "  FAIL $1"; fi
}
token() { curl -s -b "$1" -c "$1" "$BASE/$2" | grep -o 'name="csrf" value="[^"]*"' | head -1 | sed 's/.*value="//;s/"//'; }
answers() { # all radio groups on the test page, first option each
  curl -s -b "$P" -c "$P" "$BASE/tes.php?type=$1" | grep -o 'name="answers\[[0-9]*\]" value="[a-d]"' | awk -F'"' '!seen[$2]++ {printf "%s=%s&", $2, $4}'
}

echo "== public pages"
for page in index.php "tes.php?type=pre" area.php materi.php hadir.php; do
  code=$(curl -s -o "$WORK/page.html" -w '%{http_code}' "$BASE/$page"); grep -qi 'fatal error\|warning:\|notice:' "$WORK/page.html"; err=$?
  [ "$code" = 200 ] && [ "$err" -ne 0 ]; check "$page renders" $?
done

echo "== admin login and open post-test"
T=$(token "$A" admin/login.php)
code=$(curl -s -b "$A" -c "$A" -o /dev/null -w '%{redirect_url}' -X POST "$BASE/admin/login.php" --data-urlencode "csrf=$T" --data-urlencode "password=$ADMIN_PASS")
[[ "$code" == *admin/index.php ]]; check "admin login" $?
curl -s -b "$A" "$BASE/admin/index.php" | grep -q 'Post-test dibuka'; post_open=$?
if [ $post_open -ne 0 ]; then T=$(token "$A" admin/index.php); curl -s -b "$A" -o /dev/null -X POST "$BASE/admin/index.php" --data "csrf=$T&toggle=post"; fi

echo "== participant flow ($PHONE)"
for type in pre post post; do
  T=$(token "$P" "tes.php?type=$type"); body="$(answers $type)csrf=$T&type=$type&name=Uji+Otomatis&phone=$PHONE&gender=L&age=21&kelurahan=Jatisampurna"
  code=$(curl -s -b "$P" -c "$P" -o /dev/null -w '%{redirect_url}' -X POST "$BASE/kirim.php" --data "$body")
  [[ "$code" == *hasil.php ]]; check "submit $type" $?
done
curl -s -b "$P" "$BASE/hasil.php" | grep -q 'Percobaan 2'; check "result shows attempts" $?
curl -s -b "$P" "$BASE/area.php" | grep -q 'Halo, Uji Otomatis'; check "area peserta" $?

T=$(token "$P" kuesioner.php)
curl -s -b "$P" "$BASE/kuesioner.php" | grep -o 'name="rating\[[0-9]*\]" value="4"' | sed 's/.*rating\[\([0-9]*\)\].*/\1/' | sort -u > "$WORK/aspects"
survey="csrf=$T&saran=Uji+otomatis+saran+umum"; while read -r id; do survey="$survey&rating%5B$id%5D=4&comment%5B$id%5D=Saran+uji+otomatis"; done < "$WORK/aspects"
curl -s -b "$P" -c "$P" -o /dev/null -X POST "$BASE/kuesioner.php" --data "$survey"
curl -s -b "$P" "$BASE/kuesioner.php" | grep -q 'Terima kasih atas penilaianmu'; check "survey saved ($(wc -l < "$WORK/aspects") aspects)" $?
curl -s -b "$P" "$BASE/sertifikat.php" | grep -q 'MKPM-UT/KT-JTS'; check "certificate issued" $?

printf '%%PDF-1.4 smoke' > "$WORK/cv.pdf"
T=$(token "$P" tugas.php)
curl -s -b "$P" -c "$P" -o /dev/null -X POST "$BASE/tugas.php" -F "csrf=$T" -F "linkedin_url=linkedin.com/in/uji-otomatis" -F "cv=@$CURL_WORK/cv.pdf;filename=cv.pdf"
curl -s -b "$P" "$BASE/tugas.php" | grep -q 'Terkirim: cv.pdf'; check "assignment upload" $?
code=$(curl -s -o /dev/null -w '%{http_code}' "$BASE/uploads/"); [ "$code" != 200 ]; check "uploads folder not browsable ($code)" $?
code=$(curl -s -o /dev/null -w '%{http_code}' "$BASE/config.php"); body=$(curl -s "$BASE/config.php"); [[ "$body" != *admin_password_hash* ]]; check "config.php not exposed ($code)" $?

echo "== admin pages and exports"
for page in index peserta bank-soal soal hadir materi penilaian kuesioner kuesioner-atur qr pengaturan; do
  code=$(curl -s -b "$A" -o "$WORK/a.html" -w '%{http_code}' "$BASE/admin/$page.php"); grep -qi 'fatal error\|warning:\|notice:' "$WORK/a.html"; err=$?
  [ "$code" = 200 ] && [ "$err" -ne 0 ]; check "admin/$page" $?
done
for export in "export.php" "kuesioner.php?export=csv"; do
  curl -s -b "$A" -o "$WORK/x.xlsx" "$BASE/admin/$export"; head -c 2 "$WORK/x.xlsx" | grep -q 'PK'; check "excel $export" $?
done
if [ $post_open -ne 0 ]; then T=$(token "$A" admin/index.php); curl -s -b "$A" -o /dev/null -X POST "$BASE/admin/index.php" --data "csrf=$T&toggle=post"; fi

rm -rf "$WORK"
echo "== $PASS passed, $FAIL failed (test participant phone: $PHONE)"
[ "$FAIL" -eq 0 ]
