<?php
declare(strict_types=1);

// Seeds fictional demo participants so the admin panel can be previewed locally.
// Usage: php tests/seed_demo.php   (remove later from Pengaturan → Hapus semua data)

$_SESSION = [];
require __DIR__ . '/../inc/bootstrap.php';

const DEMO_PARTICIPANTS = [
    ['Rizky Pratama', 'L', 19, 'Jatisampurna', 0.35, 0.85],
    ['Siti Nurhaliza', 'P', 21, 'Jatiranggon', 0.45, 0.90],
    ['Dimas Saputra', 'L', 22, 'Jatikarya', 0.30, 0.70],
    ['Putri Ayu', 'P', 20, 'Jatiraden', 0.55, 0.95],
    ['Fajar Nugroho', 'L', 24, 'Jatisampurna', 0.40, 0.60],
    ['Nabila Zahra', 'P', 18, 'Jatiranggon', 0.25, 0.80],
    ['Bagas Kurniawan', 'L', 23, 'Jatikarya', 0.50, 0.75],
    ['Anisa Rahma', 'P', 19, 'Jatiraden', 0.35, null],
    ['Yoga Permana', 'L', 25, 'Jatisampurna', 0.60, 0.65],
    ['Intan Permata', 'P', 22, 'Jatiranggon', 0.30, null],
];

$questions = getQuestions();
mt_srand(2026);

$insert = db()->prepare('INSERT INTO submissions
    (test_type, attempt, name, phone, gender, age, kelurahan, correct, total, score, by_topic, answers, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');

foreach (DEMO_PARTICIPANTS as $index => [$name, $gender, $age, $kelurahan, $preRate, $postRate]) {
    $phone = normalizePhone(sprintf('08129900%04d', $index + 1));
    foreach (['pre' => $preRate, 'post' => $postRate] as $type => $rate) {
        if ($rate === null) {
            continue;
        }
        $answers = [];
        foreach ($questions as $question) {
            $isCorrect = mt_rand() / mt_getrandmax() < $rate;
            $answers[$question['id']] = $isCorrect ? $question['answer'] : ($question['answer'] === 'a' ? 'c' : 'a');
        }
        $result = scoreAnswers($questions, $answers);
        $timestamp = date('Y-m-d H:i:s', strtotime($type === 'pre' ? '-7 days' : '-1 day') + $index * 300);
        $insert->execute([$type, 1, $name, $phone, $gender, $age, $kelurahan, $result['correct'], $result['total'],
            $result['score'], json_encode($result['by_topic']), json_encode($answers), $timestamp]);
    }
}
setSetting('post_open', '1');
echo 'Seeded ' . count(DEMO_PARTICIPANTS) . " demo participants.\n";
