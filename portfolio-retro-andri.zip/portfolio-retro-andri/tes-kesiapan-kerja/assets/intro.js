'use strict';

(function initIntro() {
  const intro = document.getElementById('intro');
  if (!intro) return;

  const INTRO_DURATION_MS = 4200;
  const EXIT_DURATION_MS = 900;
  let hasExited = false;

  function rememberSeen() {
    try {
      sessionStorage.setItem('intro_seen', '1');
    } catch (error) {
      console.warn('sessionStorage unavailable; intro will replay next visit', error);
    }
  }

  function exitIntro() {
    if (hasExited) return;
    hasExited = true;
    rememberSeen();
    intro.classList.add('is-leaving');
    document.documentElement.classList.remove('intro-lock');
    setTimeout(() => intro.remove(), EXIT_DURATION_MS);
  }

  const autoExitTimer = setTimeout(exitIntro, INTRO_DURATION_MS);
  document.getElementById('intro-skip').addEventListener('click', () => {
    clearTimeout(autoExitTimer);
    exitIntro();
  });
  document.addEventListener('keydown', (event) => {
    if (event.key !== 'Escape' && event.key !== 'Enter') return;
    clearTimeout(autoExitTimer);
    exitIntro();
  });
})();
