'use strict';

(function initTestForm() {
  const form = document.getElementById('test-form');
  if (!form) return;

  const MIN_LOADING_MS = 2600;
  const LOADING_STEPS = [
    'Memverifikasi data peserta',
    'Mengecek riwayat tes',
    `Menyiapkan ${form.dataset.count} soal`,
    'Mengacak urutan soal',
  ];
  const PREFERS_REDUCED_MOTION = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  const element = (id) => document.getElementById(id);
  const stepIdentity = element('step-identity');
  const stepQuestions = element('step-questions');
  const identityError = element('identity-error');
  const loadingOverlay = element('loading-overlay');
  const loaderStatus = element('loader-status');
  const loaderFill = element('loader-fill');
  const confirmModal = element('confirm-modal');
  const progress = element('progress');
  const progressBar = element('progress-bar');
  const answeredCount = element('answered-count');
  const formError = element('form-error');
  const questions = Array.from(form.querySelectorAll('[data-question]'));
  const identityFields = Array.from(stepIdentity.querySelectorAll('input, select'));
  let isSubmitting = false;
  let isTimedOut = false;
  const DRAFT_KEY = `tkk_draft_${form.dataset.type}`;
  const IDENTITY_FIELDS = ['name', 'phone', 'gender', 'age', 'kelurahan'];
  const TIMER_WARNING_SECONDS = 60;

  const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  function validateIdentity() {
    const invalidField = identityFields.find((field) => !field.checkValidity());
    if (!invalidField) return true;
    identityError.textContent = 'Lengkapi data peserta terlebih dahulu.';
    invalidField.focus();
    invalidField.reportValidity();
    return false;
  }

  async function checkAttempts() {
    const body = new FormData();
    body.append('csrf', form.querySelector('[name=csrf]').value);
    body.append('type', form.dataset.type);
    body.append('phone', form.querySelector('[name=phone]').value);
    const response = await fetch('cek.php', { method: 'POST', body });
    const result = await response.json();
    if (!result.success) throw new Error(result.error || 'Gagal memeriksa data peserta.');
    return result.data;
  }

  async function playLoading() {
    const stepDuration = PREFERS_REDUCED_MOTION ? 150 : MIN_LOADING_MS / LOADING_STEPS.length;
    for (let index = 0; index < LOADING_STEPS.length; index++) {
      loaderStatus.textContent = LOADING_STEPS[index];
      loaderFill.style.width = `${Math.round(((index + 1) / LOADING_STEPS.length) * 100)}%`;
      await wait(stepDuration);
    }
  }

  function resetLoading() {
    loaderFill.style.width = '0';
    loaderStatus.textContent = LOADING_STEPS[0];
  }

  function openConfirm(attempts) {
    element('confirm-attempt').textContent = `${attempts.attemptsUsed + 1}/${attempts.maxAttempts}`;
    element('confirm-label').textContent = form.dataset.label;
    element('confirm-name').textContent = form.querySelector('[name=name]').value.trim();
    confirmModal.hidden = false;
    element('confirm-start').focus();
  }

  function showQuestions() {
    stepIdentity.hidden = true;
    stepQuestions.hidden = false;
    progress.hidden = false;
    stepQuestions.classList.add('step-enter');
    updateProgress();
    window.scrollTo({ top: 0, behavior: PREFERS_REDUCED_MOTION ? 'auto' : 'smooth' });
  }

  async function handleIdentityNext() {
    identityError.textContent = '';
    if (!validateIdentity()) return;

    loadingOverlay.hidden = false;
    try {
      const [attempts] = await Promise.all([checkAttempts(), playLoading()]);
      loadingOverlay.hidden = true;
      resetLoading();
      if (attempts.alreadySubmitted) {
        identityError.textContent = attempts.message;
        return;
      }
      openConfirm(attempts);
    } catch (error) {
      console.error('Identity check failed', error);
      loadingOverlay.hidden = true;
      resetLoading();
      identityError.textContent = error.message || 'Terjadi kesalahan. Coba lagi.';
    }
  }

  function isAnswered(question) {
    return question.querySelector('input[type=radio]:checked') !== null;
  }

  function updateProgress() {
    const answered = questions.filter(isAnswered).length;
    progressBar.style.width = `${Math.round((answered / questions.length) * 100)}%`;
    answeredCount.textContent = `${answered} / ${questions.length} terjawab`;
  }

  element('identity-next').addEventListener('click', handleIdentityNext);
  stepIdentity.addEventListener('keydown', (event) => {
    if (event.key !== 'Enter' || event.target.tagName === 'BUTTON') return;
    event.preventDefault();
    handleIdentityNext();
  });
  element('confirm-cancel').addEventListener('click', () => { confirmModal.hidden = true; });
  element('confirm-start').addEventListener('click', async () => {
    confirmModal.hidden = true;
    showQuestions();
    await startTimer();
  });
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && !confirmModal.hidden) confirmModal.hidden = true;
  });

  form.addEventListener('change', (event) => {
    const question = event.target.closest('[data-question]');
    if (question) question.classList.remove('missing');
    formError.textContent = '';
    updateProgress();
    saveDraft();
  });
  form.addEventListener('input', (event) => {
    if (IDENTITY_FIELDS.includes(event.target.name)) saveDraft();
  });

  form.addEventListener('submit', (event) => {
    if (isSubmitting || stepQuestions.hidden) {
      event.preventDefault();
      return;
    }
    const missing = questions.filter((question) => !isAnswered(question));
    if (missing.length > 0 && !isTimedOut) {
      event.preventDefault();
      missing.forEach((question) => question.classList.add('missing'));
      formError.textContent = `Masih ada ${missing.length} soal yang belum dijawab.`;
      missing[0].scrollIntoView({ behavior: 'smooth', block: 'center' });
      return;
    }
    isSubmitting = true;
    form.querySelector('button[type=submit]').textContent = 'Mengirim…';
  });

  // ---------- autosave: keeps answers if the phone dies or the page reloads ----------
  function readDraft() {
    try {
      return JSON.parse(localStorage.getItem(DRAFT_KEY) || 'null');
    } catch (error) {
      console.warn('Draft unavailable', error);
      return null;
    }
  }

  function saveDraft() {
    const identity = Object.fromEntries(IDENTITY_FIELDS.map((name) => [name, form.elements[name].value]));
    const answers = Object.fromEntries(
      Array.from(form.querySelectorAll('input[type=radio]:checked')).map((input) => [input.name, input.value])
    );
    try {
      localStorage.setItem(DRAFT_KEY, JSON.stringify({ identity, answers, savedAt: Date.now() }));
    } catch (error) {
      console.warn('Draft could not be saved', error);
    }
  }

  function restoreDraft() {
    const draft = readDraft();
    if (!draft) return;
    IDENTITY_FIELDS.forEach((name) => {
      // A draft is newer than the session prefill; only a server validation round-trip (skipIntro) should win over it.
      const keepServerValue = form.dataset.skipIntro === '1' && form.elements[name].value;
      if (draft.identity && draft.identity[name] && !keepServerValue) form.elements[name].value = draft.identity[name];
    });
    let restoredAnswers = 0;
    Object.entries(draft.answers || {}).forEach(([name, value]) => {
      const input = form.querySelector(`input[type=radio][name="${CSS.escape(name)}"][value="${CSS.escape(value)}"]`);
      if (input && !input.checked) {
        input.checked = true;
        restoredAnswers++;
      }
    });
    if (restoredAnswers > 0) element('draft-notice').hidden = false;
  }

  // ---------- timer ----------
  async function startTimer() {
    const body = new FormData();
    body.append('csrf', form.querySelector('[name=csrf]').value);
    body.append('type', form.dataset.type);
    body.append('action', 'start');
    try {
      const result = await (await fetch('cek.php', { method: 'POST', body })).json();
      if (!result.success || result.data.remainingSeconds === null) return;
      runCountdown(result.data.remainingSeconds);
    } catch (error) {
      console.error('Timer could not start', error);
    }
  }

  function runCountdown(totalSeconds) {
    const timer = element('timer');
    const timerValue = element('timer-value');
    const endsAt = Date.now() + totalSeconds * 1000;
    timer.hidden = false;

    function tick() {
      const remaining = Math.max(0, Math.round((endsAt - Date.now()) / 1000));
      const minutes = String(Math.floor(remaining / 60)).padStart(2, '0');
      const seconds = String(remaining % 60).padStart(2, '0');
      timerValue.textContent = `${minutes}:${seconds}`;
      timer.classList.toggle('is-warning', remaining <= TIMER_WARNING_SECONDS);
      if (remaining > 0) return;
      clearInterval(intervalId);
      submitOnTimeout();
    }
    const intervalId = setInterval(tick, 1000);
    tick();
  }

  function submitOnTimeout() {
    if (isSubmitting) return;
    isTimedOut = true;
    element('timed-out').value = '1';
    formError.textContent = 'Waktu habis. Jawaban dikirim otomatis…';
    form.requestSubmit();
  }

  restoreDraft();

  // Returning from a server-side validation error: answers are already filled, go straight to questions.
  // Identity stays visible so any server-reported identity error can still be fixed.
  if (form.dataset.skipIntro === '1') {
    showQuestions();
    stepIdentity.hidden = false;
    element('identity-next').hidden = true;
  }
})();
