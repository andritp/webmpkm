'use strict';

(function initSurveyForm() {
  const form = document.getElementById('survey-form');
  if (!form) return;

  const minLength = Number(form.dataset.minLength);
  const sections = Array.from(form.querySelectorAll('[data-aspect]'));
  const doneCounter = document.getElementById('survey-done');
  const formError = document.getElementById('survey-form-error');

  function sectionProblem(section) {
    const ratingInputs = section.querySelectorAll('input[type=radio]');
    const textarea = section.querySelector('textarea');
    const label = section.querySelector('legend').textContent.replace(/^\s*[\d✎]+/, '').replace('*', '').trim();
    if (ratingInputs.length > 0 && !section.querySelector('input[type=radio]:checked')) {
      return `Beri nilai 1–5 untuk "${label}".`;
    }
    if (textarea.value.trim().length < minLength) {
      return section.hasAttribute('data-general')
        ? `Kritik dan saran umum wajib diisi (minimal ${minLength} karakter).`
        : `Saran untuk "${label}" wajib diisi (minimal ${minLength} karakter).`;
    }
    return '';
  }

  function refreshSection(section, showError) {
    const problem = sectionProblem(section);
    section.classList.toggle('is-complete', problem === '');
    if (problem === '' || showError) {
      section.classList.toggle('has-error', problem !== '');
      section.querySelector('[data-error]').textContent = problem;
    }
    return problem;
  }

  function refreshCounter() {
    doneCounter.textContent = String(sections.filter((section) => sectionProblem(section) === '').length);
  }

  form.addEventListener('input', (event) => {
    const section = event.target.closest('[data-aspect]');
    if (section) refreshSection(section, false);
    formError.textContent = '';
    refreshCounter();
  });
  form.addEventListener('change', (event) => {
    const section = event.target.closest('[data-aspect]');
    if (section) refreshSection(section, false);
    refreshCounter();
  });

  form.addEventListener('submit', (event) => {
    const incomplete = sections.filter((section) => refreshSection(section, true) !== '');
    if (incomplete.length === 0) {
      form.querySelector('button[type=submit]').textContent = 'Mengirim…';
      return;
    }
    event.preventDefault();
    formError.textContent = `Kuesioner belum bisa dikirim: ${incomplete.length} bagian belum lengkap. Semua nilai dan saran wajib diisi.`;
    incomplete[0].scrollIntoView({ behavior: 'smooth', block: 'center' });
    const firstEmpty = incomplete[0].querySelector('input[type=radio]:not(:checked)') && !incomplete[0].querySelector('input[type=radio]:checked')
      ? incomplete[0].querySelector('input[type=radio]')
      : incomplete[0].querySelector('textarea');
    setTimeout(() => firstEmpty.focus({ preventScroll: true }), 400);
  });

  sections.forEach((section) => section.classList.toggle('is-complete', sectionProblem(section) === ''));
  refreshCounter();
  const serverErrors = document.getElementById('survey-errors');
  if (serverErrors) serverErrors.focus();
})();
