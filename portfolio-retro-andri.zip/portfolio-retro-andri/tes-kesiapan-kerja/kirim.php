<?php
declare(strict_types=1);
require __DIR__ . '/inc/bootstrap.php';

const MIN_AGE = 13;
const MAX_AGE = 40;
const MIN_PHONE_DIGITS = 10;

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('index.php');
}
verifyCsrf();

$testType = (string) ($_POST['type'] ?? '');
if (!array_key_exists($testType, TEST_TYPES) || !isTestOpen($testType)) {
    redirect('index.php');
}

$input = [
    'name' => trim((string) ($_POST['name'] ?? '')),
    'phone' => trim((string) ($_POST['phone'] ?? '')),
    'gender' => (string) ($_POST['gender'] ?? ''),
    'age' => (string) ($_POST['age'] ?? ''),
    'kelurahan' => trim((string) ($_POST['kelurahan'] ?? '')),
    'answers' => array_map('strval', (array) ($_POST['answers'] ?? [])),
];
$questions = getQuestions();
$phone = normalizePhone($input['phone']);
$startedAt = (int) ($_SESSION['test_started'][$testType] ?? 0);
$isTimedOut = ($_POST['timed_out'] ?? '') === '1' && $startedAt > 0
    && isTimeExpired($startedAt, time(), testDurationMinutes(), TIMER_GRACE_SECONDS);
$errors = validateSubmission($input, $phone, $isTimedOut ? 0 : count($questions));

$attemptsUsed = $errors ? 0 : countAttempts($phone, $testType);
if (!$errors && remainingAttempts($testType, $attemptsUsed) === 0) {
    $errors[] = attemptsExhaustedMessage($testType);
}
if ($errors) {
    $_SESSION['form_errors'] = $errors;
    $_SESSION['form_old'] = $input;
    redirect('tes.php?type=' . $testType);
}

$answers = [];
foreach ($input['answers'] as $questionId => $optionKey) {
    $answers[(int) $questionId] = $optionKey;
}
$result = scoreAnswers($questions, $answers);

try {
    $statement = db()->prepare('INSERT INTO submissions
        (test_type, attempt, name, phone, gender, age, kelurahan, correct, total, score, by_topic, answers, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
    $statement->execute([
        $testType, $attemptsUsed + 1, $input['name'], $phone, $input['gender'], (int) $input['age'], $input['kelurahan'],
        $result['correct'], $result['total'], $result['score'],
        json_encode($result['by_topic']), json_encode($answers), date('Y-m-d H:i:s'),
    ]);
} catch (PDOException $exception) {
    error_log('Failed to save submission: ' . $exception->getMessage());
    $_SESSION['form_errors'] = ['Jawaban gagal disimpan. Coba kirim ulang atau hubungi panitia.'];
    $_SESSION['form_old'] = $input;
    redirect('tes.php?type=' . $testType);
}

$_SESSION['last_submission_id'] = (int) db()->lastInsertId();
unset($_SESSION['test_started'][$testType]);
$_SESSION['participant'] = ['phone' => $phone, 'name' => $input['name']];
// Prefills the identity form when the participant retakes the post-test.
$_SESSION['last_identity'] = array_intersect_key($input, array_flip(['name', 'phone', 'gender', 'age', 'kelurahan']));
redirect('hasil.php');

/**
 * @param array<string, mixed> $input
 * @return list<string>
 */
function validateSubmission(array $input, string $phone, int $questionCount): array
{
    $errors = [];
    if ($input['name'] === '' || mb_strlen($input['name']) > 100) {
        $errors[] = 'Nama lengkap wajib diisi.';
    }
    if (strlen($phone) < MIN_PHONE_DIGITS) {
        $errors[] = 'Nomor WhatsApp tidak valid.';
    }
    if (!in_array($input['gender'], ['L', 'P'], true)) {
        $errors[] = 'Pilih jenis kelamin.';
    }
    $age = filter_var($input['age'], FILTER_VALIDATE_INT);
    if ($age === false || $age < MIN_AGE || $age > MAX_AGE) {
        $errors[] = 'Usia harus antara ' . MIN_AGE . '–' . MAX_AGE . ' tahun.';
    }
    if ($input['kelurahan'] === '') {
        $errors[] = 'Kelurahan wajib diisi.';
    }
    $missing = $questionCount - count($input['answers']);
    if ($missing > 0) {
        $errors[] = "Masih ada {$missing} soal yang belum dijawab.";
    }
    return $errors;
}

