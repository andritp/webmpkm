<?php
declare(strict_types=1);
require __DIR__ . '/inc/bootstrap.php';

renderHeader(APP_TITLE);
?>
<div class="intro" id="intro" role="dialog" aria-label="Selamat datang">
  <div class="intro-glow"></div>
  <div class="intro-grid"></div>
  <div class="intro-body">
    <div class="intro-logos">
      <span class="intro-logo"><img src="assets/logo-ut.png" alt="Universitas Terbuka"></span>
      <span class="intro-x">×</span>
      <span class="intro-logo"><img src="assets/logo-karang-taruna.png" alt="Karang Taruna"></span>
    </div>
    <h1 class="intro-title">
      <span class="word" style="--i: 0">Belajar</span>
      <span class="word" style="--i: 1">Bersama,</span><br>
      <span class="word gold" style="--i: 2">Tumbuh</span>
      <span class="word gold" style="--i: 3">Bersama</span>
    </h1>
    <span class="intro-line"></span>
    <p class="intro-sub">Universitas Terbuka <b>×</b> Karang Taruna Kecamatan Jatisampurna</p>
  </div>
  <div class="intro-support"><span>Supported by</span><img src="assets/logo-aytindeso-light.png" alt="AYTINDESO"></div>
  <button type="button" class="intro-skip" id="intro-skip">Lewati ›</button>
</div>
<script>
  // Runs before first paint: returning visitors in the same session skip the intro without a flash.
  (function () {
    var seen = false;
    try { seen = sessionStorage.getItem('intro_seen') === '1'; } catch (error) { seen = false; }
    var reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (seen || reduced) { document.getElementById('intro').remove(); }
    else { document.documentElement.classList.add('intro-lock'); }
  })();
</script>
<section class="hero">
  <p class="kicker">Program Pemberdayaan Masyarakat</p>
  <h1>Tes <span class="hl">Kesiapan Kerja</span> Pemuda Karang Taruna</h1>
  <p class="lead">Kerjakan <b>pre-test</b> sebelum pelatihan dimulai dan <b>post-test</b> setelah pelatihan selesai.
    Hasilnya membantu tim mengukur peningkatan pemahaman kamu.</p>
  <ul class="facts">
    <li><b><?= count(getQuestions()) ?></b> soal pilihan ganda</li>
    <li><b>± 15</b> menit</li>
    <li><b><?= count(TOPICS) ?></b> materi</li>
  </ul>
</section>

<section class="test-grid">
  <?php foreach (TEST_TYPES as $type => $label): $open = isTestOpen($type); ?>
    <article class="test-card <?= $open ? '' : 'is-closed' ?>">
      <div class="test-step"><?= $type === 'pre' ? '01' : '02' ?></div>
      <h2><?= e($label) ?></h2>
      <p><?= $type === 'pre'
          ? 'Dikerjakan sebelum materi pelatihan disampaikan.'
          : 'Dikerjakan setelah seluruh materi dan praktik selesai.' ?></p>
      <?php if ($open): ?>
        <a class="btn btn-primary" href="tes.php?type=<?= $type ?>">Mulai <?= e($label) ?></a>
      <?php else: ?>
        <span class="btn btn-disabled">Belum dibuka panitia</span>
      <?php endif; ?>
    </article>
  <?php endforeach; ?>
</section>

<section class="topics-box">
  <h3>Materi yang diujikan</h3>
  <ol>
    <?php foreach (TOPICS as $topicLabel): ?><li><?= e($topicLabel) ?></li><?php endforeach; ?>
  </ol>
</section>
<script src="<?= e(asset('assets/intro.js')) ?>"></script>
<?php renderFooter();
