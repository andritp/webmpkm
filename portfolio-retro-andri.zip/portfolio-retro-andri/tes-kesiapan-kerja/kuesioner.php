<?php
declare(strict_types=1);
require __DIR__ . '/inc/bootstrap.php';

const SCALE_LABELS = [1 => 'Sangat kurang', 2 => 'Kurang', 3 => 'Cukup', 4 => 'Baik', 5 => 'Sangat baik'];

$participant = requireParticipant();
if (!participantAttempts($participant['phone'])['post']) {
    renderHeader('Kuesioner — ' . APP_TITLE);
    echo '<div class="notice">Kuesioner bisa diisi setelah kamu mengerjakan post-test. <a href="area.php">Kembali</a></div>';
    renderFooter();
    exit;
}

$aspects = getSurveyAspects();
$survey = findSurvey($participant['phone']);
$errors = [];
$old = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $survey === null) {
    verifyCsrf();
    $old = $_POST;
    $result = validateSurveyInput($aspects, $_POST);
    $errors = $result['errors'];
    if (!$errors) {
        try {
            saveSurveyResponse($participant['phone'], $participant['name'], $result['data']);
            redirect('kuesioner.php');
        } catch (RuntimeException $exception) {
            error_log($exception->getMessage() . ': ' . ($exception->getPrevious()?->getMessage() ?? ''));
            $errors['form'] = 'Kuesioner gagal disimpan. Coba kirim ulang.';
        }
    }
}
$oldValue = static fn (string $group, int $id): string => (string) ($old[$group][$id] ?? '');

renderHeader('Kuesioner — ' . APP_TITLE);
?>
<?php if ($survey !== null): ?>
  <section class="card result center">
    <div class="done-badge">✓</div>
    <h1 class="page-title">Terima kasih atas penilaianmu!</h1>
    <p class="hint">Masukanmu membantu kami memperbaiki pelatihan berikutnya. Sertifikat kamu sudah bisa diunduh.</p>
    <p class="result-actions"><a class="btn btn-primary" href="sertifikat.php">Unduh sertifikat</a><a class="btn" href="area.php">Area Peserta</a></p>
  </section>
<?php else: ?>
  <form method="post" class="card survey-form" id="survey-form" novalidate data-min-length="<?= MIN_COMMENT_LENGTH ?>">
    <?= csrfField() ?>
    <p class="kicker">Kuesioner kepuasan peserta</p>
    <h1 class="page-title">Bagaimana pengalamanmu mengikuti pelatihan?</h1>
    <p class="hint">Beri nilai 1 (sangat kurang) sampai 5 (sangat baik) <b>dan tuliskan saran</b> untuk setiap pertanyaan.
      Semua kolom <b>wajib diisi</b>, minimal <?= MIN_COMMENT_LENGTH ?> karakter. Jawaban jujurmu sangat membantu.</p>
    <div class="survey-progress"><span id="survey-done">0</span>/<?= count($aspects) + 1 ?> bagian lengkap</div>

    <?php if ($errors): ?>
      <div class="alert" id="survey-errors" tabindex="-1">
        <b>Kuesioner belum bisa dikirim. Lengkapi bagian berikut:</b>
        <ul><?php foreach ($errors as $error): ?><li><?= e($error) ?></li><?php endforeach; ?></ul>
      </div>
    <?php endif; ?>

    <?php foreach ($aspects as $number => $aspect): $id = $aspect['id']; ?>
      <fieldset class="rating <?= isset($errors["rating.{$id}"]) || isset($errors["comment.{$id}"]) ? 'has-error' : '' ?>" data-aspect>
        <legend><span class="q-num"><?= $number + 1 ?></span><?= e($aspect['label']) ?></legend>
        <div class="rating-scale">
          <?php foreach (SCALE_LABELS as $value => $scaleLabel): ?>
            <label title="<?= e($scaleLabel) ?>">
              <input type="radio" name="rating[<?= $id ?>]" value="<?= $value ?>" required <?= $oldValue('rating', $id) === (string) $value ? 'checked' : '' ?>>
              <span><b><?= $value ?></b><small><?= e($scaleLabel) ?></small></span>
            </label>
          <?php endforeach; ?>
        </div>
        <label class="comment-field">Saran <span class="required">*</span>
          <textarea name="comment[<?= $id ?>]" rows="2" required minlength="<?= MIN_COMMENT_LENGTH ?>" maxlength="<?= MAX_COMMENT_LENGTH ?>" placeholder="<?= e($aspect['comment_prompt']) ?>"><?= e($oldValue('comment', $id)) ?></textarea>
        </label>
        <p class="field-error" data-error><?= e($errors["rating.{$id}"] ?? $errors["comment.{$id}"] ?? '') ?></p>
      </fieldset>
    <?php endforeach; ?>

    <fieldset class="rating <?= isset($errors['saran']) ? 'has-error' : '' ?>" data-aspect data-general>
      <legend><span class="q-num">✎</span>Kritik dan saran umum <span class="required">*</span></legend>
      <textarea name="saran" rows="4" required minlength="<?= MIN_COMMENT_LENGTH ?>" maxlength="<?= MAX_GENERAL_FEEDBACK_LENGTH ?>" placeholder="Apa yang paling bermanfaat? Apa yang perlu diperbaiki untuk pelatihan berikutnya?"><?= e((string) ($old['saran'] ?? '')) ?></textarea>
      <p class="field-error" data-error><?= e($errors['saran'] ?? '') ?></p>
    </fieldset>

    <p class="form-error" id="survey-form-error" role="alert"></p>
    <button class="btn btn-primary btn-lg" type="submit">Kirim kuesioner</button>
  </form>
  <script src="<?= e(asset('assets/survey.js')) ?>"></script>
<?php endif; ?>
<?php renderFooter();
