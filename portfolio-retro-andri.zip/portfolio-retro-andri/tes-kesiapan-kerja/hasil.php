<?php
declare(strict_types=1);
require __DIR__ . '/inc/bootstrap.php';

$submissionId = (int) ($_SESSION['last_submission_id'] ?? 0);
if ($submissionId === 0) {
    redirect('index.php');
}

$statement = db()->prepare('SELECT * FROM submissions WHERE id = ?');
$statement->execute([$submissionId]);
$submission = $statement->fetch();
if (!$submission) {
    redirect('index.php');
}

$byTopic = json_decode($submission['by_topic'], true) ?: [];
$preScore = null;
if ($submission['test_type'] === 'post') {
    $preStatement = db()->prepare("SELECT score FROM submissions WHERE phone = ? AND test_type = 'pre'");
    $preStatement->execute([$submission['phone']]);
    $preValue = $preStatement->fetchColumn();
    $preScore = $preValue === false ? null : (int) $preValue;
}
$attemptStatement = db()->prepare('SELECT attempt, score FROM submissions WHERE phone = ? AND test_type = ? ORDER BY attempt');
$attemptStatement->execute([$submission['phone'], $submission['test_type']]);
$attemptScores = array_map('intval', array_column($attemptStatement->fetchAll(), 'score', 'attempt'));
$bestScore = max($attemptScores);
$attemptLimit = maxAttempts($submission['test_type']);
$remaining = remainingAttempts($submission['test_type'], count($attemptScores));
$canRetry = $remaining > 0 && isTestOpen($submission['test_type']);
$gain = $preScore === null ? null : calculateNormalizedGain($preScore, $bestScore);

renderHeader('Hasil ' . TEST_TYPES[$submission['test_type']]);
?>
<section class="result card">
  <p class="kicker">Jawaban terkirim</p>
  <h1>Terima kasih, <?= e($submission['name']) ?>!</h1>
  <p class="lead">Hasil <?= e(TEST_TYPES[$submission['test_type']]) ?> kamu<?= $attemptLimit > 1 ? ' — percobaan ke-' . (int) $submission['attempt'] : '' ?>:</p>

  <div class="score-ring" style="--score: <?= (int) $submission['score'] ?>">
    <span><?= (int) $submission['score'] ?></span><small>dari 100</small>
  </div>
  <p class="center"><?= (int) $submission['correct'] ?> dari <?= (int) $submission['total'] ?> soal benar</p>
  <?php if ($attemptLimit > 1): ?>
    <div class="attempt-strip">
      <?php for ($attempt = 1; $attempt <= $attemptLimit; $attempt++): $score = $attemptScores[$attempt] ?? null; ?>
        <div class="attempt <?= $score === null ? 'is-empty' : '' ?> <?= $score !== null && $score === $bestScore ? 'is-best' : '' ?> <?= $attempt === (int) $submission['attempt'] ? 'is-current' : '' ?>">
          <small>Percobaan <?= $attempt ?></small><b><?= $score ?? '–' ?></b>
          <?php if ($score !== null && $score === $bestScore): ?><em>Terbaik</em><?php endif; ?>
        </div>
      <?php endfor; ?>
    </div>
    <p class="hint center">Nilai terbaik (<b><?= $bestScore ?></b>) yang dipakai sebagai hasil akhir. Sisa kesempatan: <b><?= $remaining ?></b>.</p>
  <?php endif; ?>

  <?php if ($preScore !== null): ?>
    <div class="compare">
      <div><small>Pre-test</small><b><?= $preScore ?></b></div>
      <div class="arrow">→</div>
      <div><small>Post-test<?= $attemptLimit > 1 ? ' (terbaik)' : '' ?></small><b><?= $bestScore ?></b></div>
      <div><small>Peningkatan (N-gain)</small><b><?= $gain === null ? '-' : number_format($gain, 2, ',', '.') ?></b><em><?= e(categorizeGain($gain)) ?></em></div>
    </div>
  <?php endif; ?>

  <h3>Skor per materi</h3>
  <div class="topic-bars">
    <?php foreach (TOPICS as $topicKey => $topicLabel): $value = (int) ($byTopic[$topicKey] ?? 0); ?>
      <div class="topic-row">
        <span><?= e($topicLabel) ?></span>
        <div class="track"><div class="fill" style="width: <?= $value ?>%"></div></div>
        <b><?= $value ?></b>
      </div>
    <?php endforeach; ?>
  </div>

  <p class="hint center"><?= $submission['test_type'] === 'pre'
      ? 'Jangan lupa kerjakan post-test setelah pelatihan selesai, dengan nomor WhatsApp yang sama.'
      : 'Selamat! Kamu telah menyelesaikan rangkaian tes pelatihan.' ?></p>
  <p class="center result-actions">
    <?php if ($canRetry): ?><a class="btn btn-primary" href="tes.php?type=<?= e($submission['test_type']) ?>">Coba lagi (sisa <?= $remaining ?>×)</a><?php endif; ?>
    <?php if ($submission['test_type'] === 'post' && findSurvey($submission['phone']) === null): ?><a class="btn btn-primary" href="kuesioner.php">Isi kuesioner &amp; dapatkan sertifikat</a><?php endif; ?>
    <a class="btn" href="area.php">Area Peserta</a>
  </p>
</section>
<script>
  // The attempt is saved on the server, so the local draft is no longer needed.
  try { localStorage.removeItem('tkk_draft_<?= e($submission['test_type']) ?>'); } catch (error) { console.warn('Draft cleanup skipped', error); }
</script>
<?php renderFooter();
