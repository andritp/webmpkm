<?php
declare(strict_types=1);
require __DIR__ . '/../inc/bootstrap.php';
require __DIR__ . '/../inc/admin_layout.php';
requireAdmin();

const SCORE_FIELDS = ['score_cv' => 'CV', 'score_letter' => 'Surat', 'score_linkedin' => 'LinkedIn'];
const MAX_PRODUCT_SCORE = 100;

if (isset($_GET['file'], $_GET['id'])) {
    $field = $_GET['file'] === 'letter' ? 'letter' : 'cv';
    $statement = db()->prepare("SELECT {$field}_file AS stored, {$field}_original AS original FROM assignments WHERE id = ?");
    $statement->execute([(int) $_GET['id']]);
    $file = $statement->fetch();
    sendStoredFile($file['stored'] ?? '', $file['original'] ?? 'file');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    saveGrade((int) ($_POST['id'] ?? 0));
    redirect('penilaian.php');
}

$assignments = db()->query('SELECT * FROM assignments ORDER BY updated_at DESC')->fetchAll();
$participantCount = (int) db()->query('SELECT COUNT(DISTINCT phone) FROM submissions')->fetchColumn();
$linkedinCount = count(array_filter($assignments, static fn (array $row): bool => $row['linkedin_url'] !== ''));
$verifiedCount = count(array_filter($assignments, static fn (array $row): bool => (int) $row['linkedin_verified'] === 1));
$gradedCount = count(array_filter($assignments, static fn (array $row): bool => $row['score_cv'] !== null));

renderAdminHeader('penilaian', 'Penilaian Produk');
?>
<section class="kpi-grid">
  <div class="kpi"><span class="kpi-icon">↑</span><small>Peserta yang menyetor</small><b><?= count($assignments) ?> / <?= $participantCount ?></b></div>
  <div class="kpi"><span class="kpi-icon">in</span><small>Punya link LinkedIn</small><b><?= $linkedinCount ?></b></div>
  <div class="kpi dark"><span class="kpi-icon">✓</span><small>LinkedIn terverifikasi</small><b><?= $verifiedCount ?></b>
    <em><?= $participantCount ? round($verifiedCount / $participantCount * 100) . '% dari peserta' : '' ?></em></div>
  <div class="kpi"><span class="kpi-icon">★</span><small>Sudah dinilai</small><b><?= $gradedCount ?></b></div>
</section>

<section class="panel">
  <div class="panel-head"><h2>Hasil praktik peserta</h2></div>
  <p class="page-note">Buka file dan profil LinkedIn, beri nilai 0–100, lalu centang "Terverifikasi" bila akun LinkedIn sudah benar dan lengkap. Setelah dinilai, peserta tidak bisa mengganti file.</p>
  <?php if (!$assignments): ?><p class="empty">Belum ada peserta yang menyetor tugas.</p><?php endif; ?>
  <?php foreach ($assignments as $row): ?>
    <form method="post" class="grade-row">
      <?= csrfField() ?>
      <input type="hidden" name="id" value="<?= (int) $row['id'] ?>">
      <div class="grade-who"><b><?= e($row['name']) ?></b><small><?= e($row['phone']) ?> · <?= e($row['updated_at']) ?></small></div>
      <div class="grade-files">
        <?= $row['cv_file'] !== '' ? '<a href="penilaian.php?id=' . (int) $row['id'] . '&file=cv">CV ↓</a>' : '<span class="muted-x">CV –</span>' ?>
        <?= $row['letter_file'] !== '' ? '<a href="penilaian.php?id=' . (int) $row['id'] . '&file=letter">Surat ↓</a>' : '<span class="muted-x">Surat –</span>' ?>
        <?= $row['linkedin_url'] !== '' ? '<a href="' . e($row['linkedin_url']) . '" target="_blank" rel="noopener noreferrer">LinkedIn ↗</a>' : '<span class="muted-x">LinkedIn –</span>' ?>
      </div>
      <div class="grade-scores">
        <?php foreach (SCORE_FIELDS as $field => $label): ?>
          <label><?= $label ?><input type="number" name="<?= $field ?>" min="0" max="<?= MAX_PRODUCT_SCORE ?>" value="<?= $row[$field] ?? '' ?>"></label>
        <?php endforeach; ?>
        <label class="check"><input type="checkbox" name="linkedin_verified" value="1" <?= (int) $row['linkedin_verified'] === 1 ? 'checked' : '' ?>> Terverifikasi</label>
      </div>
      <input class="grade-notes" name="notes" maxlength="500" value="<?= e($row['notes']) ?>" placeholder="Catatan untuk peserta (opsional)">
      <button class="btn btn-primary btn-sm" type="submit">Simpan</button>
    </form>
  <?php endforeach; ?>
</section>
<?php renderAdminFooter();

function saveGrade(int $id): void
{
    $scores = [];
    foreach (array_keys(SCORE_FIELDS) as $field) {
        $raw = trim((string) ($_POST[$field] ?? ''));
        $value = filter_var($raw, FILTER_VALIDATE_INT, ['options' => ['min_range' => 0, 'max_range' => MAX_PRODUCT_SCORE]]);
        $scores[] = $raw === '' || $value === false ? null : $value;
    }
    $notes = mb_substr(trim((string) ($_POST['notes'] ?? '')), 0, 500);
    db()->prepare('UPDATE assignments SET score_cv = ?, score_letter = ?, score_linkedin = ?, linkedin_verified = ?, notes = ? WHERE id = ?')
        ->execute([...$scores, isset($_POST['linkedin_verified']) ? 1 : 0, $notes, $id]);
    $_SESSION['flash'] = 'Penilaian disimpan.';
}
