<?php
declare(strict_types=1);
require __DIR__ . '/../inc/bootstrap.php';
require __DIR__ . '/../inc/report.php';
require __DIR__ . '/../inc/admin_layout.php';
requireAdmin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $phone = (string) ($_POST['delete_phone'] ?? '');
    $type = (string) ($_POST['delete_type'] ?? '');
    if ($phone !== '' && array_key_exists($type, TEST_TYPES)) {
        db()->prepare('DELETE FROM submissions WHERE phone = ? AND test_type = ?')->execute([$phone, $type]);
        $_SESSION['flash'] = 'Semua percobaan ' . TEST_TYPES[$type] . ' peserta dihapus. Peserta bisa mengerjakan ulang.';
    }
    redirect('peserta.php');
}

$participants = buildParticipantRows();

renderAdminHeader('peserta', 'Data Peserta');
?>
<section class="panel">
  <div class="toolbar">
    <input type="search" id="participant-search" placeholder="Cari nama, nomor, atau kelurahan…" aria-label="Cari peserta">
    <select id="participant-filter" aria-label="Filter status">
      <option value="all">Semua peserta</option>
      <option value="complete">Lengkap (pre + post)</option>
      <option value="pre-only">Belum post-test</option>
    </select>
    <span class="count" id="participant-count"><?= count($participants) ?> peserta</span>
    <a class="btn btn-primary" href="export.php">Export Excel</a>
  </div>

  <div class="table-wrap">
    <table class="data-table" id="participant-table">
      <thead><tr><th>#</th><th>Nama</th><th>WhatsApp</th><th>L/P</th><th>Usia</th><th>Kelurahan</th><th>Pre</th><th>Post (terbaik)</th><th>N-gain</th><th>Kategori</th><th>Aksi</th></tr></thead>
      <tbody>
      <?php if (!$participants): ?>
        <tr><td colspan="11" class="empty">Belum ada peserta yang mengerjakan tes.</td></tr>
      <?php endif; ?>
      <?php foreach ($participants as $index => $participant):
          $status = $participant['pre'] && $participant['post'] ? 'complete' : ($participant['pre'] ? 'pre-only' : 'post-only');
          $category = categorizeGain($participant['gain']);
      ?>
        <tr data-status="<?= $status ?>" data-search="<?= e(mb_strtolower($participant['name'] . ' ' . $participant['phone'] . ' ' . $participant['kelurahan'])) ?>">
          <td><?= $index + 1 ?></td>
          <td><b><?= e($participant['name']) ?></b></td>
          <td><?= e($participant['phone']) ?></td>
          <td><?= e($participant['gender']) ?></td>
          <td><?= $participant['age'] ?></td>
          <td><?= e($participant['kelurahan']) ?></td>
          <td><span class="pill pre"><?= $participant['pre']['score'] ?? '-' ?></span></td>
          <td><span class="pill post"><?= $participant['post']['score'] ?? '-' ?></span>
            <?php if ($participant['post']): ?><small class="attempts" title="Skor tiap percobaan: <?= implode(', ', $participant['post']['attempt_scores']) ?>"><?= $participant['post']['attempt_count'] ?>/<?= maxAttempts('post') ?>×</small><?php endif; ?></td>
          <td><?= formatNumber($participant['gain'], 2) ?></td>
          <td><span class="tag tag-<?= mb_strtolower($category === '-' ? 'none' : $category) ?>"><?= e($category) ?></span></td>
          <td class="row-actions">
            <?php foreach (['pre', 'post'] as $type): if (!$participant[$type]) continue; ?>
              <form method="post" onsubmit="return confirm('Hapus <?= TEST_TYPES[$type] ?> milik <?= e(addslashes($participant['name'])) ?>? Semua percobaan akan dihapus.');">
                <?= csrfField() ?>
                <input type="hidden" name="delete_phone" value="<?= e($participant['phone']) ?>">
                <input type="hidden" name="delete_type" value="<?= $type ?>">
                <button class="link-danger" type="submit">Hapus <?= $type ?></button>
              </form>
            <?php endforeach; ?>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</section>

<script>
(function initParticipantFilter() {
  const searchInput = document.getElementById('participant-search');
  const statusFilter = document.getElementById('participant-filter');
  const counter = document.getElementById('participant-count');
  const rows = Array.from(document.querySelectorAll('#participant-table tbody tr[data-status]'));

  function applyFilter() {
    const query = searchInput.value.trim().toLowerCase();
    const status = statusFilter.value;
    let visible = 0;
    rows.forEach((row) => {
      const matches = row.dataset.search.includes(query) && (status === 'all' || row.dataset.status === status);
      row.hidden = !matches;
      if (matches) visible++;
    });
    counter.textContent = `${visible} peserta`;
  }

  searchInput.addEventListener('input', applyFilter);
  statusFilter.addEventListener('change', applyFilter);
})();
</script>
<?php renderAdminFooter();
