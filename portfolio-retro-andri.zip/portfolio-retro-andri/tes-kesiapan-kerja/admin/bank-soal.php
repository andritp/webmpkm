<?php
declare(strict_types=1);
require __DIR__ . '/../inc/bootstrap.php';
require __DIR__ . '/../inc/admin_layout.php';
requireAdmin();

$errors = [];
$formData = null;
$editId = isset($_GET['edit']) ? (int) $_GET['edit'] : null;
$isNew = isset($_GET['new']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    [$errors, $formData, $editId] = handleQuestionAction((string) ($_POST['action'] ?? ''));
    if (!$errors) {
        redirect('bank-soal.php');
    }
    $isNew = $editId === null;
}

$editing = $editId !== null ? findQuestion($editId) : null;
if ($editId !== null && $editing === null) {
    $_SESSION['flash'] = 'Soal tidak ditemukan.';
    redirect('bank-soal.php');
}
$showForm = $isNew || $editing !== null;
$formData ??= $editing ?? ['topic' => array_key_first(TOPICS), 'text' => '', 'options' => array_fill_keys(OPTION_KEYS, ''), 'answer' => ''];

$questions = getAllQuestions();
$activeCount = count(array_filter($questions, static fn (array $question): bool => $question['is_active']));
$submissionCount = (int) db()->query('SELECT COUNT(*) FROM submissions')->fetchColumn();

renderAdminHeader('bank-soal', 'Bank Soal');
?>
<?php if ($submissionCount > 0): ?>
  <div class="alert alert-warn">Sudah ada <b><?= $submissionCount ?></b> jawaban tersimpan. Mengubah soal di tengah kegiatan membuat nilai
    pre-test dan post-test tidak sebanding. Sebaiknya soal dikunci setelah pre-test dimulai.</div>
<?php endif; ?>

<?php if ($showForm): ?>
  <section class="panel">
    <div class="panel-head"><h2><?= $editing ? 'Edit soal #' . $editing['id'] : 'Tambah soal baru' ?></h2><a class="panel-link" href="bank-soal.php">← Kembali ke daftar</a></div>
    <?php if ($errors): ?><div class="alert"><ul><?php foreach ($errors as $error): ?><li><?= e($error) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
    <form method="post" class="question-form">
      <?= csrfField() ?>
      <input type="hidden" name="action" value="save">
      <?php if ($editing): ?><input type="hidden" name="id" value="<?= $editing['id'] ?>"><?php endif; ?>
      <label>Materi
        <select name="topic" required>
          <?php foreach (TOPICS as $topicKey => $topicLabel): ?>
            <option value="<?= $topicKey ?>" <?= $formData['topic'] === $topicKey ? 'selected' : '' ?>><?= e($topicLabel) ?></option>
          <?php endforeach; ?>
        </select>
      </label>
      <label>Pertanyaan<textarea name="text" rows="3" required maxlength="<?= MAX_QUESTION_LENGTH ?>" placeholder="Tulis pertanyaan…"><?= e($formData['text']) ?></textarea></label>
      <fieldset class="option-editor">
        <legend>Pilihan jawaban — klik bulatan untuk menandai kunci</legend>
        <?php foreach (OPTION_KEYS as $key): ?>
          <div class="option-edit-row">
            <input type="radio" name="answer" value="<?= $key ?>" id="answer-<?= $key ?>" <?= $formData['answer'] === $key ? 'checked' : '' ?> required>
            <label for="answer-<?= $key ?>" class="opt-letter"><?= strtoupper($key) ?></label>
            <input name="option_<?= $key ?>" value="<?= e($formData['options'][$key]) ?>" required maxlength="<?= MAX_OPTION_LENGTH ?>" placeholder="Pilihan <?= strtoupper($key) ?>" aria-label="Pilihan <?= strtoupper($key) ?>">
          </div>
        <?php endforeach; ?>
      </fieldset>
      <p class="hint">Urutan pilihan akan diacak otomatis saat ditampilkan ke peserta.</p>
      <div class="form-actions">
        <a class="btn" href="bank-soal.php">Batal</a>
        <button class="btn btn-primary" type="submit">Simpan soal</button>
      </div>
    </form>
  </section>
<?php endif; ?>

<section class="panel">
  <div class="toolbar">
    <select id="topic-filter" aria-label="Filter materi">
      <option value="all">Semua materi</option>
      <?php foreach (TOPICS as $topicKey => $topicLabel): ?><option value="<?= $topicKey ?>"><?= e($topicLabel) ?></option><?php endforeach; ?>
    </select>
    <span class="count"><?= $activeCount ?> aktif dari <?= count($questions) ?> soal</span>
    <a class="btn btn-primary" href="bank-soal.php?new=1">+ Tambah soal</a>
  </div>

  <?php foreach ($questions as $question): ?>
    <article class="bank-item <?= $question['is_active'] ? '' : 'is-inactive' ?>" data-topic="<?= $question['topic'] ?>">
      <div class="item-main">
        <span class="item-no"><?= $question['id'] ?></span>
        <div>
          <small class="bank-topic"><?= e(TOPICS[$question['topic']] ?? $question['topic']) ?></small>
          <p class="item-text"><?= e($question['text']) ?></p>
          <ol class="bank-options" type="A">
            <?php foreach ($question['options'] as $key => $option): ?>
              <li class="<?= $key === $question['answer'] ? 'is-key' : '' ?>"><?= e($option) ?></li>
            <?php endforeach; ?>
          </ol>
        </div>
        <span class="tag <?= $question['is_active'] ? 'tag-tinggi' : 'tag-none' ?>"><?= $question['is_active'] ? 'Aktif' : 'Nonaktif' ?></span>
      </div>
      <div class="bank-actions">
        <a class="btn btn-sm" href="bank-soal.php?edit=<?= $question['id'] ?>">Edit</a>
        <form method="post">
          <?= csrfField() ?>
          <input type="hidden" name="action" value="toggle">
          <input type="hidden" name="id" value="<?= $question['id'] ?>">
          <button class="btn btn-sm" type="submit"><?= $question['is_active'] ? 'Nonaktifkan' : 'Aktifkan' ?></button>
        </form>
        <form method="post" onsubmit="return confirm('Hapus soal #<?= $question['id'] ?> secara permanen? Gunakan Nonaktifkan bila soal mungkin dipakai lagi.');">
          <?= csrfField() ?>
          <input type="hidden" name="action" value="delete">
          <input type="hidden" name="id" value="<?= $question['id'] ?>">
          <button class="link-danger" type="submit">Hapus</button>
        </form>
      </div>
    </article>
  <?php endforeach; ?>
</section>

<script>
(function initTopicFilter() {
  const filter = document.getElementById('topic-filter');
  const items = Array.from(document.querySelectorAll('.bank-item'));
  filter.addEventListener('change', () => {
    items.forEach((item) => { item.hidden = filter.value !== 'all' && item.dataset.topic !== filter.value; });
  });
})();
</script>
<?php renderAdminFooter();

/** @return array{0: list<string>, 1: ?array, 2: ?int} errors, submitted form data, id being edited */
function handleQuestionAction(string $action): array
{
    $id = isset($_POST['id']) ? (int) $_POST['id'] : null;

    if ($action === 'save') {
        $result = validateQuestionInput($_POST, TOPICS);
        if ($result['errors']) {
            return [$result['errors'], $result['data'], $id];
        }
        saveQuestion($id, $result['data']);
        $_SESSION['flash'] = $id === null ? 'Soal baru ditambahkan.' : "Soal #{$id} diperbarui.";
        return [[], null, null];
    }
    if ($id === null || findQuestion($id) === null) {
        $_SESSION['flash'] = 'Soal tidak ditemukan.';
        return [[], null, null];
    }
    if ($action === 'toggle') {
        $question = findQuestion($id);
        if ($question['is_active'] && count(getQuestions()) <= 1) {
            $_SESSION['flash'] = 'Minimal harus ada 1 soal aktif.';
            return [[], null, null];
        }
        setQuestionActive($id, !$question['is_active']);
        $_SESSION['flash'] = "Soal #{$id} " . ($question['is_active'] ? 'dinonaktifkan.' : 'diaktifkan.');
    }
    if ($action === 'delete') {
        if (findQuestion($id)['is_active'] && count(getQuestions()) <= 1) {
            $_SESSION['flash'] = 'Minimal harus ada 1 soal aktif.';
            return [[], null, null];
        }
        deleteQuestion($id);
        $_SESSION['flash'] = "Soal #{$id} dihapus.";
    }
    return [[], null, null];
}
