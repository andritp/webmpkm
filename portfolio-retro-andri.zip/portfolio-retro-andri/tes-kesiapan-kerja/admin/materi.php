<?php
declare(strict_types=1);
require __DIR__ . '/../inc/bootstrap.php';
require __DIR__ . '/../inc/admin_layout.php';
requireAdmin();

const MATERIAL_SUGGESTIONS = [
    'Buku Saku "Job Ready: Bekal Menuju Dunia Kerja"',
    'Template Curriculum Vitae (CV)',
    'Template Surat Lamaran Kerja',
    'Panduan Membuat Akun LinkedIn',
];

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $errors = handleMaterialAction((string) ($_POST['action'] ?? ''));
    if (!$errors) {
        redirect('materi.php');
    }
}
$materials = db()->query('SELECT * FROM materials ORDER BY id DESC')->fetchAll();

renderAdminHeader('materi', 'Materi & Unduhan');
?>
<div class="panel-grid">
  <section class="panel">
    <div class="panel-head"><h2>Upload materi</h2></div>
    <?php if ($errors): ?><div class="alert"><ul><?php foreach ($errors as $error): ?><li><?= e($error) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
    <form method="post" enctype="multipart/form-data" class="stack-form">
      <?= csrfField() ?>
      <input type="hidden" name="action" value="upload">
      <label>Judul<input name="title" required maxlength="150" list="material-titles" placeholder="Template CV"></label>
      <datalist id="material-titles"><?php foreach (MATERIAL_SUGGESTIONS as $title): ?><option value="<?= e($title) ?>"><?php endforeach; ?></datalist>
      <label>Deskripsi singkat<input name="description" maxlength="300" placeholder="Opsional"></label>
      <label>File<input type="file" name="file" required accept=".<?= implode(',.', MATERIAL_EXTENSIONS) ?>"></label>
      <p class="hint">Format: <?= strtoupper(implode(', ', MATERIAL_EXTENSIONS)) ?>. Maksimal <?= formatFileSize(MAX_MATERIAL_BYTES) ?>.</p>
      <button class="btn btn-primary" type="submit">Upload</button>
    </form>
  </section>

  <section class="panel span-2">
    <div class="panel-head"><h2>Daftar materi (<?= count($materials) ?>)</h2><a class="panel-link" href="../materi.php" target="_blank" rel="noopener">Lihat halaman peserta ↗</a></div>
    <?php if (!$materials): ?><p class="empty">Belum ada materi. Upload buku saku, template CV, template surat lamaran, dan panduan LinkedIn.</p><?php endif; ?>
    <ul class="material-list">
      <?php foreach ($materials as $material): ?>
        <li>
          <span class="file-badge"><?= e(strtoupper(fileExtension($material['original_name']))) ?></span>
          <div><b><?= e($material['title']) ?></b><small><?= e($material['original_name']) ?> · <?= e(formatFileSize((int) $material['size'])) ?> · <?= (int) $material['download_count'] ?>× diunduh</small></div>
          <form method="post" onsubmit="return confirm('Hapus materi ini?');">
            <?= csrfField() ?>
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="id" value="<?= (int) $material['id'] ?>">
            <button class="link-danger" type="submit">Hapus</button>
          </form>
        </li>
      <?php endforeach; ?>
    </ul>
  </section>
</div>
<?php renderAdminFooter();

/** @return list<string> */
function handleMaterialAction(string $action): array
{
    if ($action === 'delete') {
        $statement = db()->prepare('SELECT stored_name FROM materials WHERE id = ?');
        $statement->execute([(int) ($_POST['id'] ?? 0)]);
        $storedName = $statement->fetchColumn();
        if ($storedName !== false) {
            deleteStoredFile((string) $storedName);
            db()->prepare('DELETE FROM materials WHERE id = ?')->execute([(int) $_POST['id']]);
            $_SESSION['flash'] = 'Materi dihapus.';
        }
        return [];
    }
    if ($action !== 'upload') {
        return [];
    }
    $title = trim((string) ($_POST['title'] ?? ''));
    $description = trim((string) ($_POST['description'] ?? ''));
    $file = $_FILES['file'] ?? ['error' => UPLOAD_ERR_NO_FILE];
    $errors = [];
    if ($title === '' || mb_strlen($title) > 150) {
        $errors[] = 'Judul wajib diisi (maksimal 150 karakter).';
    }
    $fileError = validateUploadMeta($file, MATERIAL_EXTENSIONS, MAX_MATERIAL_BYTES);
    if ($fileError !== null) {
        $errors[] = $fileError;
    }
    if ($errors) {
        return $errors;
    }
    try {
        $storedName = storeUpload($file);
    } catch (RuntimeException $exception) {
        error_log('Material upload failed: ' . $exception->getMessage());
        return ['Upload gagal disimpan. Coba lagi.'];
    }
    db()->prepare('INSERT INTO materials (title, description, stored_name, original_name, size, created_at) VALUES (?, ?, ?, ?, ?, ?)')
        ->execute([$title, mb_substr($description, 0, 300), $storedName, mb_substr(basename($file['name']), 0, 200), (int) $file['size'], date('Y-m-d H:i:s')]);
    $_SESSION['flash'] = 'Materi diupload.';
    return [];
}
