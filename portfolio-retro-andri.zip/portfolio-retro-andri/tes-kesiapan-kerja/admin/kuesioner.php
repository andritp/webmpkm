<?php
declare(strict_types=1);
require __DIR__ . '/../inc/bootstrap.php';
require __DIR__ . '/../inc/admin_layout.php';
require __DIR__ . '/../inc/xlsx.php';
requireAdmin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $surveyId = (int) ($_POST['delete_survey'] ?? 0);
    db()->prepare('DELETE FROM survey_answers WHERE survey_id = ?')->execute([$surveyId]);
    db()->prepare('DELETE FROM surveys WHERE id = ?')->execute([$surveyId]);
    $_SESSION['flash'] = 'Jawaban kuesioner dihapus. Peserta bisa mengisi ulang.';
    redirect('kuesioner.php');
}

$aspects = getSurveyAspects(false);
$aspectsById = array_column($aspects, null, 'id');
$respondents = db()->query('SELECT * FROM surveys ORDER BY id DESC')->fetchAll();

if (($_GET['export'] ?? '') === 'csv') {
    exportSurveyXlsx($aspects, $respondents);
}

$summary = summarizeSurvey(surveyRatingRows(), $aspectsById);
$commentsByAspect = surveyCommentsByAspect();
$activeAverages = array_filter(array_map(static fn (array $aspect): ?float => $aspect['is_active'] ? $summary[$aspect['id']]['average'] : null, $aspects), static fn (?float $value): bool => $value !== null);
$overall = $activeAverages ? round(array_sum($activeAverages) / count($activeAverages), 2) : null;

renderAdminHeader('kuesioner', 'Kuesioner Kepuasan');
?>
<section class="kpi-grid">
  <div class="kpi"><span class="kpi-icon">✎</span><small>Responden</small><b><?= count($respondents) ?></b></div>
  <div class="kpi dark"><span class="kpi-icon">★</span><small>Rata-rata kepuasan (skala 1–5)</small>
    <b><?= $overall === null ? '-' : number_format($overall, 2, ',', '.') ?></b><em><?= e(satisfactionLabel($overall)) ?></em></div>
  <div class="kpi"><span class="kpi-icon">%</span><small>Indeks kepuasan</small>
    <b><?= $overall === null ? '-' : number_format($overall / 5 * 100, 1, ',', '.') . '%' ?></b></div>
  <div class="kpi"><span class="kpi-icon">?</span><small>Pertanyaan aktif</small>
    <b><?= count(array_filter($aspects, static fn (array $aspect): bool => $aspect['is_active'])) ?></b></div>
</section>

<section class="panel">
  <div class="panel-head">
    <h2>Rata-rata per pertanyaan</h2>
    <div class="admin-actions">
      <a class="btn btn-sm" href="kuesioner-atur.php">Atur pertanyaan</a>
      <a class="btn btn-sm btn-primary" href="kuesioner.php?export=csv">Export Excel</a>
    </div>
  </div>
  <div class="survey-bars">
    <?php foreach ($aspects as $aspect): $average = $summary[$aspect['id']]['average']; ?>
      <div class="survey-row <?= $aspect['is_active'] ? '' : 'is-inactive' ?>">
        <span><?= e($aspect['label']) ?><?= $aspect['is_active'] ? '' : ' <em>(nonaktif)</em>' ?></span>
        <div class="track"><div class="fill post" style="width: <?= $average === null ? 0 : $average / 5 * 100 ?>%"></div></div>
        <b><?= $average === null ? '-' : number_format($average, 2, ',', '.') ?></b>
        <span class="tag tag-<?= mb_strtolower(str_replace(' ', '-', satisfactionLabel($average))) ?>"><?= e(satisfactionLabel($average)) ?></span>
      </div>
    <?php endforeach; ?>
  </div>
  <p class="hint">Kategori: ≥ 4,2 Sangat Baik · 3,4–4,19 Baik · 2,6–3,39 Cukup · &lt; 2,6 Kurang.</p>
</section>

<section class="panel">
  <div class="panel-head"><h2>Saran per pertanyaan</h2></div>
  <?php foreach ($aspects as $aspect): $comments = $commentsByAspect[$aspect['id']] ?? []; ?>
    <details class="comment-group" <?= $comments ? '' : 'disabled' ?>>
      <summary><b><?= e($aspect['label']) ?></b><span class="count"><?= count($comments) ?> saran</span></summary>
      <div class="suggestions">
        <?php foreach ($comments as $comment): ?>
          <blockquote class="<?= $comment['rating'] <= 2 ? 'is-low' : '' ?>">
            <p><?= nl2br(e($comment['comment'])) ?></p>
            <cite><?= e($comment['name']) ?> · nilai <?= $comment['rating'] ?></cite>
          </blockquote>
        <?php endforeach; ?>
      </div>
    </details>
  <?php endforeach; ?>
</section>

<section class="panel table-wrap">
  <div class="panel-head"><h2>Responden dan kritik umum</h2></div>
  <table class="data-table">
    <thead><tr><th>#</th><th>Nama</th><th>WhatsApp</th><th>Kritik dan saran umum</th><th>Waktu</th><th></th></tr></thead>
    <tbody>
      <?php if (!$respondents): ?><tr><td colspan="6" class="empty">Belum ada responden.</td></tr><?php endif; ?>
      <?php foreach ($respondents as $index => $row): ?>
        <tr>
          <td><?= $index + 1 ?></td><td><b><?= e($row['name']) ?></b></td><td><?= e($row['phone']) ?></td>
          <td class="wrap-cell"><?= nl2br(e($row['saran'])) ?></td><td><?= e($row['created_at']) ?></td>
          <td><form method="post" onsubmit="return confirm('Hapus jawaban kuesioner <?= e(addslashes($row['name'])) ?>? Peserta harus mengisi ulang untuk mendapat sertifikat.');">
            <?= csrfField() ?><input type="hidden" name="delete_survey" value="<?= (int) $row['id'] ?>"><button class="link-danger" type="submit">Hapus</button></form></td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</section>
<?php renderAdminFooter();

/**
 * @param list<array<string, mixed>> $aspects
 * @param list<array<string, mixed>> $respondents
 */
function exportSurveyXlsx(array $aspects, array $respondents): never
{
    $answers = [];
    foreach (db()->query('SELECT survey_id, aspect_id, rating, comment FROM survey_answers')->fetchAll() as $answer) {
        $answers[(int) $answer['survey_id']][(int) $answer['aspect_id']] = $answer;
    }
    $columns = [['No', 5, 'int'], ['Nama', 24, 'text'], ['WhatsApp', 16, 'text']];
    foreach ($aspects as $number => $aspect) {
        $columns[] = ['Nilai ' . ($number + 1) . ' — ' . $aspect['label'], 14, 'int'];
        $columns[] = ['Saran ' . ($number + 1), 34, 'text'];
    }
    $columns[] = ['Kritik dan Saran Umum', 40, 'text'];
    $columns[] = ['Waktu', 19, 'text'];
    $rows = [];
    foreach (array_reverse($respondents) as $index => $row) {
        $line = [$index + 1, $row['name'], $row['phone']];
        foreach ($aspects as $aspect) {
            $answer = $answers[(int) $row['id']][$aspect['id']] ?? null;
            $line[] = isset($answer['rating']) ? (int) $answer['rating'] : null;
            $line[] = $answer['comment'] ?? '';
        }
        $rows[] = array_merge($line, [$row['saran'], $row['created_at']]);
    }
    $summary = summarizeSurvey(surveyRatingRows(), array_column($aspects, null, 'id'));
    $summaryRows = [];
    foreach ($aspects as $number => $aspect) {
        $average = $summary[$aspect['id']]['average'];
        $summaryRows[] = [$number + 1, $aspect['label'], $average, satisfactionLabel($average)];
    }
    sendXlsx('kuesioner-kepuasan-' . date('Ymd-His') . '.xlsx', [
        'Jawaban Responden' => ['title' => 'Kuesioner Kepuasan Peserta (skala 1–5)', 'columns' => $columns, 'rows' => $rows],
        'Rata-rata per Aspek' => [
            'title' => 'Rata-rata kepuasan per aspek',
            'columns' => [['No', 5, 'int'], ['Aspek', 56, 'text'], ['Rata-rata', 11, 'decimal'], ['Kategori', 14, 'text']],
            'rows' => $summaryRows,
        ],
    ]);
}
