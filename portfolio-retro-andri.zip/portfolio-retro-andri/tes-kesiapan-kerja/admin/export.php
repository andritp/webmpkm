<?php
declare(strict_types=1);
require __DIR__ . '/../inc/bootstrap.php';
require __DIR__ . '/../inc/report.php';
require __DIR__ . '/../inc/xlsx.php';
requireAdmin();

const GENDER_LABELS = ['L' => 'Laki-laki', 'P' => 'Perempuan'];

$participants = buildParticipantRows();
$summary = summarizeParticipants($participants);
$exportedAt = date('d-m-Y H:i');

$dataRows = [];
$topicRows = [];
foreach ($participants as $index => $participant) {
    $dataRows[] = [
        $index + 1,
        $participant['name'],
        $participant['phone'],
        GENDER_LABELS[$participant['gender']] ?? $participant['gender'],
        $participant['age'],
        $participant['kelurahan'],
        $participant['pre']['score'] ?? null,
        $participant['post']['score'] ?? null,
        $participant['post']['attempt_count'] ?? null,
        $participant['post'] ? implode(' | ', $participant['post']['attempt_scores']) : '',
        $participant['gain'],
        categorizeGain($participant['gain']),
        $participant['pre']['created_at'] ?? '',
        $participant['post']['created_at'] ?? '',
    ];
    $topicRow = [$index + 1, $participant['name']];
    foreach (array_keys(TOPICS) as $topicKey) {
        $topicRow[] = $participant['pre']['by_topic'][$topicKey] ?? null;
        $topicRow[] = $participant['post']['by_topic'][$topicKey] ?? null;
    }
    $topicRows[] = $topicRow;
}

$topicColumns = [['No', 5, 'int'], ['Nama', 24, 'text']];
foreach (TOPICS as $topicLabel) {
    $topicColumns[] = ["Pre — {$topicLabel}", 14, 'int'];
    $topicColumns[] = ["Post — {$topicLabel}", 14, 'int'];
}

$summaryRows = [
    ['Peserta pre-test', $summary['pre_count']],
    ['Peserta post-test', $summary['post_count']],
    ['Peserta lengkap (pre + post)', $summary['paired_count']],
    ['Rata-rata nilai pre-test', $summary['pre_average']],
    ['Rata-rata nilai post-test (terbaik)', $summary['post_average']],
    ['Rata-rata N-gain', $summary['gain_average']],
    ['Kategori rata-rata N-gain', categorizeGain($summary['gain_average'])],
    ['N-gain kategori Tinggi (> 0,7)', $summary['categories']['Tinggi']],
    ['N-gain kategori Sedang (0,3–0,7)', $summary['categories']['Sedang']],
    ['N-gain kategori Rendah (< 0,3)', $summary['categories']['Rendah']],
];
foreach (TOPICS as $topicKey => $topicLabel) {
    $summaryRows[] = ["Rata-rata pre — {$topicLabel}", $summary['topics'][$topicKey]['pre']];
    $summaryRows[] = ["Rata-rata post — {$topicLabel}", $summary['topics'][$topicKey]['post']];
}

sendXlsx('hasil-pre-post-test-' . date('Ymd-His') . '.xlsx', [
    'Data Peserta' => [
        'title' => "Hasil Pre-test dan Post-test — Karang Taruna Kec. Jatisampurna (diunduh {$exportedAt})",
        'columns' => [
            ['No', 5, 'int'], ['Nama', 26, 'text'], ['WhatsApp', 16, 'text'], ['Jenis Kelamin', 13, 'text'],
            ['Usia', 7, 'int'], ['Kelurahan', 16, 'text'], ['Skor Pre', 10, 'int'], ['Skor Post (terbaik)', 12, 'int'],
            ['Jumlah Percobaan Post', 12, 'int'], ['Skor Tiap Percobaan Post', 16, 'text'], ['N-gain', 9, 'decimal'],
            ['Kategori N-gain', 12, 'text'], ['Waktu Pre-test', 19, 'text'], ['Waktu Post-test (terbaik)', 19, 'text'],
        ],
        'rows' => $dataRows,
    ],
    'Skor per Materi' => [
        'title' => 'Skor per materi (0–100) — pre-test dan post-test terbaik',
        'columns' => $topicColumns,
        'rows' => $topicRows,
    ],
    'Ringkasan' => [
        'title' => "Ringkasan hasil (diunduh {$exportedAt})",
        'columns' => [['Keterangan', 40, 'text'], ['Nilai', 14, 'auto']],
        'rows' => $summaryRows,
    ],
]);
