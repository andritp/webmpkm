<?php
declare(strict_types=1);
require __DIR__ . '/../inc/bootstrap.php';
require __DIR__ . '/../inc/admin_layout.php';
requireAdmin();

$errors = [];
$editId = isset($_GET['edit']) ? (int) $_GET['edit'] : null;
$formData = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    [$errors, $formData, $editId] = handleAspectAction((string) ($_POST['action'] ?? ''));
    if (!$errors) {
        redirect('kuesioner-atur.php');
    }
}

$aspects = getSurveyAspects(false);
$aspectsById = array_column($aspects, null, 'id');
$editing = $editId !== null ? ($aspectsById[$editId] ?? null) : null;
$formData ??= $editing ?? ['label' => '', 'comment_prompt' => ''];
$answerCounts = db()->query('SELECT aspect_id, COUNT(*) AS total FROM survey_answers GROUP BY aspect_id')->fetchAll(PDO::FETCH_KEY_PAIR);
$respondentCount = (int) db()->query('SELECT COUNT(*) FROM surveys')->fetchColumn();

renderAdminHeader('kuesioner', 'Atur Pertanyaan Kuesioner');
?>
<p class="page-note"><a href="kuesioner.php">← Kembali ke hasil kuesioner</a></p>
<?php if ($respondentCount > 0): ?>
  <div class="alert alert-warn">Sudah ada <b><?= $respondentCount ?></b> responden. Mengubah kalimat pertanyaan mengubah arti jawaban yang sudah masuk.
    Untuk pertanyaan yang tidak dipakai lagi, gunakan <b>Nonaktifkan</b> agar datanya tetap tersimpan.</div>
<?php endif; ?>

<div class="panel-grid">
  <section class="panel">
    <div class="panel-head"><h2><?= $editing ? 'Edit pertanyaan' : 'Tambah pertanyaan' ?></h2></div>
    <?php if ($errors): ?><div class="alert"><ul><?php foreach ($errors as $error): ?><li><?= e($error) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
    <form method="post" class="stack-form">
      <?= csrfField() ?>
      <input type="hidden" name="action" value="save">
      <?php if ($editing): ?><input type="hidden" name="id" value="<?= $editing['id'] ?>"><?php endif; ?>
      <label>Pertanyaan (dinilai 1–5)<textarea name="label" rows="3" required maxlength="200" placeholder="Pemateri bersikap ramah dan menghargai peserta"><?= e($formData['label']) ?></textarea></label>
      <label>Petunjuk kolom saran<input name="comment_prompt" maxlength="200" value="<?= e($formData['comment_prompt']) ?>" placeholder="<?= e(DEFAULT_COMMENT_PROMPT) ?>"></label>
      <p class="hint">Petunjuk tampil samar di dalam kolom saran. Saran tetap wajib diisi peserta.</p>
      <div class="form-actions">
        <?php if ($editing): ?><a class="btn" href="kuesioner-atur.php">Batal</a><?php endif; ?>
        <button class="btn btn-primary" type="submit"><?= $editing ? 'Simpan perubahan' : 'Tambah pertanyaan' ?></button>
      </div>
    </form>
  </section>

  <section class="panel span-2">
    <div class="panel-head"><h2>Daftar pertanyaan (<?= count($aspects) ?>)</h2><a class="panel-link" href="../kuesioner.php" target="_blank" rel="noopener">Pratinjau peserta ↗</a></div>
    <ol class="aspect-list">
      <?php foreach ($aspects as $index => $aspect): $answered = (int) ($answerCounts[$aspect['id']] ?? 0); ?>
        <li class="<?= $aspect['is_active'] ? '' : 'is-inactive' ?> <?= $editing && $editing['id'] === $aspect['id'] ? 'is-editing' : '' ?>">
          <div class="aspect-order">
            <?php foreach ([-1 => '▲', 1 => '▼'] as $direction => $arrow): ?>
              <form method="post"><?= csrfField() ?><input type="hidden" name="action" value="move"><input type="hidden" name="id" value="<?= $aspect['id'] ?>"><input type="hidden" name="direction" value="<?= $direction ?>">
                <button type="submit" aria-label="Pindah <?= $direction < 0 ? 'ke atas' : 'ke bawah' ?>" <?= ($direction < 0 && $index === 0) || ($direction > 0 && $index === count($aspects) - 1) ? 'disabled' : '' ?>><?= $arrow ?></button></form>
            <?php endforeach; ?>
          </div>
          <div class="aspect-body">
            <b><?= e($aspect['label']) ?></b>
            <small>Petunjuk saran: <?= e($aspect['comment_prompt']) ?> · <?= $answered ?> jawaban</small>
          </div>
          <span class="tag <?= $aspect['is_active'] ? 'tag-tinggi' : 'tag-none' ?>"><?= $aspect['is_active'] ? 'Aktif' : 'Nonaktif' ?></span>
          <div class="row-actions">
            <a class="btn btn-sm" href="kuesioner-atur.php?edit=<?= $aspect['id'] ?>">Edit</a>
            <form method="post"><?= csrfField() ?><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?= $aspect['id'] ?>">
              <button class="btn btn-sm" type="submit"><?= $aspect['is_active'] ? 'Nonaktifkan' : 'Aktifkan' ?></button></form>
            <?php if ($answered === 0): ?>
              <form method="post" onsubmit="return confirm('Hapus pertanyaan ini secara permanen?');"><?= csrfField() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= $aspect['id'] ?>">
                <button class="link-danger" type="submit">Hapus</button></form>
            <?php endif; ?>
          </div>
        </li>
      <?php endforeach; ?>
    </ol>
    <p class="hint">Pertanyaan yang sudah punya jawaban tidak bisa dihapus, hanya bisa dinonaktifkan, supaya data laporan tidak hilang.</p>
  </section>
</div>
<?php renderAdminFooter();

/** @return array{0: list<string>, 1: ?array, 2: ?int} */
function handleAspectAction(string $action): array
{
    $id = isset($_POST['id']) ? (int) $_POST['id'] : null;
    if ($action === 'save') {
        $result = validateAspectInput($_POST);
        if ($result['errors']) {
            return [$result['errors'], $result['data'], $id];
        }
        saveSurveyAspect($id, $result['data']);
        $_SESSION['flash'] = $id === null ? 'Pertanyaan ditambahkan.' : 'Pertanyaan diperbarui.';
        return [[], null, null];
    }
    if ($id === null) {
        return [[], null, null];
    }
    $activeCount = count(getSurveyAspects());
    $current = array_column(getSurveyAspects(false), null, 'id')[$id] ?? null;
    if ($current === null) {
        $_SESSION['flash'] = 'Pertanyaan tidak ditemukan.';
        return [[], null, null];
    }
    if ($action === 'move') {
        moveSurveyAspect($id, (int) ($_POST['direction'] ?? 0) < 0 ? -1 : 1);
    }
    if ($action === 'toggle') {
        if ($current['is_active'] && $activeCount <= 1) {
            $_SESSION['flash'] = 'Minimal harus ada 1 pertanyaan aktif.';
            return [[], null, null];
        }
        db()->prepare('UPDATE survey_aspects SET is_active = 1 - is_active WHERE id = ?')->execute([$id]);
        $_SESSION['flash'] = $current['is_active'] ? 'Pertanyaan dinonaktifkan.' : 'Pertanyaan diaktifkan.';
    }
    if ($action === 'delete') {
        $statement = db()->prepare('SELECT COUNT(*) FROM survey_answers WHERE aspect_id = ?');
        $statement->execute([$id]);
        if ((int) $statement->fetchColumn() > 0 || ($current['is_active'] && $activeCount <= 1)) {
            $_SESSION['flash'] = 'Pertanyaan ini tidak bisa dihapus. Gunakan Nonaktifkan.';
            return [[], null, null];
        }
        db()->prepare('DELETE FROM survey_aspects WHERE id = ?')->execute([$id]);
        $_SESSION['flash'] = 'Pertanyaan dihapus.';
    }
    return [[], null, null];
}
