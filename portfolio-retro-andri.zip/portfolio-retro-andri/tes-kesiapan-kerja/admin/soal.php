<?php
declare(strict_types=1);
require __DIR__ . '/../inc/bootstrap.php';
require __DIR__ . '/../inc/admin_layout.php';
requireAdmin();

const EASY_THRESHOLD = 70;
const HARD_THRESHOLD = 30;

$submissions = array_map(
    static fn (array $row): array => [
        'test_type' => $row['test_type'],
        'answers' => array_map('strval', json_decode($row['answers'], true) ?: []),
    ],
    pickBestAttempts(db()->query('SELECT phone, test_type, attempt, score, answers FROM submissions')->fetchAll())
);
$questions = getQuestions();
$items = calculateItemAnalysis($questions, $submissions);

function difficultyLabel(?int $percentCorrect): string
{
    if ($percentCorrect === null) {
        return '-';
    }
    if ($percentCorrect > EASY_THRESHOLD) {
        return 'Mudah';
    }
    return $percentCorrect >= HARD_THRESHOLD ? 'Sedang' : 'Sukar';
}

renderAdminHeader('soal', 'Analisis Soal');
?>
<p class="page-note">Persentase peserta yang menjawab benar tiap soal. Tingkat kesukaran dihitung dari pre-test
  (Mudah &gt; 70%, Sedang 30–70%, Sukar &lt; 30%). Soal yang naik tajam di post-test menandakan materinya tersampaikan dengan baik.</p>

<?php foreach (TOPICS as $topicKey => $topicLabel): ?>
  <section class="panel">
    <div class="panel-head"><h2><?= e($topicLabel) ?></h2></div>
    <?php foreach ($questions as $question): if ($question['topic'] !== $topicKey) continue;
        $item = $items[$question['id']];
        $difficulty = difficultyLabel($item['pre']);
    ?>
      <article class="item">
        <div class="item-main">
          <span class="item-no"><?= $question['id'] ?></span>
          <div>
            <p class="item-text"><?= e($question['text']) ?></p>
            <p class="item-key">Kunci: <b><?= e($question['options'][$question['answer']]) ?></b></p>
          </div>
          <span class="tag tag-<?= mb_strtolower($difficulty === '-' ? 'none' : $difficulty) ?>"><?= $difficulty ?></span>
        </div>
        <div class="item-bars">
          <?php foreach (['pre' => 'Pre', 'post' => 'Post'] as $type => $label): ?>
            <div class="item-bar"><small><?= $label ?></small>
              <div class="track"><div class="fill <?= $type ?>" style="width: <?= (int) ($item[$type] ?? 0) ?>%"></div></div>
              <b><?= $item[$type] === null ? '-' : $item[$type] . '%' ?></b>
            </div>
          <?php endforeach; ?>
        </div>
      </article>
    <?php endforeach; ?>
  </section>
<?php endforeach; ?>
<?php renderAdminFooter();
