<?php
declare(strict_types=1);
require __DIR__ . '/../inc/bootstrap.php';
require __DIR__ . '/../inc/admin_layout.php';
requireAdmin();

const MIN_PASSWORD_LENGTH = 8;
const RESET_CONFIRMATION_WORD = 'HAPUS';

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $errors = handleSettingsAction((string) ($_POST['action'] ?? ''));
    if (!$errors) {
        redirect('pengaturan.php');
    }
}

renderAdminHeader('pengaturan', 'Pengaturan');
?>
<?php if ($errors): ?><div class="alert"><?php foreach ($errors as $error): ?><div><?= e($error) ?></div><?php endforeach; ?></div><?php endif; ?>

<div class="panel-grid">
  <section class="panel">
    <div class="panel-head"><h2>Akses tes</h2></div>
    <p class="page-note">Buka pre-test sebelum materi dimulai. Tutup pre-test dan buka post-test setelah pelatihan selesai.</p>
    <?php foreach (TEST_TYPES as $type => $label): $open = isTestOpen($type); ?>
      <form method="post" class="switch-row">
        <?= csrfField() ?>
        <input type="hidden" name="action" value="toggle_<?= $type ?>">
        <div><b><?= e($label) ?></b><small><?= $open ? 'Dibuka' : 'Ditutup' ?></small></div>
        <button type="submit" class="switch <?= $open ? 'on' : '' ?>" aria-label="<?= $open ? 'Tutup' : 'Buka' ?> <?= e($label) ?>"><span></span></button>
      </form>
    <?php endforeach; ?>
  </section>

  <section class="panel">
    <div class="panel-head"><h2>Ganti password admin</h2></div>
    <form method="post" class="stack-form">
      <?= csrfField() ?>
      <input type="hidden" name="action" value="change_password">
      <label>Password lama<input type="password" name="current_password" required autocomplete="current-password"></label>
      <label>Password baru<input type="password" name="new_password" required minlength="<?= MIN_PASSWORD_LENGTH ?>" autocomplete="new-password"></label>
      <label>Ulangi password baru<input type="password" name="confirm_password" required minlength="<?= MIN_PASSWORD_LENGTH ?>" autocomplete="new-password"></label>
      <button class="btn btn-primary" type="submit">Simpan password</button>
    </form>
  </section>

  <section class="panel">
    <div class="panel-head"><h2>Timer tes</h2></div>
    <form method="post" class="stack-form">
      <?= csrfField() ?>
      <input type="hidden" name="action" value="save_timer">
      <label>Durasi pengerjaan (menit)<input type="number" name="duration" min="0" max="180" value="<?= testDurationMinutes() ?>" required></label>
      <p class="hint">Isi 0 untuk mematikan timer. Saat waktu habis, jawaban otomatis dikirim.</p>
      <button class="btn btn-primary" type="submit">Simpan timer</button>
    </form>
  </section>

  <section class="panel">
    <div class="panel-head"><h2>Penanda tangan sertifikat</h2></div>
    <form method="post" class="stack-form">
      <?= csrfField() ?>
      <input type="hidden" name="action" value="save_signers">
      <?php foreach ([1 => ['Kurnen', 'Ketua Kelompok 1 MK-PM Universitas Terbuka'], 2 => ['', 'Ketua Karang Taruna Kecamatan Jatisampurna']] as $slot => [$defaultName, $defaultTitle]): ?>
        <label>Nama penanda tangan <?= $slot ?><input name="signer<?= $slot ?>_name" maxlength="80" value="<?= e(getSetting("signer{$slot}_name", $defaultName)) ?>" placeholder="Nama lengkap"></label>
        <label>Jabatan <?= $slot ?><input name="signer<?= $slot ?>_title" maxlength="100" value="<?= e(getSetting("signer{$slot}_title", $defaultTitle)) ?>"></label>
      <?php endforeach; ?>
      <button class="btn btn-primary" type="submit">Simpan</button>
    </form>
  </section>

  <section class="panel span-2 danger-zone">
    <div class="panel-head"><h2>Zona berbahaya</h2></div>
    <p class="page-note">Menghapus <b>seluruh</b> data pre-test dan post-test. Export Excel terlebih dahulu. Tindakan ini tidak bisa dibatalkan.</p>
    <form method="post" class="inline-form" onsubmit="return confirm('Yakin menghapus SEMUA data tes? Tindakan ini tidak bisa dibatalkan.');">
      <?= csrfField() ?>
      <input type="hidden" name="action" value="reset_all">
      <label>Ketik <b><?= RESET_CONFIRMATION_WORD ?></b> untuk konfirmasi<input name="confirm_word" required autocomplete="off"></label>
      <button class="btn btn-danger" type="submit">Hapus semua data</button>
    </form>
  </section>
</div>
<?php renderAdminFooter();

/** @return list<string> */
function handleSettingsAction(string $action): array
{
    if ($action === 'toggle_pre' || $action === 'toggle_post') {
        toggleTest(substr($action, strlen('toggle_')));
        return [];
    }
    if ($action === 'save_timer') {
        $minutes = filter_var($_POST['duration'] ?? '', FILTER_VALIDATE_INT, ['options' => ['min_range' => 0, 'max_range' => MAX_TEST_DURATION_MINUTES]]);
        if ($minutes === false) {
            return ['Durasi harus 0–' . MAX_TEST_DURATION_MINUTES . ' menit.'];
        }
        setSetting('test_duration', (string) $minutes);
        $_SESSION['flash'] = $minutes === 0 ? 'Timer dimatikan.' : "Timer diatur {$minutes} menit.";
        return [];
    }
    if ($action === 'save_signers') {
        foreach ([1, 2] as $slot) {
            setSetting("signer{$slot}_name", mb_substr(trim((string) ($_POST["signer{$slot}_name"] ?? '')), 0, 80));
            setSetting("signer{$slot}_title", mb_substr(trim((string) ($_POST["signer{$slot}_title"] ?? '')), 0, 100));
        }
        $_SESSION['flash'] = 'Penanda tangan sertifikat disimpan.';
        return [];
    }
    if ($action === 'change_password') {
        return changeAdminPassword();
    }
    if ($action === 'reset_all') {
        if (trim((string) ($_POST['confirm_word'] ?? '')) !== RESET_CONFIRMATION_WORD) {
            return ['Kata konfirmasi tidak sesuai. Data tidak dihapus.'];
        }
        db()->exec('DELETE FROM submissions');
        $_SESSION['flash'] = 'Seluruh data tes telah dihapus.';
    }
    return [];
}

/** @return list<string> */
function changeAdminPassword(): array
{
    $current = (string) ($_POST['current_password'] ?? '');
    $new = (string) ($_POST['new_password'] ?? '');
    $confirm = (string) ($_POST['confirm_password'] ?? '');

    if (!password_verify($current, adminPasswordHash())) {
        return ['Password lama salah.'];
    }
    if (strlen($new) < MIN_PASSWORD_LENGTH) {
        return ['Password baru minimal ' . MIN_PASSWORD_LENGTH . ' karakter.'];
    }
    if ($new !== $confirm) {
        return ['Konfirmasi password baru tidak sama.'];
    }
    setSetting('admin_password_hash', password_hash($new, PASSWORD_DEFAULT));
    $_SESSION['flash'] = 'Password admin berhasil diganti.';
    return [];
}
