<?php
declare(strict_types=1);
require __DIR__ . '/../inc/bootstrap.php';
require __DIR__ . '/../inc/report.php';
require __DIR__ . '/../inc/admin_layout.php';
requireAdmin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $type = (string) ($_POST['toggle'] ?? '');
    if (array_key_exists($type, TEST_TYPES)) {
        toggleTest($type);
    }
    redirect('index.php');
}

$participants = buildParticipantRows();
$summary = summarizeParticipants($participants);
$recent = db()->query('SELECT name, test_type, attempt, score, created_at FROM submissions ORDER BY id DESC LIMIT 6')->fetchAll();
$categoryTotal = array_sum($summary['categories']);
$improvement = ($summary['pre_average'] !== null && $summary['post_average'] !== null)
    ? $summary['post_average'] - $summary['pre_average']
    : null;

renderAdminHeader('dashboard', 'Dashboard');
?>
<section class="kpi-grid">
  <div class="kpi"><span class="kpi-icon">01</span><small>Peserta pre-test</small><b><?= $summary['pre_count'] ?></b></div>
  <div class="kpi"><span class="kpi-icon">02</span><small>Peserta post-test</small><b><?= $summary['post_count'] ?></b></div>
  <div class="kpi"><span class="kpi-icon">↗</span><small>Rata-rata pre → post</small>
    <b><?= formatNumber($summary['pre_average']) ?> → <?= formatNumber($summary['post_average']) ?></b>
    <?php if ($improvement !== null): ?><em class="<?= $improvement >= 0 ? 'up' : 'down' ?>"><?= $improvement >= 0 ? '+' : '' ?><?= formatNumber($improvement) ?> poin</em><?php endif; ?>
  </div>
  <div class="kpi dark"><span class="kpi-icon">N</span><small>Rata-rata N-gain (<?= $summary['paired_count'] ?> pasang)</small>
    <b><?= formatNumber($summary['gain_average'], 2) ?></b><em><?= e(categorizeGain($summary['gain_average'])) ?></em></div>
</section>

<div class="panel-grid">
  <section class="panel span-2">
    <div class="panel-head"><h2>Rata-rata skor per materi</h2>
      <div class="legend"><span class="sw pre"></span>Pre-test <span class="sw post"></span>Post-test</div></div>
    <div class="column-chart">
      <?php foreach (TOPICS as $topicKey => $topicLabel): $avg = $summary['topics'][$topicKey]; ?>
        <div class="col-group">
          <div class="cols">
            <div class="col pre" style="height: <?= (float) $avg['pre'] ?>%"><span><?= formatNumber($avg['pre'], 0) ?></span></div>
            <div class="col post" style="height: <?= (float) $avg['post'] ?>%"><span><?= formatNumber($avg['post'], 0) ?></span></div>
          </div>
          <small><?= e($topicLabel) ?></small>
        </div>
      <?php endforeach; ?>
    </div>
  </section>

  <section class="panel">
    <div class="panel-head"><h2>Kategori N-gain</h2></div>
    <?php
      $high = $categoryTotal ? $summary['categories']['Tinggi'] / $categoryTotal * 100 : 0;
      $mid = $categoryTotal ? $summary['categories']['Sedang'] / $categoryTotal * 100 : 0;
    ?>
    <div class="donut" style="--high: <?= round($high, 1) ?>; --mid: <?= round($mid, 1) ?>">
      <div><b><?= $categoryTotal ?></b><small>pasang</small></div>
    </div>
    <ul class="donut-legend">
      <li><span class="sw high"></span>Tinggi (&gt; 0,7)<b><?= $summary['categories']['Tinggi'] ?></b></li>
      <li><span class="sw mid"></span>Sedang (0,3–0,7)<b><?= $summary['categories']['Sedang'] ?></b></li>
      <li><span class="sw low"></span>Rendah (&lt; 0,3)<b><?= $summary['categories']['Rendah'] ?></b></li>
    </ul>
  </section>

  <section class="panel">
    <div class="panel-head"><h2>Akses tes</h2></div>
    <?php foreach (TEST_TYPES as $type => $label): $open = isTestOpen($type); ?>
      <form method="post" class="switch-row">
        <?= csrfField() ?>
        <input type="hidden" name="toggle" value="<?= $type ?>">
        <div><b><?= e($label) ?></b><small><?= $open ? 'Peserta bisa mengerjakan' : 'Tertutup untuk peserta' ?></small></div>
        <button type="submit" class="switch <?= $open ? 'on' : '' ?>" aria-label="<?= $open ? 'Tutup' : 'Buka' ?> <?= e($label) ?>"><span></span></button>
      </form>
    <?php endforeach; ?>
  </section>

  <section class="panel span-2">
    <div class="panel-head"><h2>Aktivitas terbaru</h2><a href="peserta.php" class="panel-link">Lihat semua →</a></div>
    <?php if (!$recent): ?>
      <p class="empty">Belum ada peserta yang mengerjakan tes.</p>
    <?php else: ?>
      <ul class="activity">
        <?php foreach ($recent as $row): ?>
          <li>
            <span class="avatar"><?= e(mb_strtoupper(mb_substr($row['name'], 0, 1))) ?></span>
            <div><b><?= e($row['name']) ?></b><small>menyelesaikan <?= e(TEST_TYPES[$row['test_type']]) ?><?= maxAttempts($row['test_type']) > 1 ? ' (percobaan ' . (int) $row['attempt'] . ')' : '' ?> · <?= e($row['created_at']) ?></small></div>
            <span class="pill <?= $row['test_type'] ?>"><?= (int) $row['score'] ?></span>
          </li>
        <?php endforeach; ?>
      </ul>
    <?php endif; ?>
  </section>
</div>
<?php renderAdminFooter();
