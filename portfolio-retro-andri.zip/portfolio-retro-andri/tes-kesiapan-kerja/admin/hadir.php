<?php
declare(strict_types=1);
require __DIR__ . '/../inc/bootstrap.php';
require __DIR__ . '/../inc/admin_layout.php';
require __DIR__ . '/../inc/xlsx.php';
requireAdmin();

if (isset($_GET['export'])) {
    exportAttendance((int) $_GET['export']);
}

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $errors = handleAttendanceAction((string) ($_POST['action'] ?? ''));
    if (!$errors) {
        redirect('hadir.php');
    }
}

$sessions = db()->query('SELECT s.*, (SELECT COUNT(*) FROM attendance a WHERE a.session_id = s.id) AS total
    FROM attendance_sessions s ORDER BY s.session_date, s.id')->fetchAll();
$selectedId = (int) ($_GET['sesi'] ?? ($sessions[0]['id'] ?? 0));
$attendees = [];
if ($selectedId > 0) {
    $statement = db()->prepare('SELECT * FROM attendance WHERE session_id = ? ORDER BY created_at');
    $statement->execute([$selectedId]);
    $attendees = $statement->fetchAll();
}

renderAdminHeader('hadir', 'Daftar Hadir');
?>
<div class="panel-grid">
  <section class="panel">
    <div class="panel-head"><h2>Buat sesi</h2></div>
    <?php if ($errors): ?><div class="alert"><ul><?php foreach ($errors as $error): ?><li><?= e($error) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
    <form method="post" class="stack-form">
      <?= csrfField() ?>
      <input type="hidden" name="action" value="create">
      <label>Nama sesi<input name="title" required maxlength="150" placeholder="Sesi 1 — Pengenalan Dunia Kerja"></label>
      <label>Tanggal<input type="date" name="session_date" required value="<?= date('Y-m-d') ?>"></label>
      <button class="btn btn-primary" type="submit">Tambah sesi</button>
    </form>
  </section>

  <section class="panel span-2">
    <div class="panel-head"><h2>Sesi kegiatan</h2><a class="panel-link" href="../hadir.php" target="_blank" rel="noopener">Halaman absen peserta ↗</a></div>
    <?php if (!$sessions): ?><p class="empty">Belum ada sesi. Buat sesi untuk setiap pertemuan, lalu buka saat kegiatan berlangsung.</p><?php endif; ?>
    <?php foreach ($sessions as $session): ?>
      <div class="switch-row <?= (int) $session['id'] === $selectedId ? 'is-selected' : '' ?>">
        <div><a href="hadir.php?sesi=<?= (int) $session['id'] ?>"><b><?= e($session['title']) ?></b></a>
          <small><?= e($session['session_date']) ?> · <?= (int) $session['total'] ?> hadir</small></div>
        <div class="row-actions">
          <a class="btn btn-sm" href="hadir.php?export=<?= (int) $session['id'] ?>">Excel</a>
          <form method="post"><?= csrfField() ?><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?= (int) $session['id'] ?>">
            <button type="submit" class="switch <?= (int) $session['is_open'] === 1 ? 'on' : '' ?>" aria-label="Buka atau tutup sesi"><span></span></button></form>
          <form method="post" onsubmit="return confirm('Hapus sesi beserta data kehadirannya?');"><?= csrfField() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int) $session['id'] ?>">
            <button type="submit" class="link-danger">Hapus</button></form>
        </div>
      </div>
    <?php endforeach; ?>
  </section>

  <?php if ($selectedId > 0): ?>
  <section class="panel span-3 table-wrap">
    <div class="panel-head"><h2>Peserta hadir (<?= count($attendees) ?>)</h2></div>
    <table class="data-table">
      <thead><tr><th>#</th><th>Nama</th><th>WhatsApp</th><th>Kelurahan</th><th>Waktu absen</th></tr></thead>
      <tbody>
        <?php if (!$attendees): ?><tr><td colspan="5" class="empty">Belum ada yang absen di sesi ini.</td></tr><?php endif; ?>
        <?php foreach ($attendees as $index => $row): ?>
          <tr><td><?= $index + 1 ?></td><td><?= e($row['name']) ?></td><td><?= e($row['phone']) ?></td><td><?= e($row['kelurahan']) ?></td><td><?= e($row['created_at']) ?></td></tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </section>
  <?php endif; ?>
</div>
<?php renderAdminFooter();

/** @return list<string> */
function handleAttendanceAction(string $action): array
{
    $id = (int) ($_POST['id'] ?? 0);
    if ($action === 'create') {
        $title = trim((string) ($_POST['title'] ?? ''));
        $date = (string) ($_POST['session_date'] ?? '');
        $errors = [];
        if ($title === '' || mb_strlen($title) > 150) {
            $errors[] = 'Nama sesi wajib diisi.';
        }
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
            $errors[] = 'Tanggal tidak valid.';
        }
        if ($errors) {
            return $errors;
        }
        db()->prepare('INSERT INTO attendance_sessions (title, session_date, is_open, created_at) VALUES (?, ?, 0, ?)')
            ->execute([$title, $date, date('Y-m-d H:i:s')]);
        $_SESSION['flash'] = 'Sesi ditambahkan. Buka sesi saat kegiatan dimulai.';
    }
    if ($action === 'toggle') {
        db()->prepare('UPDATE attendance_sessions SET is_open = 1 - is_open WHERE id = ?')->execute([$id]);
        $_SESSION['flash'] = 'Status sesi diperbarui.';
    }
    if ($action === 'delete') {
        db()->prepare('DELETE FROM attendance WHERE session_id = ?')->execute([$id]);
        db()->prepare('DELETE FROM attendance_sessions WHERE id = ?')->execute([$id]);
        $_SESSION['flash'] = 'Sesi dihapus.';
    }
    return [];
}

function exportAttendance(int $sessionId): never
{
    $session = db()->prepare('SELECT * FROM attendance_sessions WHERE id = ?');
    $session->execute([$sessionId]);
    $info = $session->fetch() ?: ['title' => 'sesi', 'session_date' => ''];
    $statement = db()->prepare('SELECT * FROM attendance WHERE session_id = ? ORDER BY created_at');
    $statement->execute([$sessionId]);
    $rows = [];
    foreach ($statement->fetchAll() as $index => $row) {
        $rows[] = [$index + 1, $row['name'], $row['phone'], $row['kelurahan'], $row['created_at'], ''];
    }
    $slug = trim((string) preg_replace('/[^a-z0-9]+/', '-', strtolower($info['title'])), '-') ?: 'sesi';
    sendXlsx("daftar-hadir-{$slug}.xlsx", [
        'Daftar Hadir' => [
            'title' => "Daftar Hadir: {$info['title']} ({$info['session_date']})",
            'columns' => [['No', 5, 'int'], ['Nama', 28, 'text'], ['WhatsApp', 16, 'text'], ['Kelurahan', 18, 'text'], ['Waktu Absen', 19, 'text'], ['Tanda Tangan', 22, 'text']],
            'rows' => $rows,
        ],
    ]);
}
