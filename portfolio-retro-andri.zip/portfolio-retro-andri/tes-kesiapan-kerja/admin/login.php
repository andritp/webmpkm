<?php
declare(strict_types=1);
require __DIR__ . '/../inc/bootstrap.php';

const MAX_LOGIN_ATTEMPTS = 5;
const LOCKOUT_SECONDS = 300;

$error = '';
$lockedUntil = (int) ($_SESSION['login_locked_until'] ?? 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    if ($lockedUntil > time() || isLoginBlocked('admin')) {
        $error = 'Terlalu banyak percobaan. Coba lagi dalam beberapa menit.';
    } elseif (password_verify((string) ($_POST['password'] ?? ''), adminPasswordHash())) {
        session_regenerate_id(true);
        $_SESSION['is_admin'] = true;
        unset($_SESSION['login_attempts'], $_SESSION['login_locked_until']);
        clearLoginFailures('admin');
        redirect('index.php');
    } else {
        recordLoginFailure('admin');
        $_SESSION['login_attempts'] = (int) ($_SESSION['login_attempts'] ?? 0) + 1;
        if ($_SESSION['login_attempts'] >= MAX_LOGIN_ATTEMPTS) {
            $_SESSION['login_locked_until'] = time() + LOCKOUT_SECONDS;
            $_SESSION['login_attempts'] = 0;
        }
        $error = 'Password salah.';
    }
}

?>
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Login — Panel Admin</title>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="<?= e(asset('assets/style.css', '../')) ?>">
  <link rel="stylesheet" href="<?= e(asset('assets/admin.css', '../')) ?>">
</head>
<body class="login-body">
  <div class="login-shell">
    <aside class="login-art">
      <div class="login-logos">
        <img src="../assets/logo-ut-white.png" alt="Universitas Terbuka">
        <span aria-hidden="true">×</span>
        <img src="../assets/logo-aytindeso-light.png" alt="AYTINDESO">
      </div>
      <p class="kicker">Panel Admin · Tes Kesiapan Kerja</p>
      <h1>Selamat datang, <span class="hl">Panitia!</span></h1>
      <p class="login-quote">“Setiap data yang kamu kelola hari ini adalah langkah kecil menuju pemuda yang siap kerja.”</p>
      <p>Kelola pre-test, post-test, kuesioner, dan sertifikat pelatihan pemuda Karang Taruna Kecamatan Jatisampurna.</p>
    </aside>
    <form method="post" class="login-form">
      <?= csrfField() ?>
      <h2>Masuk</h2>
      <p class="hint">Khusus panitia MK-PM Kelompok 1.</p>
      <?php if ($error): ?><div class="alert"><?= e($error) ?></div><?php endif; ?>
      <label>Password<input type="password" name="password" required autofocus autocomplete="current-password"></label>
      <button class="btn btn-primary btn-lg" type="submit">Masuk ke panel</button>
      <a class="back-link" href="../index.php">← Kembali ke halaman peserta</a>
    </form>
  </div>
</body>
</html>
