<?php
declare(strict_types=1);
require __DIR__ . '/../inc/bootstrap.php';
require __DIR__ . '/../inc/admin_layout.php';
requireAdmin();

$scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$baseUrl = $scheme . '://' . $_SERVER['HTTP_HOST'] . rtrim(dirname(dirname($_SERVER['SCRIPT_NAME'])), '/\\') . '/';
$targets = [
    'beranda' => ['label' => 'Beranda tes', 'path' => 'index.php'],
    'pre' => ['label' => 'Pre-test', 'path' => 'tes.php?type=pre'],
    'post' => ['label' => 'Post-test', 'path' => 'tes.php?type=post'],
    'hadir' => ['label' => 'Daftar hadir', 'path' => 'hadir.php'],
    'area' => ['label' => 'Area peserta', 'path' => 'area.php'],
    'materi' => ['label' => 'Materi', 'path' => 'materi.php'],
];

renderAdminHeader('qr', 'QR Code');
?>
<p class="page-note">Tampilkan QR di slide atau cetak untuk ditempel saat acara. Peserta tinggal scan dengan kamera HP.
  <?php if (str_contains($baseUrl, 'localhost')): ?><b>Catatan:</b> alamat masih <code>localhost</code>, QR baru bisa dipakai peserta setelah web di-online-kan.<?php endif; ?></p>

<div class="panel-grid">
  <section class="panel">
    <div class="panel-head"><h2>Pilih tujuan</h2></div>
    <div class="qr-targets">
      <?php foreach ($targets as $key => $target): ?>
        <label class="option"><input type="radio" name="qr-target" value="<?= e($baseUrl . $target['path']) ?>" data-label="<?= e($target['label']) ?>" <?= $key === 'beranda' ? 'checked' : '' ?>>
          <span class="opt-letter">◎</span><span><?= e($target['label']) ?></span></label>
      <?php endforeach; ?>
    </div>
  </section>

  <section class="panel span-2 qr-preview">
    <div class="qr-poster" id="qr-poster">
      <p class="kicker">Scan untuk membuka</p>
      <h2 id="qr-title">Beranda tes</h2>
      <div id="qr-code" class="qr-code"></div>
      <code id="qr-url"></code>
      <p class="qr-foot">Belajar Bersama, Tumbuh Bersama · Kelompok 1 MK-PM UT</p>
    </div>
    <div class="form-actions">
      <button class="btn" type="button" id="qr-copy">Salin link</button>
      <button class="btn" type="button" onclick="window.print()">Cetak poster</button>
      <button class="btn btn-primary" type="button" id="qr-download">Unduh PNG</button>
    </div>
  </section>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
<script>
(function initQr() {
  const QR_SIZE = 260;
  const container = document.getElementById('qr-code');
  const urlLabel = document.getElementById('qr-url');
  const title = document.getElementById('qr-title');
  let currentUrl = '';

  function render(radio) {
    currentUrl = radio.value;
    container.innerHTML = '';
    new QRCode(container, { text: currentUrl, width: QR_SIZE, height: QR_SIZE, colorDark: '#0b1240', colorLight: '#ffffff', correctLevel: QRCode.CorrectLevel.H });
    urlLabel.textContent = currentUrl;
    title.textContent = radio.dataset.label;
  }

  document.querySelectorAll('input[name=qr-target]').forEach((radio) => radio.addEventListener('change', () => render(radio)));
  render(document.querySelector('input[name=qr-target]:checked'));

  document.getElementById('qr-download').addEventListener('click', () => {
    const canvas = container.querySelector('canvas');
    if (!canvas) return;
    const link = document.createElement('a');
    link.href = canvas.toDataURL('image/png');
    link.download = `qr-${title.textContent.toLowerCase().replace(/\s+/g, '-')}.png`;
    link.click();
  });
  document.getElementById('qr-copy').addEventListener('click', async (event) => {
    try {
      await navigator.clipboard.writeText(currentUrl);
      event.target.textContent = 'Tersalin ✓';
    } catch (error) {
      console.error('Clipboard write failed', error);
      event.target.textContent = 'Gagal menyalin';
    }
    setTimeout(() => { event.target.textContent = 'Salin link'; }, 1500);
  });
})();
</script>
<?php renderAdminFooter();
