# Pre-test and Post-test Kesiapan Kerja

Web app for the MK-PM Kelompok 1 Universitas Terbuka program: "Program Pelatihan Kesiapan Kerja bagi Pemuda Karang Taruna melalui Pengenalan Dunia Kerja di Kecamatan Jatisampurna Kota Bekasi".

- 20 starter multiple-choice questions, 4 per topic (Dunia Kerja, Budaya dan Etika Kerja, CV, Surat Lamaran, LinkedIn).
- The same questions are used for the pre-test and the post-test. Question and option order is shuffled for each participant.
- Pre-test and post-test results are paired by WhatsApp number. Results include an N-gain score (Hake).
- The admin panel (`/admin/`) includes these pages:
  - Dashboard: KPIs, average score per topic, N-gain categories, test access switches, and recent activity.
  - Data Peserta: search, filter, delete a submission, and CSV export for Excel.
  - Bank Soal: add, edit, deactivate, or delete questions. Questions are stored in the database. The 20 built-in questions in `inc/questions.php` are only copied in on the first run.
  - Analisis Soal: percent correct per question for pre-test and post-test, with a difficulty label.
  - Pengaturan: test access, admin password change (stored in the database), and a full data reset.
- Participant pages:
  - `area.php`: participants sign in with name and WhatsApp number to see their scores and next steps.
  - `pembahasan.php`: answer review, available after all post-test attempts are used.
  - `kuesioner.php`: satisfaction survey on a 1–5 scale.
  - `sertifikat.php`: printable A4 certificate, available after the post-test and the survey.
  - `tugas.php`: LinkedIn link, CV, and cover letter upload.
  - `materi.php`: downloads.
  - `hadir.php`: digital attendance.
- The test page autosaves answers in the browser and has an optional countdown timer (Pengaturan, default 15 minutes).
- Admin pages added for Daftar Hadir, Materi, Penilaian Produk, Kuesioner, and QR Code.
- Uploaded files are stored in `uploads/` under random names, are blocked from direct access, and are served through PHP.
- `php tests/seed_demo.php` fills the database with 10 fictional participants for previewing the panel.

## Run locally

```bash
php -S localhost:8090 -t .
```

Open <http://localhost:8090>. The admin page is at `/admin/`, and the local password is written in `config.php`. Local data is stored in SQLite at `data/tes.sqlite`. Delete that file to reset.

## Tests

```bash
php tests/scoring_test.php
php tests/question_validation_test.php
php tests/features_test.php
```

## Deploy to cPanel

1. In cPanel → **MySQL Databases**, create a database and a user, then give the user ALL PRIVILEGES on the database.
2. Upload the whole folder, for example to a subdomain such as `tes.aytindeso.com`.
3. Edit `config.php`:
   - Set `'db_driver' => 'mysql'`.
   - Fill in `host`, `name`, `user`, and `pass`.
   - Replace `admin_password_hash` with a new hash: `php -r "echo password_hash('newPassword', PASSWORD_DEFAULT);"`
4. Open the site. The tables are created automatically on the first visit.
5. Enable SSL (AutoSSL) so the site runs on HTTPS.

The `.htaccess` files block direct access to `config.php`, `inc/`, `data/`, and `tests/`.
