<?php
declare(strict_types=1);
require __DIR__ . '/inc/bootstrap.php';

$testType = (string) ($_GET['type'] ?? '');
if (!array_key_exists($testType, TEST_TYPES)) {
    redirect('index.php');
}
if (!isTestOpen($testType)) {
    renderHeader(APP_TITLE);
    echo '<div class="notice">' . e(TEST_TYPES[$testType]) . ' belum dibuka oleh panitia. <a href="index.php">Kembali</a></div>';
    renderFooter();
    exit;
}

$errors = $_SESSION['form_errors'] ?? [];
// Prefill from the previous attempt only for post-test retakes, so a shared device does not leak the last participant's data into a pre-test.
$old = $_SESSION['form_old'] ?? ($testType === 'post' ? ($_SESSION['last_identity'] ?? []) : []);
unset($_SESSION['form_errors'], $_SESSION['form_old']);

$oldValue = static fn (string $key): string => e((string) ($old[$key] ?? ''));
$questions = getQuestions();
shuffle($questions);

renderHeader(TEST_TYPES[$testType] . ' — ' . APP_TITLE);
?>
<div class="progress" aria-hidden="true" hidden id="progress"><div class="progress-bar" id="progress-bar"></div></div>

<form method="post" action="kirim.php" class="test-form" id="test-form" novalidate
      data-type="<?= e($testType) ?>" data-count="<?= count($questions) ?>" data-label="<?= e(TEST_TYPES[$testType]) ?>"
      data-skip-intro="<?= isset($old['answers']) && $old['answers'] ? '1' : '0' ?>">
  <?= csrfField() ?>
  <input type="hidden" name="type" value="<?= e($testType) ?>">
  <input type="hidden" name="timed_out" id="timed-out" value="0">

  <h1 class="page-title"><?= e(TEST_TYPES[$testType]) ?></h1>
  <?php if ($errors): ?>
    <div class="alert"><b>Periksa kembali isian kamu:</b><ul>
      <?php foreach ($errors as $error): ?><li><?= e($error) ?></li><?php endforeach; ?>
    </ul></div>
  <?php endif; ?>

  <section id="step-identity">
  <fieldset class="card">
    <legend><span class="q-num">1</span>Data peserta</legend>
    <p class="hint">Gunakan nama dan nomor WhatsApp yang <b>sama</b> saat pre-test dan post-test.</p>
    <div class="field-grid">
      <label>Nama lengkap<input name="name" required maxlength="100" value="<?= $oldValue('name') ?>" placeholder="Budi Santoso"></label>
      <label>Nomor WhatsApp<input name="phone" required inputmode="tel" maxlength="20" value="<?= $oldValue('phone') ?>" placeholder="0812xxxxxxxx"></label>
      <label>Jenis kelamin
        <select name="gender" required>
          <option value="">Pilih…</option>
          <?php foreach (['L' => 'Laki-laki', 'P' => 'Perempuan'] as $value => $label): ?>
            <option value="<?= $value ?>" <?= ($old['gender'] ?? '') === $value ? 'selected' : '' ?>><?= $label ?></option>
          <?php endforeach; ?>
        </select>
      </label>
      <label>Usia<input name="age" type="number" min="13" max="40" required value="<?= $oldValue('age') ?>" placeholder="20"></label>
      <label class="span-2">Kelurahan<input name="kelurahan" required maxlength="60" value="<?= $oldValue('kelurahan') ?>" placeholder="Jatisampurna"></label>
    </div>
    <?= privacyNote() ?>
    <p class="form-error" id="identity-error" role="alert"></p>
    <div class="step-actions">
      <button type="button" class="btn btn-primary btn-lg" id="identity-next">Lanjut →</button>
    </div>
  </fieldset>
  </section>

  <section id="step-questions" hidden>
  <div class="timer" id="timer" hidden aria-live="polite"><span>Sisa waktu</span><b id="timer-value">--:--</b></div>
  <div class="notice draft-notice" id="draft-notice" hidden>Jawaban yang belum terkirim sebelumnya sudah dipulihkan.</div>

  <?php foreach ($questions as $index => $question):
      $options = $question['options'];
      $optionKeys = array_keys($options);
      shuffle($optionKeys);
      $chosen = $old['answers'][$question['id']] ?? '';
  ?>
    <fieldset class="card question" data-question>
      <legend><span class="q-num"><?= $index + 1 ?></span><?= e(TOPICS[$question['topic']]) ?></legend>
      <p class="q-text"><?= e($question['text']) ?></p>
      <?php foreach ($optionKeys as $position => $key): ?>
        <label class="option">
          <input type="radio" name="answers[<?= $question['id'] ?>]" value="<?= $key ?>" required <?= $chosen === $key ? 'checked' : '' ?>>
          <span class="opt-letter"><?= chr(65 + $position) ?></span>
          <span><?= e($options[$key]) ?></span>
        </label>
      <?php endforeach; ?>
    </fieldset>
  <?php endforeach; ?>

  <div class="submit-bar">
    <span id="answered-count">0 / <?= count($questions) ?> terjawab</span>
    <button type="submit" class="btn btn-primary">Kirim jawaban</button>
  </div>
  <p class="form-error" id="form-error" role="alert"></p>
  </section>
</form>

<div class="overlay" id="loading-overlay" hidden aria-live="polite">
  <div class="loader">
    <div class="loader-orbit">
      <span class="ring ring-gold"></span>
      <span class="ring ring-navy"></span>
      <span class="ring ring-dash"></span>
      <span class="dot dot-a"></span><span class="dot dot-b"></span><span class="dot dot-c"></span>
      <div class="loader-core"><img src="assets/logo-ut.png" alt=""></div>
    </div>
    <p class="loader-title">Mohon tunggu…</p>
    <p class="loader-status" id="loader-status">Memverifikasi data peserta</p>
    <div class="loader-bar"><span id="loader-fill"></span></div>
  </div>
</div>

<div class="overlay" id="confirm-modal" hidden>
  <div class="modal" role="dialog" aria-modal="true" aria-labelledby="confirm-title">
    <div class="modal-icon">?</div>
    <h2 id="confirm-title">Apakah kamu yakin ingin mengerjakan <span id="confirm-label"></span>?</h2>
    <p class="modal-name">Halo, <b id="confirm-name"></b></p>
    <ul class="modal-facts">
      <li><b><?= count($questions) ?></b> soal</li>
      <li><b>± 15</b> menit</li>
      <li><b id="confirm-attempt">1/<?= maxAttempts($testType) ?></b> percobaan</li>
    </ul>
    <p class="hint"><?= maxAttempts($testType) > 1
      ? "Kamu punya " . maxAttempts($testType) . " kesempatan. Nilai terbaik yang dipakai sebagai hasil akhir."
      : "Jawaban hanya bisa dikirim satu kali. Pastikan koneksi internet stabil." ?></p>
    <div class="modal-actions">
      <button type="button" class="btn" id="confirm-cancel">Batal</button>
      <button type="button" class="btn btn-primary btn-lg" id="confirm-start">MULAI</button>
    </div>
  </div>
</div>
<script src="<?= e(asset('assets/app.js')) ?>"></script>
<?php renderFooter();
