<?php
declare(strict_types=1);

const UPLOAD_DIR = __DIR__ . '/../uploads';
const MAX_UPLOAD_BYTES = 5 * 1024 * 1024;
const MAX_MATERIAL_BYTES = 20 * 1024 * 1024;
const ASSIGNMENT_EXTENSIONS = ['pdf', 'doc', 'docx', 'jpg', 'jpeg', 'png'];
const MATERIAL_EXTENSIONS = ['pdf', 'doc', 'docx', 'ppt', 'pptx', 'xls', 'xlsx', 'jpg', 'jpeg', 'png', 'zip'];

function ensureFeatureSchema(PDO $pdo, string $autoId, string $engine): void
{
    ensureSurveySchema($pdo, $autoId, $engine);
    $pdo->exec("CREATE TABLE IF NOT EXISTS login_failures (
        id {$autoId}, scope VARCHAR(20) NOT NULL, ip VARCHAR(45) NOT NULL, attempted_at INT NOT NULL
    ){$engine}");
    $pdo->exec("CREATE TABLE IF NOT EXISTS certificates (
        id {$autoId}, phone VARCHAR(20) NOT NULL UNIQUE, name VARCHAR(100) NOT NULL,
        number VARCHAR(60) NOT NULL, issued_at VARCHAR(19) NOT NULL
    ){$engine}");
    $pdo->exec("CREATE TABLE IF NOT EXISTS materials (
        id {$autoId}, title VARCHAR(150) NOT NULL, description VARCHAR(300) NOT NULL,
        stored_name VARCHAR(80) NOT NULL, original_name VARCHAR(200) NOT NULL, size INT NOT NULL,
        download_count INT NOT NULL DEFAULT 0, created_at VARCHAR(19) NOT NULL
    ){$engine}");
    $pdo->exec("CREATE TABLE IF NOT EXISTS assignments (
        id {$autoId}, phone VARCHAR(20) NOT NULL UNIQUE, name VARCHAR(100) NOT NULL,
        linkedin_url VARCHAR(255) NOT NULL DEFAULT '', cv_file VARCHAR(80) NOT NULL DEFAULT '', cv_original VARCHAR(200) NOT NULL DEFAULT '',
        letter_file VARCHAR(80) NOT NULL DEFAULT '', letter_original VARCHAR(200) NOT NULL DEFAULT '',
        score_cv INT NULL, score_letter INT NULL, score_linkedin INT NULL,
        linkedin_verified INT NOT NULL DEFAULT 0, notes VARCHAR(500) NOT NULL DEFAULT '', updated_at VARCHAR(19) NOT NULL
    ){$engine}");
    $pdo->exec("CREATE TABLE IF NOT EXISTS attendance_sessions (
        id {$autoId}, title VARCHAR(150) NOT NULL, session_date VARCHAR(10) NOT NULL,
        is_open INT NOT NULL DEFAULT 0, created_at VARCHAR(19) NOT NULL
    ){$engine}");
    $pdo->exec("CREATE TABLE IF NOT EXISTS attendance (
        id {$autoId}, session_id INT NOT NULL, phone VARCHAR(20) NOT NULL, name VARCHAR(100) NOT NULL,
        kelurahan VARCHAR(60) NOT NULL, created_at VARCHAR(19) NOT NULL, UNIQUE (session_id, phone)
    ){$engine}");
}

/** @return array{phone:string, name:string}|null */
function currentParticipant(): ?array
{
    return $_SESSION['participant'] ?? null;
}

/** @return array{phone:string, name:string} */
function requireParticipant(): array
{
    $participant = currentParticipant();
    if ($participant === null) {
        redirect('area.php');
    }
    return $participant;
}

/** Phone number plus a matching name (case-insensitive) identifies a participant who has taken a test. */
function findParticipantIdentity(string $phone, string $name): ?array
{
    $statement = db()->prepare('SELECT name, gender, age, kelurahan FROM submissions WHERE phone = ? ORDER BY id DESC LIMIT 1');
    $statement->execute([$phone]);
    $row = $statement->fetch();
    if (!$row || mb_strtolower(trim($row['name'])) !== mb_strtolower(trim($name))) {
        return null;
    }
    return ['phone' => $phone, 'name' => $row['name']];
}

/** @return array<string, list<array<string, mixed>>> test type => attempts ordered */
function participantAttempts(string $phone): array
{
    $statement = db()->prepare('SELECT * FROM submissions WHERE phone = ? ORDER BY test_type, attempt');
    $statement->execute([$phone]);
    $attempts = ['pre' => [], 'post' => []];
    foreach ($statement->fetchAll() as $row) {
        $attempts[$row['test_type']][] = $row;
    }
    return $attempts;
}

function findSurvey(string $phone): ?array
{
    $statement = db()->prepare('SELECT * FROM surveys WHERE phone = ?');
    $statement->execute([$phone]);
    return $statement->fetch() ?: null;
}

function findAssignment(string $phone): ?array
{
    $statement = db()->prepare('SELECT * FROM assignments WHERE phone = ?');
    $statement->execute([$phone]);
    return $statement->fetch() ?: null;
}

/** Issues the certificate once; the sequence follows issue order so numbers never change. */
function issueCertificate(string $phone, string $name): array
{
    $statement = db()->prepare('SELECT * FROM certificates WHERE phone = ?');
    $statement->execute([$phone]);
    $existing = $statement->fetch();
    if ($existing) {
        return $existing;
    }
    $sequence = (int) db()->query('SELECT COUNT(*) FROM certificates')->fetchColumn() + 1;
    $number = formatCertificateNumber($sequence, (int) date('Y'));
    db()->prepare('INSERT INTO certificates (phone, name, number, issued_at) VALUES (?, ?, ?, ?)')
        ->execute([$phone, $name, $number, date('Y-m-d H:i:s')]);
    return ['phone' => $phone, 'name' => $name, 'number' => $number, 'issued_at' => date('Y-m-d H:i:s')];
}

/**
 * Moves a validated upload into the protected uploads folder under a random name.
 * @param array{name:string, size:int, error:int, tmp_name:string} $file
 */
function storeUpload(array $file): string
{
    if (!is_dir(UPLOAD_DIR)) {
        mkdir(UPLOAD_DIR, 0775, true);
    }
    $storedName = bin2hex(random_bytes(16)) . '.' . fileExtension($file['name']);
    if (!move_uploaded_file($file['tmp_name'], UPLOAD_DIR . '/' . $storedName)) {
        throw new RuntimeException('Failed to store uploaded file');
    }
    return $storedName;
}

function deleteStoredFile(string $storedName): void
{
    $path = UPLOAD_DIR . '/' . basename($storedName);
    if ($storedName !== '' && is_file($path)) {
        unlink($path);
    }
}

function sendStoredFile(string $storedName, string $downloadName): never
{
    $path = UPLOAD_DIR . '/' . basename($storedName);
    if ($storedName === '' || !is_file($path)) {
        http_response_code(404);
        exit('File tidak ditemukan.');
    }
    $safeName = preg_replace('/[^A-Za-z0-9 ._\-]/', '_', $downloadName) ?: 'file';
    header('Content-Type: application/octet-stream');
    header('Content-Length: ' . filesize($path));
    header('Content-Disposition: attachment; filename="' . $safeName . '"');
    header('X-Content-Type-Options: nosniff');
    readfile($path);
    exit;
}

const LOGIN_MAX_FAILURES = 8;
const LOGIN_WINDOW_SECONDS = 600;

function clientIp(): string
{
    return substr((string) ($_SERVER['REMOTE_ADDR'] ?? 'unknown'), 0, 45);
}

/** Failed logins are tracked per IP in the database, so clearing cookies does not reset the limit. */
function isLoginBlocked(string $scope): bool
{
    $statement = db()->prepare('SELECT attempted_at FROM login_failures WHERE scope = ? AND ip = ? AND attempted_at > ?');
    $statement->execute([$scope, clientIp(), time() - LOGIN_WINDOW_SECONDS]);
    $timestamps = array_map('intval', $statement->fetchAll(PDO::FETCH_COLUMN));
    return isRateLimited($timestamps, time(), LOGIN_MAX_FAILURES, LOGIN_WINDOW_SECONDS);
}

function recordLoginFailure(string $scope): void
{
    db()->prepare('INSERT INTO login_failures (scope, ip, attempted_at) VALUES (?, ?, ?)')->execute([$scope, clientIp(), time()]);
    db()->prepare('DELETE FROM login_failures WHERE attempted_at < ?')->execute([time() - LOGIN_WINDOW_SECONDS * 6]);
}

function clearLoginFailures(string $scope): void
{
    db()->prepare('DELETE FROM login_failures WHERE scope = ? AND ip = ?')->execute([$scope, clientIp()]);
}
