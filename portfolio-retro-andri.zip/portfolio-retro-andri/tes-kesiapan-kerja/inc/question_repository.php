<?php
declare(strict_types=1);

/** Copies the built-in question bank into an empty questions table, keeping the original ids. */
function seedDefaultQuestions(PDO $pdo): void
{
    if ((int) $pdo->query('SELECT COUNT(*) FROM questions')->fetchColumn() > 0) {
        return;
    }
    $insert = $pdo->prepare('INSERT INTO questions
        (id, topic, text, option_a, option_b, option_c, option_d, answer, is_active, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?)');
    foreach (getDefaultQuestions() as $question) {
        $options = $question['options'];
        $insert->execute([$question['id'], $question['topic'], $question['text'],
            $options['a'], $options['b'], $options['c'], $options['d'], $question['answer'], date('Y-m-d H:i:s')]);
    }
}

/**
 * @param array<string, mixed> $row
 * @return array{id:int, topic:string, text:string, options:array<string,string>, answer:string, is_active:bool}
 */
function mapQuestionRow(array $row): array
{
    return [
        'id' => (int) $row['id'],
        'topic' => $row['topic'],
        'text' => $row['text'],
        'options' => ['a' => $row['option_a'], 'b' => $row['option_b'], 'c' => $row['option_c'], 'd' => $row['option_d']],
        'answer' => $row['answer'],
        'is_active' => (int) $row['is_active'] === 1,
    ];
}

/** Active questions used in the pre-test and post-test. */
function getQuestions(): array
{
    $rows = db()->query('SELECT * FROM questions WHERE is_active = 1 ORDER BY id')->fetchAll();
    return array_map('mapQuestionRow', $rows);
}

function getAllQuestions(): array
{
    return array_map('mapQuestionRow', db()->query('SELECT * FROM questions ORDER BY id')->fetchAll());
}

function findQuestion(int $id): ?array
{
    $statement = db()->prepare('SELECT * FROM questions WHERE id = ?');
    $statement->execute([$id]);
    $row = $statement->fetch();
    return $row ? mapQuestionRow($row) : null;
}

/** @param array{topic:string, text:string, options:array<string,string>, answer:string} $data */
function saveQuestion(?int $id, array $data): void
{
    $options = $data['options'];
    $values = [$data['topic'], $data['text'], $options['a'], $options['b'], $options['c'], $options['d'], $data['answer']];
    if ($id === null) {
        db()->prepare('INSERT INTO questions (topic, text, option_a, option_b, option_c, option_d, answer, is_active, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?)')->execute([...$values, date('Y-m-d H:i:s')]);
        return;
    }
    db()->prepare('UPDATE questions SET topic = ?, text = ?, option_a = ?, option_b = ?, option_c = ?, option_d = ?, answer = ?
        WHERE id = ?')->execute([...$values, $id]);
}

function setQuestionActive(int $id, bool $isActive): void
{
    db()->prepare('UPDATE questions SET is_active = ? WHERE id = ?')->execute([$isActive ? 1 : 0, $id]);
}

function deleteQuestion(int $id): void
{
    db()->prepare('DELETE FROM questions WHERE id = ?')->execute([$id]);
}
