<?php
declare(strict_types=1);

require_once __DIR__ . '/scoring.php';
require_once __DIR__ . '/questions.php';
require_once __DIR__ . '/question_validation.php';
require_once __DIR__ . '/question_repository.php';
require_once __DIR__ . '/features.php';
require_once __DIR__ . '/participant.php';
require_once __DIR__ . '/survey_repository.php';

const TEST_TYPES = ['pre' => 'Pre-test', 'post' => 'Post-test'];
const APP_TITLE = 'Tes Kesiapan Kerja — Karang Taruna Jatisampurna';

date_default_timezone_set('Asia/Jakarta');

// Errors are shown only on the local dev server; on the live host they go to the error log.
const IS_LOCAL_DEV = PHP_SAPI === 'cli-server' || PHP_SAPI === 'cli';
ini_set('display_errors', IS_LOCAL_DEV ? '1' : '0');
ini_set('log_errors', '1');

$isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax', 'secure' => $isHttps]);
session_start();

if (PHP_SAPI !== 'cli' && !headers_sent()) {
    header('X-Frame-Options: SAMEORIGIN');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: strict-origin-when-cross-origin');
}

/** @return array<string, mixed> */
function appConfig(): array
{
    static $config = null;
    if ($config === null) {
        $config = require __DIR__ . '/../config.php';
    }
    return $config;
}

function db(): PDO
{
    static $pdo = null;
    if ($pdo !== null) {
        return $pdo;
    }
    $config = appConfig();
    $options = [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC];

    if ($config['db_driver'] === 'mysql') {
        $mysql = $config['mysql'];
        $dsn = "mysql:host={$mysql['host']};dbname={$mysql['name']};charset=utf8mb4";
        try {
            $pdo = new PDO($dsn, $mysql['user'], $mysql['pass'], $options);
        } catch (PDOException $exception) {
            error_log('Database connection failed: ' . $exception->getMessage());
            http_response_code(503);
            exit('Web sedang disiapkan: database belum terhubung. Panitia, periksa pengaturan database di config.php.');
        }
    } else {
        $directory = dirname($config['sqlite_path']);
        if (!is_dir($directory)) {
            mkdir($directory, 0775, true);
        }
        $pdo = new PDO('sqlite:' . $config['sqlite_path'], null, null, $options);
    }
    ensureSchema($pdo, $config['db_driver']);
    return $pdo;
}

function submissionsTableSql(string $table, string $autoId, string $engine): string
{
    return "CREATE TABLE IF NOT EXISTS {$table} (
        id {$autoId},
        test_type VARCHAR(4) NOT NULL,
        attempt INT NOT NULL DEFAULT 1,
        name VARCHAR(100) NOT NULL,
        phone VARCHAR(20) NOT NULL,
        gender VARCHAR(10) NOT NULL,
        age INT NOT NULL,
        kelurahan VARCHAR(60) NOT NULL,
        correct INT NOT NULL,
        total INT NOT NULL,
        score INT NOT NULL,
        by_topic TEXT NOT NULL,
        answers TEXT NOT NULL,
        created_at VARCHAR(19) NOT NULL,
        UNIQUE (phone, test_type, attempt)
    ){$engine}";
}

/** Upgrades databases created before multiple post-test attempts existed (old UNIQUE(phone, test_type)). */
function migrateSubmissionAttempts(PDO $pdo, string $autoId, string $engine): void
{
    try {
        $pdo->query('SELECT attempt FROM submissions LIMIT 1');
        return;
    } catch (PDOException $exception) {
        error_log('Migrating submissions table to support attempts: ' . $exception->getMessage());
    }
    $pdo->beginTransaction();
    try {
        $pdo->exec('ALTER TABLE submissions RENAME TO submissions_old');
        $pdo->exec(submissionsTableSql('submissions', $autoId, $engine));
        $pdo->exec('INSERT INTO submissions (id, test_type, attempt, name, phone, gender, age, kelurahan, correct, total, score, by_topic, answers, created_at)
            SELECT id, test_type, 1, name, phone, gender, age, kelurahan, correct, total, score, by_topic, answers, created_at FROM submissions_old');
        $pdo->exec('DROP TABLE submissions_old');
        // MySQL commits DDL implicitly, so the transaction may already be closed here.
        if ($pdo->inTransaction()) {
            $pdo->commit();
        }
    } catch (PDOException $exception) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw new RuntimeException('Failed to migrate submissions table', 0, $exception);
    }
}

function ensureSchema(PDO $pdo, string $driver): void
{
    $autoId = $driver === 'mysql' ? 'INT AUTO_INCREMENT PRIMARY KEY' : 'INTEGER PRIMARY KEY AUTOINCREMENT';
    $engine = $driver === 'mysql' ? ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4' : '';
    $pdo->exec(submissionsTableSql('submissions', $autoId, $engine));
    migrateSubmissionAttempts($pdo, $autoId, $engine);
    $pdo->exec("CREATE TABLE IF NOT EXISTS settings (
        setting_key VARCHAR(40) PRIMARY KEY,
        setting_value VARCHAR(255) NOT NULL
    ){$engine}");
    $pdo->exec("CREATE TABLE IF NOT EXISTS questions (
        id {$autoId},
        topic VARCHAR(20) NOT NULL,
        text TEXT NOT NULL,
        option_a VARCHAR(300) NOT NULL,
        option_b VARCHAR(300) NOT NULL,
        option_c VARCHAR(300) NOT NULL,
        option_d VARCHAR(300) NOT NULL,
        answer CHAR(1) NOT NULL,
        is_active INT NOT NULL DEFAULT 1,
        created_at VARCHAR(19) NOT NULL
    ){$engine}");
    seedDefaultQuestions($pdo);
    ensureFeatureSchema($pdo, $autoId, $engine);
}

function getSetting(string $key, string $default): string
{
    $statement = db()->prepare('SELECT setting_value FROM settings WHERE setting_key = ?');
    $statement->execute([$key]);
    $value = $statement->fetchColumn();
    return $value === false ? $default : (string) $value;
}

function setSetting(string $key, string $value): void
{
    db()->prepare('DELETE FROM settings WHERE setting_key = ?')->execute([$key]);
    db()->prepare('INSERT INTO settings (setting_key, setting_value) VALUES (?, ?)')->execute([$key, $value]);
}

function isTestOpen(string $testType): bool
{
    $default = $testType === 'pre' ? '1' : '0';
    return getSetting("{$testType}_open", $default) === '1';
}

function e(string $text): string
{
    return htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
}

function csrfToken(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(16));
    }
    return $_SESSION['csrf'];
}

function csrfField(): string
{
    return '<input type="hidden" name="csrf" value="' . e(csrfToken()) . '">';
}

function verifyCsrf(): void
{
    $sent = (string) ($_POST['csrf'] ?? '');
    if (!hash_equals(csrfToken(), $sent)) {
        http_response_code(400);
        exit('Sesi tidak valid. Muat ulang halaman lalu coba lagi.');
    }
}

function redirect(string $path): never
{
    header('Location: ' . $path);
    exit;
}

function requireAdmin(): void
{
    if (empty($_SESSION['is_admin'])) {
        redirect('login.php');
    }
}

function renderHeader(string $title, string $basePath = ''): void
{
    echo '<!doctype html><html lang="id"><head><meta charset="utf-8">'
        . '<meta name="viewport" content="width=device-width, initial-scale=1">'
        . '<title>' . e($title) . '</title>'
        . '<link rel="preconnect" href="https://fonts.googleapis.com">'
        . '<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@500;600;700;800&display=swap" rel="stylesheet">'
        . '<link rel="stylesheet" href="' . e(asset('assets/style.css', $basePath)) . '"></head><body>'
        . '<header class="site-head"><div class="wrap head-row">'
        . '<a class="brand" href="' . $basePath . 'index.php"><img src="' . $basePath . 'assets/logo-ut.png" alt="Universitas Terbuka">'
        . '<img src="' . $basePath . 'assets/logo-karang-taruna.png" alt="Karang Taruna"><i class="brand-sep" aria-hidden="true"></i>'
        . '<span>Tes Kesiapan Kerja<small>MK-PM Kelompok 1 · Universitas Terbuka</small></span></a>'
        . renderSiteNav($basePath) . '</div></header>'
        . '<main class="wrap">';
}

const SITE_NAV = ['index.php' => 'Beranda', 'area.php' => 'Area Peserta', 'materi.php' => 'Materi', 'hadir.php' => 'Daftar Hadir'];

function renderSiteNav(string $basePath): string
{
    $current = basename((string) ($_SERVER['SCRIPT_NAME'] ?? ''));
    $links = '';
    foreach (SITE_NAV as $file => $label) {
        $active = $file === $current ? ' class="is-active" aria-current="page"' : '';
        $links .= '<a href="' . $basePath . $file . '"' . $active . '>' . e($label) . '</a>';
    }
    return '<nav class="site-nav">' . $links . '</nav>';
}

const SUPPORT_URL = 'https://aytindeso.com/';

function renderFooter(string $basePath = ''): void
{
    echo '</main><footer class="site-foot wrap"><p>Program Pelatihan Kesiapan Kerja bagi Pemuda Karang Taruna · '
        . 'Kec. Jatisampurna, Kota Bekasi · September – Desember 2026</p>'
        . '<a class="support-by" href="' . SUPPORT_URL . '" target="_blank" rel="noopener">'
        . '<span>Support by</span><img src="' . $basePath . 'assets/logo-aytindeso.png" alt="AYTINDESO — Publikasi Teknologi" width="170" height="47"></a>'
        . '</footer></body></html>';
}

/** Password changed from the admin panel (stored in DB) takes precedence over config.php. */
function adminPasswordHash(): string
{
    return getSetting('admin_password_hash', (string) appConfig()['admin_password_hash']);
}

function toggleTest(string $testType): void
{
    setSetting("{$testType}_open", isTestOpen($testType) ? '0' : '1');
    $_SESSION['flash'] = TEST_TYPES[$testType] . (isTestOpen($testType) ? ' dibuka.' : ' ditutup.');
}

function countAttempts(string $phone, string $testType): int
{
    $statement = db()->prepare('SELECT COUNT(*) FROM submissions WHERE phone = ? AND test_type = ?');
    $statement->execute([$phone, $testType]);
    return (int) $statement->fetchColumn();
}

function attemptsExhaustedMessage(string $testType): string
{
    $limit = maxAttempts($testType);
    $label = TEST_TYPES[$testType];
    return $limit === 1
        ? "Nomor WhatsApp ini sudah mengerjakan {$label}. Hubungi panitia bila ada kendala."
        : "Kesempatan {$label} untuk nomor WhatsApp ini sudah habis ({$limit}×). Hubungi panitia bila ada kendala.";
}

const DEFAULT_TEST_DURATION_MINUTES = 15;
const MAX_TEST_DURATION_MINUTES = 180;
const TIMER_GRACE_SECONDS = 20;

function testDurationMinutes(): int
{
    return (int) getSetting('test_duration', (string) DEFAULT_TEST_DURATION_MINUTES);
}

function privacyNote(): string
{
    return '<p class="privacy-note">🔒 Data diri dan nomor WhatsApp hanya digunakan panitia untuk keperluan pelatihan '
        . '(penilaian, sertifikat, dan laporan kegiatan) dan tidak dibagikan ke pihak lain.</p>';
}

/** Appends the file's modification time so browsers fetch a fresh copy after every deploy. */
function asset(string $path, string $basePath = ''): string
{
    $file = __DIR__ . '/../' . $path;
    $version = is_file($file) ? (string) filemtime($file) : '1';
    return $basePath . $path . '?v=' . $version;
}
