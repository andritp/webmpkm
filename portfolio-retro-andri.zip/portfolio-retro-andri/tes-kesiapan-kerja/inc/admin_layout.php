<?php
declare(strict_types=1);

const ADMIN_MENU = [
    'Tes' => [
        'dashboard' => ['href' => 'index.php', 'label' => 'Dashboard', 'icon' => '<path d="M3 13h8V3H3zM13 21h8V11h-8zM3 21h8v-6H3zM13 3v6h8V3z"/>'],
        'peserta' => ['href' => 'peserta.php', 'label' => 'Data Peserta', 'icon' => '<path d="M16 11a4 4 0 1 0-4-4 4 4 0 0 0 4 4zM8 13a3 3 0 1 0-3-3 3 3 0 0 0 3 3zm8 2c-2.7 0-8 1.3-8 4v2h16v-2c0-2.7-5.3-4-8-4zM8 15c-.3 0-.7 0-1.1.1A4.5 4.5 0 0 1 9 19v2H2v-2c0-2.2 4.5-4 6-4z"/>'],
        'bank-soal' => ['href' => 'bank-soal.php', 'label' => 'Bank Soal', 'icon' => '<path d="M6 2h9l5 5v15H6zM14 3v5h5M9 12h8v2H9zm0 4h8v2H9z"/>'],
        'soal' => ['href' => 'soal.php', 'label' => 'Analisis Soal', 'icon' => '<path d="M4 4h16v2H4zm0 5h10v2H4zm0 5h16v2H4zm0 5h10v2H4z"/>'],
    ],
    'Kegiatan' => [
        'hadir' => ['href' => 'hadir.php', 'label' => 'Daftar Hadir', 'icon' => '<path d="M7 2v2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2h-2V2h-2v2H9V2zm-2 8h14v10H5zm5.6 8.4L7.2 15l1.4-1.4 2 2 4.8-4.8 1.4 1.4z"/>'],
        'materi' => ['href' => 'materi.php', 'label' => 'Materi', 'icon' => '<path d="M5 20h14v-2H5zm14-11h-4V3H9v6H5l7 7z"/>'],
        'penilaian' => ['href' => 'penilaian.php', 'label' => 'Penilaian Produk', 'icon' => '<path d="M12 17.3l6.2 3.7-1.6-7 5.4-4.7-7.1-.6L12 2 9.1 8.7 2 9.3l5.4 4.7-1.6 7z"/>'],
        'kuesioner' => ['href' => 'kuesioner.php', 'label' => 'Kuesioner', 'icon' => '<path d="M4 4h16v12H5.2L4 17.2zm4 5v2h2V9zm4 0v2h2V9zm4 0v2h2V9z"/>'],
    ],
    'Lainnya' => [
        'qr' => ['href' => 'qr.php', 'label' => 'QR Code', 'icon' => '<path d="M3 3h8v8H3zm2 2v4h4V5zm8-2h8v8h-8zm2 2v4h4V5zM3 13h8v8H3zm2 2v4h4v-4zm8-2h2v2h-2zm2 2h2v2h-2zm2-2h4v2h-4zm-4 4h2v4h-2zm4 0h4v2h-2v2h-2z"/>'],
        'pengaturan' => ['href' => 'pengaturan.php', 'label' => 'Pengaturan', 'icon' => '<path d="M19.4 13a7.5 7.5 0 0 0 0-2l2.1-1.6-2-3.5-2.5 1a7.7 7.7 0 0 0-1.7-1L15 3h-4l-.4 2.6a7.7 7.7 0 0 0-1.7 1l-2.5-1-2 3.5L6.5 11a7.5 7.5 0 0 0 0 2l-2.1 1.6 2 3.5 2.5-1a7.7 7.7 0 0 0 1.7 1L11 21h4l.4-2.6a7.7 7.7 0 0 0 1.7-1l2.5 1 2-3.5zM13 15.5A3.5 3.5 0 1 1 16.5 12 3.5 3.5 0 0 1 13 15.5z"/>'],
    ],
];

function renderAdminHeader(string $active, string $title): void
{
    $flash = $_SESSION['flash'] ?? '';
    unset($_SESSION['flash']);
    ?>
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= e($title) ?> — Panel Admin</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="<?= e(asset('assets/style.css', '../')) ?>">
  <link rel="stylesheet" href="<?= e(asset('assets/admin.css', '../')) ?>">
</head>
<body class="admin-body">
<input type="checkbox" id="nav-toggle" class="nav-toggle" aria-label="Buka menu">
<aside class="sidebar">
  <div class="side-brand">
    <img src="../assets/logo-ut.png" alt="Universitas Terbuka">
    <div><b>Panel Admin</b><small>Tes Kesiapan Kerja</small></div>
  </div>
  <nav class="side-nav">
    <?php foreach (ADMIN_MENU as $group => $items): ?>
      <span class="side-group"><?= e($group) ?></span>
      <?php foreach ($items as $key => $item): ?>
        <a href="<?= $item['href'] ?>" class="<?= $key === $active ? 'active' : '' ?>">
          <svg viewBox="0 0 24 24" aria-hidden="true"><?= $item['icon'] ?></svg><?= e($item['label']) ?>
        </a>
      <?php endforeach; ?>
    <?php endforeach; ?>
  </nav>
  <div class="side-foot">
    <a href="../index.php" target="_blank" rel="noopener">Lihat halaman peserta ↗</a>
    <a href="logout.php" class="logout">Keluar</a>
  </div>
</aside>
<label for="nav-toggle" class="nav-backdrop" aria-hidden="true"></label>
<div class="admin-main">
  <header class="topbar">
    <label for="nav-toggle" class="burger" aria-label="Menu"><span></span><span></span><span></span></label>
    <h1><?= e($title) ?></h1>
    <div class="topbar-status">
      <?php foreach (TEST_TYPES as $type => $label): $open = isTestOpen($type); ?>
        <span class="status <?= $open ? 'on' : 'off' ?>"><?= e($label) ?> <?= $open ? 'dibuka' : 'ditutup' ?></span>
      <?php endforeach; ?>
    </div>
  </header>
  <div class="admin-content">
    <?php if ($flash): ?><div class="notice"><?= e($flash) ?></div><?php endif; ?>
<?php
}

function renderAdminFooter(): void
{
    echo '</div></div></body></html>';
}
