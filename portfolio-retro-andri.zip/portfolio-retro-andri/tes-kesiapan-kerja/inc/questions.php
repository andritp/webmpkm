<?php
declare(strict_types=1);

const TOPICS = [
    'dunia_kerja' => 'Pengenalan Dunia Kerja',
    'etika' => 'Budaya dan Etika Kerja',
    'cv' => 'Curriculum Vitae',
    'surat' => 'Surat Lamaran Kerja',
    'linkedin' => 'LinkedIn',
];

/**
 * Initial question bank, copied into the database on first run. Edit questions from the admin panel afterwards.
 * @return array<int, array{id:int, topic:string, text:string, options:array<string,string>, answer:string}>
 */
function getDefaultQuestions(): array
{
    return [
        // --- Pengenalan Dunia Kerja ---
        ['id' => 1, 'topic' => 'dunia_kerja', 'answer' => 'b',
            'text' => 'Langkah pertama yang paling tepat sebelum mulai melamar kerja adalah…',
            'options' => [
                'a' => 'Mengirim lamaran ke semua lowongan tanpa membaca persyaratan',
                'b' => 'Mengenali minat, keterampilan, dan posisi yang sesuai dengan diri sendiri',
                'c' => 'Menunggu tawaran pekerjaan dari teman',
                'd' => 'Membuat akun media sosial baru',
            ]],
        ['id' => 2, 'topic' => 'dunia_kerja', 'answer' => 'b',
            'text' => 'Urutan umum proses rekrutmen di perusahaan adalah…',
            'options' => [
                'a' => 'Wawancara → seleksi berkas → tes → kontrak',
                'b' => 'Seleksi berkas → tes/psikotes → wawancara → penawaran kerja',
                'c' => 'Kontrak kerja → wawancara → seleksi berkas',
                'd' => 'Tes kesehatan → kontrak kerja → seleksi berkas',
            ]],
        ['id' => 3, 'topic' => 'dunia_kerja', 'answer' => 'b',
            'text' => 'Ciri lowongan kerja palsu (penipuan) yang perlu diwaspadai adalah…',
            'options' => [
                'a' => 'Mencantumkan alamat dan situs resmi perusahaan',
                'b' => 'Meminta pelamar membayar sejumlah uang agar bisa diterima',
                'c' => 'Proses seleksi dilakukan melalui email resmi perusahaan',
                'd' => 'Menjelaskan kualifikasi dan tanggung jawab dengan jelas',
            ]],
        ['id' => 4, 'topic' => 'dunia_kerja', 'answer' => 'b',
            'text' => 'Yang dimaksud dengan hard skill adalah…',
            'options' => [
                'a' => 'Kemampuan berkomunikasi dan bekerja sama dalam tim',
                'b' => 'Kemampuan teknis yang dapat diukur, misalnya mengoperasikan komputer atau mengemudi',
                'c' => 'Sikap ramah dan sopan kepada rekan kerja',
                'd' => 'Kemampuan mengendalikan emosi saat bekerja',
            ]],

        // --- Budaya dan Etika Kerja ---
        ['id' => 5, 'topic' => 'etika', 'answer' => 'b',
            'text' => 'Jika terpaksa datang terlambat karena halangan mendadak, sikap yang paling profesional adalah…',
            'options' => [
                'a' => 'Diam saja dan langsung bekerja seperti biasa',
                'b' => 'Segera mengabari atasan, menjelaskan alasannya, dan berusaha tidak mengulanginya',
                'c' => 'Pulang lebih awal sebagai gantinya',
                'd' => 'Meminta teman untuk mengisikan absen',
            ]],
        ['id' => 6, 'topic' => 'etika', 'answer' => 'a',
            'text' => 'Contoh sikap bertanggung jawab di tempat kerja adalah…',
            'options' => [
                'a' => 'Menyelesaikan tugas sesuai tenggat dan mengakui kesalahan bila terjadi',
                'b' => 'Melimpahkan pekerjaan sendiri kepada rekan kerja',
                'c' => 'Menyalahkan orang lain ketika target tidak tercapai',
                'd' => 'Bekerja dengan serius hanya ketika diawasi atasan',
            ]],
        ['id' => 7, 'topic' => 'etika', 'answer' => 'a',
            'text' => 'Saat berbeda pendapat dengan rekan kerja dalam rapat, sikap yang tepat adalah…',
            'options' => [
                'a' => 'Menyampaikan pendapat dengan sopan disertai alasan yang jelas',
                'b' => 'Diam di rapat, lalu membicarakannya di belakang',
                'c' => 'Memotong pembicaraan rekan agar pendapat sendiri didengar',
                'd' => 'Meninggalkan rapat sebagai bentuk protes',
            ]],
        ['id' => 8, 'topic' => 'etika', 'answer' => 'b',
            'text' => 'Menjaga kerahasiaan data perusahaan berarti…',
            'options' => [
                'a' => 'Boleh membagikan data perusahaan kepada teman dekat',
                'b' => 'Tidak menyebarkan informasi internal perusahaan kepada pihak yang tidak berwenang',
                'c' => 'Mengunggah dokumen pekerjaan ke media sosial pribadi',
                'd' => 'Menyalin data ke flashdisk pribadi lalu membagikannya',
            ]],

        // --- Curriculum Vitae ---
        ['id' => 9, 'topic' => 'cv', 'answer' => 'a',
            'text' => 'Bagian yang wajib ada dalam sebuah CV adalah…',
            'options' => [
                'a' => 'Data diri, pendidikan, pengalaman, dan keterampilan',
                'b' => 'Hobi, makanan favorit, dan zodiak',
                'c' => 'Nama orang tua dan jumlah saudara kandung',
                'd' => 'Riwayat kesehatan lengkap sejak kecil',
            ]],
        ['id' => 10, 'topic' => 'cv', 'answer' => 'b',
            'text' => 'Panjang CV yang ideal untuk lulusan baru (fresh graduate) adalah…',
            'options' => [
                'a' => '5–6 halaman agar terlihat lengkap',
                'b' => '1 halaman, maksimal 2 halaman',
                'c' => 'Setengah halaman tanpa rincian apa pun',
                'd' => 'Tidak ada batasan, semakin panjang semakin baik',
            ]],
        ['id' => 11, 'topic' => 'cv', 'answer' => 'b',
            'text' => 'Alamat email yang paling tepat dicantumkan di CV adalah…',
            'options' => [
                'a' => 'cowokkeren99@gmail.com',
                'b' => 'andi.pratama@gmail.com',
                'c' => 'sibebeb_lucu@yahoo.com',
                'd' => 'Tidak perlu mencantumkan email',
            ]],
        ['id' => 12, 'topic' => 'cv', 'answer' => 'b',
            'text' => 'Cara menuliskan pengalaman kerja atau organisasi di CV yang baik adalah…',
            'options' => [
                'a' => 'Diurutkan dari pengalaman yang paling lama',
                'b' => 'Diurutkan dari yang terbaru, disertai peran dan pencapaian',
                'c' => 'Ditulis semuanya tanpa urutan tertentu',
                'd' => 'Cukup menuliskan nama tempatnya saja',
            ]],

        // --- Surat Lamaran Kerja ---
        ['id' => 13, 'topic' => 'surat', 'answer' => 'b',
            'text' => 'Fungsi utama surat lamaran kerja adalah…',
            'options' => [
                'a' => 'Menggantikan CV sepenuhnya',
                'b' => 'Memperkenalkan diri serta menunjukkan kesesuaian pelamar dengan posisi yang dilamar',
                'c' => 'Meminta gaji setinggi mungkin',
                'd' => 'Menceritakan riwayat hidup secara lengkap',
            ]],
        ['id' => 14, 'topic' => 'surat', 'answer' => 'b',
            'text' => 'Bagian surat lamaran yang menyebutkan posisi yang dilamar dan sumber informasi lowongan adalah…',
            'options' => [
                'a' => 'Paragraf penutup',
                'b' => 'Paragraf pembuka',
                'c' => 'Daftar lampiran',
                'd' => 'Bagian tanda tangan',
            ]],
        ['id' => 15, 'topic' => 'surat', 'answer' => 'b',
            'text' => 'Kesalahan yang sering membuat surat lamaran langsung ditolak adalah…',
            'options' => [
                'a' => 'Menggunakan bahasa yang formal dan sopan',
                'b' => 'Salah menulis nama perusahaan atau posisi karena menyalin surat orang lain',
                'c' => 'Mencantumkan nomor telepon yang aktif',
                'd' => 'Menyebutkan dokumen yang dilampirkan',
            ]],
        ['id' => 16, 'topic' => 'surat', 'answer' => 'b',
            'text' => 'Saat mengirim lamaran melalui email, yang sebaiknya dilakukan adalah…',
            'options' => [
                'a' => 'Mengirim lampiran tanpa subjek dan tanpa isi email',
                'b' => 'Menulis subjek yang jelas (posisi – nama), isi email singkat, dan melampirkan file PDF',
                'c' => 'Melampirkan foto dokumen yang buram',
                'd' => 'Mengirim email yang sama berkali-kali agar cepat dibaca',
            ]],

        // --- LinkedIn ---
        ['id' => 17, 'topic' => 'linkedin', 'answer' => 'b',
            'text' => 'LinkedIn adalah…',
            'options' => [
                'a' => 'Aplikasi untuk berbagi video hiburan',
                'b' => 'Media sosial profesional untuk membangun profil kerja, mencari lowongan, dan memperluas jaringan',
                'c' => 'Aplikasi belanja online',
                'd' => 'Aplikasi pesan instan seperti WhatsApp',
            ]],
        ['id' => 18, 'topic' => 'linkedin', 'answer' => 'b',
            'text' => 'Foto profil LinkedIn yang tepat adalah…',
            'options' => [
                'a' => 'Foto bersama teman-teman saat liburan',
                'b' => 'Foto wajah yang jelas, berpakaian rapi, dengan latar sederhana',
                'c' => 'Gambar kartun atau logo favorit',
                'd' => 'Tidak perlu memasang foto profil',
            ]],
        ['id' => 19, 'topic' => 'linkedin', 'answer' => 'b',
            'text' => 'Bagian "Headline" pada profil LinkedIn sebaiknya berisi…',
            'options' => [
                'a' => 'Alamat rumah lengkap',
                'b' => 'Ringkasan singkat keahlian atau tujuan karier, misalnya "Lulusan SMK TKJ | Siap Kerja di Bidang IT Support"',
                'c' => 'Nomor rekening bank',
                'd' => 'Status hubungan pribadi',
            ]],
        ['id' => 20, 'topic' => 'linkedin', 'answer' => 'a',
            'text' => 'Fitur LinkedIn yang digunakan untuk mencari lowongan sekaligus melamar langsung adalah…',
            'options' => [
                'a' => 'Jobs (Pekerjaan) dengan fitur Easy Apply',
                'b' => 'Stories',
                'c' => 'Marketplace',
                'd' => 'Reels',
            ]],
    ];
}
