<?php
declare(strict_types=1);

const OPTION_KEYS = ['a', 'b', 'c', 'd'];
const MAX_QUESTION_LENGTH = 500;
const MAX_OPTION_LENGTH = 300;

/**
 * @param array<string, mixed> $input raw form input
 * @param array<string, string> $topics allowed topic keys => labels
 * @return array{errors: list<string>, data: array{topic:string, text:string, options:array<string,string>, answer:string}}
 */
function validateQuestionInput(array $input, array $topics): array
{
    $errors = [];
    $topic = (string) ($input['topic'] ?? '');
    $text = trim((string) ($input['text'] ?? ''));
    $answer = (string) ($input['answer'] ?? '');

    if (!array_key_exists($topic, $topics)) {
        $errors[] = 'Pilih materi yang valid.';
    }
    if ($text === '') {
        $errors[] = 'Pertanyaan wajib diisi.';
    } elseif (mb_strlen($text) > MAX_QUESTION_LENGTH) {
        $errors[] = 'Pertanyaan maksimal ' . MAX_QUESTION_LENGTH . ' karakter.';
    }

    $options = [];
    foreach (OPTION_KEYS as $key) {
        $value = trim((string) ($input["option_{$key}"] ?? ''));
        $options[$key] = $value;
        $letter = strtoupper($key);
        if ($value === '') {
            $errors[] = "Pilihan {$letter} wajib diisi.";
        } elseif (mb_strlen($value) > MAX_OPTION_LENGTH) {
            $errors[] = "Pilihan {$letter} maksimal " . MAX_OPTION_LENGTH . ' karakter.';
        }
    }

    $filled = array_filter($options, static fn (string $value): bool => $value !== '');
    $normalized = array_map(static fn (string $value): string => mb_strtolower($value), $filled);
    if (count(array_unique($normalized)) < count($normalized)) {
        $errors[] = 'Setiap pilihan jawaban harus berbeda.';
    }
    if (!in_array($answer, OPTION_KEYS, true)) {
        $errors[] = 'Pilih kunci jawaban (A–D).';
    }

    return [
        'errors' => $errors,
        'data' => ['topic' => $topic, 'text' => $text, 'options' => $options, 'answer' => $answer],
    ];
}
