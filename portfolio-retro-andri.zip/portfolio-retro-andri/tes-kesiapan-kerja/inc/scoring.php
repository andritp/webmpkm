<?php
declare(strict_types=1);

const GAIN_HIGH_THRESHOLD = 0.7;
const GAIN_LOW_THRESHOLD = 0.3;
const MAX_SCORE = 100;
const PHONE_COUNTRY_CODE = '62';

/**
 * @param array<int, array{id:int, topic:string, answer:string}> $questions
 * @param array<int, string> $answers question id => chosen option key
 * @return array{correct:int, total:int, score:int, by_topic:array<string,int>}
 */
function scoreAnswers(array $questions, array $answers): array
{
    $correct = 0;
    $topicTotals = [];
    $topicCorrect = [];

    foreach ($questions as $question) {
        $topic = $question['topic'];
        $topicTotals[$topic] = ($topicTotals[$topic] ?? 0) + 1;
        $topicCorrect[$topic] = $topicCorrect[$topic] ?? 0;

        $chosen = $answers[$question['id']] ?? null;
        if ($chosen !== $question['answer']) {
            continue;
        }
        $correct++;
        $topicCorrect[$topic]++;
    }

    $byTopic = [];
    foreach ($topicTotals as $topic => $total) {
        $byTopic[$topic] = toPercent($topicCorrect[$topic], $total);
    }

    $total = count($questions);
    return [
        'correct' => $correct,
        'total' => $total,
        'score' => toPercent($correct, $total),
        'by_topic' => $byTopic,
    ];
}

function toPercent(int $part, int $total): int
{
    if ($total === 0) {
        return 0;
    }
    return (int) round($part / $total * MAX_SCORE);
}

/** Hake normalized gain; null when the pre-test score leaves no room to improve. */
function calculateNormalizedGain(int $preScore, int $postScore): ?float
{
    if ($preScore >= MAX_SCORE) {
        return null;
    }
    return round(($postScore - $preScore) / (MAX_SCORE - $preScore), 2);
}

function categorizeGain(?float $gain): string
{
    if ($gain === null) {
        return '-';
    }
    if ($gain > GAIN_HIGH_THRESHOLD) {
        return 'Tinggi';
    }
    if ($gain >= GAIN_LOW_THRESHOLD) {
        return 'Sedang';
    }
    return 'Rendah';
}

/** Normalizes Indonesian phone numbers so pre-test and post-test rows can be paired. */
function normalizePhone(string $phone): string
{
    $digits = preg_replace('/\D+/', '', $phone) ?? '';
    if ($digits === '') {
        return '';
    }
    if (str_starts_with($digits, PHONE_COUNTRY_CODE)) {
        return $digits;
    }
    if (str_starts_with($digits, '0')) {
        return PHONE_COUNTRY_CODE . substr($digits, 1);
    }
    return PHONE_COUNTRY_CODE . $digits;
}

/**
 * Item analysis: percentage of participants answering each question correctly, split by test type.
 * @param array<int, array{id:int, topic:string, answer:string}> $questions
 * @param list<array{test_type:string, answers:array<int,string>}> $submissions
 * @return array<int, array{pre:?int, post:?int}>
 */
function calculateItemAnalysis(array $questions, array $submissions): array
{
    $counts = ['pre' => 0, 'post' => 0];
    $correct = [];
    foreach ($questions as $question) {
        $correct[$question['id']] = ['pre' => 0, 'post' => 0];
    }

    foreach ($submissions as $submission) {
        $type = $submission['test_type'];
        $counts[$type]++;
        foreach ($questions as $question) {
            if (($submission['answers'][$question['id']] ?? null) === $question['answer']) {
                $correct[$question['id']][$type]++;
            }
        }
    }

    $items = [];
    foreach ($correct as $questionId => $byType) {
        $items[$questionId] = [
            'pre' => $counts['pre'] ? toPercent($byType['pre'], $counts['pre']) : null,
            'post' => $counts['post'] ? toPercent($byType['post'], $counts['post']) : null,
        ];
    }
    return $items;
}

const MAX_ATTEMPTS = ['pre' => 1, 'post' => 3];

function maxAttempts(string $testType): int
{
    return MAX_ATTEMPTS[$testType] ?? 1;
}

function remainingAttempts(string $testType, int $attemptsUsed): int
{
    return max(0, maxAttempts($testType) - $attemptsUsed);
}

/**
 * Keeps one row per phone + test type: the highest score, ties resolved to the latest attempt.
 * Adds attempt_count and attempt_scores (in attempt order) to each kept row.
 * @param list<array<string, mixed>> $rows each with phone, test_type, attempt, score
 * @return list<array<string, mixed>>
 */
function pickBestAttempts(array $rows): array
{
    usort($rows, static fn (array $left, array $right): int => (int) $left['attempt'] <=> (int) $right['attempt']);

    $best = [];
    $scores = [];
    foreach ($rows as $row) {
        $key = $row['phone'] . '|' . $row['test_type'];
        $scores[$key][] = (int) $row['score'];
        if (!isset($best[$key]) || (int) $row['score'] >= (int) $best[$key]['score']) {
            $best[$key] = $row;
        }
    }
    foreach ($best as $key => $row) {
        $best[$key]['attempt_count'] = count($scores[$key]);
        $best[$key]['attempt_scores'] = $scores[$key];
    }
    return array_values($best);
}
