<?php
declare(strict_types=1);

const LEGACY_SURVEY_COLUMNS = ['materi', 'pemateri', 'waktu', 'manfaat', 'fasilitas'];

function ensureSurveySchema(PDO $pdo, string $autoId, string $engine): void
{
    $pdo->exec("CREATE TABLE IF NOT EXISTS survey_aspects (
        id {$autoId}, label VARCHAR(200) NOT NULL, comment_prompt VARCHAR(200) NOT NULL,
        sort_order INT NOT NULL, is_active INT NOT NULL DEFAULT 1, created_at VARCHAR(19) NOT NULL
    ){$engine}");
    $pdo->exec("CREATE TABLE IF NOT EXISTS survey_answers (
        id {$autoId}, survey_id INT NOT NULL, aspect_id INT NOT NULL, rating INT NOT NULL, comment TEXT NOT NULL,
        UNIQUE (survey_id, aspect_id)
    ){$engine}");
    seedSurveyAspects($pdo);
    if (hasLegacySurveyColumns($pdo)) {
        migrateLegacySurveys($pdo, $autoId, $engine);
        return;
    }
    $pdo->exec(surveysTableSql('surveys', $autoId, $engine));
}

function surveysTableSql(string $table, string $autoId, string $engine): string
{
    return "CREATE TABLE IF NOT EXISTS {$table} (
        id {$autoId}, phone VARCHAR(20) NOT NULL UNIQUE, name VARCHAR(100) NOT NULL,
        saran TEXT NOT NULL, created_at VARCHAR(19) NOT NULL
    ){$engine}";
}

function seedSurveyAspects(PDO $pdo): void
{
    if ((int) $pdo->query('SELECT COUNT(*) FROM survey_aspects')->fetchColumn() > 0) {
        return;
    }
    $insert = $pdo->prepare('INSERT INTO survey_aspects (id, label, comment_prompt, sort_order, is_active, created_at) VALUES (?, ?, ?, ?, 1, ?)');
    foreach (DEFAULT_SURVEY_ASPECTS as $index => [$label, $prompt]) {
        $insert->execute([$index + 1, $label, $prompt, $index + 1, date('Y-m-d H:i:s')]);
    }
}

function hasLegacySurveyColumns(PDO $pdo): bool
{
    try {
        $pdo->query('SELECT materi FROM surveys LIMIT 1');
        return true;
    } catch (PDOException $exception) {
        return false;
    }
}

/** Old surveys stored five fixed rating columns; those map to the first five seeded aspects. */
function migrateLegacySurveys(PDO $pdo, string $autoId, string $engine): void
{
    $pdo->exec('ALTER TABLE surveys RENAME TO surveys_legacy');
    $pdo->exec(surveysTableSql('surveys', $autoId, $engine));
    $insertSurvey = $pdo->prepare('INSERT INTO surveys (id, phone, name, saran, created_at) VALUES (?, ?, ?, ?, ?)');
    $insertAnswer = $pdo->prepare('INSERT INTO survey_answers (survey_id, aspect_id, rating, comment) VALUES (?, ?, ?, ?)');
    foreach ($pdo->query('SELECT * FROM surveys_legacy')->fetchAll() as $row) {
        $insertSurvey->execute([$row['id'], $row['phone'], $row['name'], $row['saran'], $row['created_at']]);
        foreach (LEGACY_SURVEY_COLUMNS as $index => $column) {
            $insertAnswer->execute([$row['id'], $index + 1, (int) $row[$column], '']);
        }
    }
    $pdo->exec('DROP TABLE surveys_legacy');
}

/** @return list<array{id:int, label:string, comment_prompt:string, sort_order:int, is_active:bool}> */
function getSurveyAspects(bool $activeOnly = true): array
{
    $sql = 'SELECT * FROM survey_aspects' . ($activeOnly ? ' WHERE is_active = 1' : '') . ' ORDER BY sort_order, id';
    return array_map(static fn (array $row): array => [
        'id' => (int) $row['id'],
        'label' => $row['label'],
        'comment_prompt' => $row['comment_prompt'],
        'sort_order' => (int) $row['sort_order'],
        'is_active' => (int) $row['is_active'] === 1,
    ], db()->query($sql)->fetchAll());
}

/** @param array{answers: array<int, array{rating:int, comment:string}>, saran:string} $data */
function saveSurveyResponse(string $phone, string $name, array $data): void
{
    $pdo = db();
    $pdo->beginTransaction();
    try {
        $pdo->prepare('INSERT INTO surveys (phone, name, saran, created_at) VALUES (?, ?, ?, ?)')
            ->execute([$phone, $name, $data['saran'], date('Y-m-d H:i:s')]);
        $surveyId = (int) $pdo->lastInsertId();
        $insertAnswer = $pdo->prepare('INSERT INTO survey_answers (survey_id, aspect_id, rating, comment) VALUES (?, ?, ?, ?)');
        foreach ($data['answers'] as $aspectId => $answer) {
            $insertAnswer->execute([$surveyId, $aspectId, $answer['rating'], $answer['comment']]);
        }
        $pdo->commit();
    } catch (PDOException $exception) {
        $pdo->rollBack();
        throw new RuntimeException('Failed to save survey response', 0, $exception);
    }
}

/**
 * One row per respondent: [aspectId => rating], ready for summarizeSurvey().
 * @return list<array<int, int>>
 */
function surveyRatingRows(): array
{
    $rows = [];
    foreach (db()->query('SELECT survey_id, aspect_id, rating FROM survey_answers')->fetchAll() as $answer) {
        $rows[(int) $answer['survey_id']][(int) $answer['aspect_id']] = (int) $answer['rating'];
    }
    return array_values($rows);
}

/** @return array<int, list<array{name:string, rating:int, comment:string}>> aspectId => comments */
function surveyCommentsByAspect(): array
{
    $statement = db()->query("SELECT a.aspect_id, a.rating, a.comment, s.name FROM survey_answers a
        JOIN surveys s ON s.id = a.survey_id WHERE a.comment <> '' ORDER BY s.id DESC");
    $comments = [];
    foreach ($statement->fetchAll() as $row) {
        $comments[(int) $row['aspect_id']][] = ['name' => $row['name'], 'rating' => (int) $row['rating'], 'comment' => $row['comment']];
    }
    return $comments;
}

/** @param array{label:string, comment_prompt:string} $data */
function saveSurveyAspect(?int $id, array $data): void
{
    if ($id === null) {
        $nextOrder = (int) db()->query('SELECT COALESCE(MAX(sort_order), 0) + 1 FROM survey_aspects')->fetchColumn();
        db()->prepare('INSERT INTO survey_aspects (label, comment_prompt, sort_order, is_active, created_at) VALUES (?, ?, ?, 1, ?)')
            ->execute([$data['label'], $data['comment_prompt'], $nextOrder, date('Y-m-d H:i:s')]);
        return;
    }
    db()->prepare('UPDATE survey_aspects SET label = ?, comment_prompt = ? WHERE id = ?')->execute([$data['label'], $data['comment_prompt'], $id]);
}

/** Swaps sort order with the neighbouring aspect; $direction is -1 (up) or 1 (down). */
function moveSurveyAspect(int $id, int $direction): void
{
    $aspects = getSurveyAspects(false);
    $index = array_search($id, array_column($aspects, 'id'), true);
    $neighbourIndex = $index === false ? false : $index + $direction;
    if ($index === false || !isset($aspects[$neighbourIndex])) {
        return;
    }
    $update = db()->prepare('UPDATE survey_aspects SET sort_order = ? WHERE id = ?');
    $update->execute([$aspects[$neighbourIndex]['sort_order'], $id]);
    $update->execute([$aspects[$index]['sort_order'], $aspects[$neighbourIndex]['id']]);
}
