<?php
declare(strict_types=1);

const CERTIFICATE_SUFFIX = 'MKPM-UT/KT-JTS';
const SURVEY_SCALE = [1, 2, 3, 4, 5];
const DEFAULT_SURVEY_ASPECTS = [
    ['Materi pelatihan mudah dipahami dan bermanfaat', 'Materi apa yang perlu diperjelas atau ditambah?'],
    ['Pemateri menyampaikan dengan jelas', 'Apa yang bisa diperbaiki dari cara penyampaian pemateri?'],
    ['Waktu pelaksanaan sudah tepat', 'Waktu atau durasi seperti apa yang kamu inginkan?'],
    ['Pelatihan membantu kesiapan saya masuk dunia kerja', 'Bagian mana yang paling atau paling tidak membantu?'],
    ['Tempat dan fasilitas pelatihan memadai', 'Fasilitas apa yang perlu diperbaiki?'],
    ['Pemateri bersikap ramah, sabar, dan menghargai peserta', 'Ceritakan sikap pemateri selama pelatihan, termasuk bila ada yang kurang berkenan'],
    ['Pemateri memberi kesempatan bertanya dan menjawab dengan baik', 'Bagaimana pemateri menanggapi pertanyaanmu?'],
    ['Sesi praktik (CV, surat lamaran, LinkedIn) cukup dan membantu', 'Praktik apa yang perlu ditambah?'],
    ['Panitia sigap membantu bila ada kendala', 'Kendala apa yang kamu alami dan bagaimana panitia membantu?'],
    ['Saya merasa nyaman dan aman selama pelatihan', 'Apa yang membuatmu nyaman atau kurang nyaman?'],
];
const DEFAULT_COMMENT_PROMPT = 'Tuliskan saranmu untuk aspek ini';
const MIN_COMMENT_LENGTH = 5;
const MAX_COMMENT_LENGTH = 500;
const MAX_GENERAL_FEEDBACK_LENGTH = 1000;
const BYTES_PER_KB = 1024;

function formatCertificateNumber(int $sequence, int $year): string
{
    return sprintf('%03d/%s/%d', $sequence, CERTIFICATE_SUFFIX, $year);
}

function isValidLinkedinUrl(string $url): bool
{
    $candidate = preg_match('#^https?://#i', trim($url)) ? trim($url) : 'https://' . trim($url);
    $parts = parse_url($candidate);
    if (!$parts || empty($parts['host']) || empty($parts['path'])) {
        return false;
    }
    $host = strtolower($parts['host']);
    $isLinkedinHost = $host === 'linkedin.com' || str_ends_with($host, '.linkedin.com');
    return $isLinkedinHost && preg_match('#^/in/[A-Za-z0-9\-_%]+/?$#', $parts['path']) === 1;
}

function normalizeLinkedinUrl(string $url): string
{
    $candidate = preg_match('#^https?://#i', trim($url)) ? trim($url) : 'https://' . trim($url);
    $parts = parse_url($candidate);
    $host = strtolower($parts['host'] ?? '');
    if ($host === 'linkedin.com') {
        $host = 'www.linkedin.com';
    }
    return 'https://' . $host . rtrim($parts['path'] ?? '', '/');
}

function fileExtension(string $filename): string
{
    return strtolower(pathinfo($filename, PATHINFO_EXTENSION));
}

/**
 * Validates an entry of $_FILES without touching the filesystem.
 * @param array{name:string, size:int, error:int, tmp_name:string} $file
 * @param list<string> $allowedExtensions
 */
function validateUploadMeta(array $file, array $allowedExtensions, int $maxBytes): ?string
{
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
        return 'Pilih file terlebih dahulu.';
    }
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return 'Upload gagal. Coba lagi.';
    }
    if (!in_array(fileExtension($file['name']), $allowedExtensions, true)) {
        return 'Format file harus: ' . strtoupper(implode(', ', $allowedExtensions)) . '.';
    }
    if ($file['size'] > $maxBytes) {
        return 'File terlalu besar (maksimal ' . formatFileSize($maxBytes) . ').';
    }
    return null;
}

function formatFileSize(int $bytes): string
{
    if ($bytes >= BYTES_PER_KB * BYTES_PER_KB) {
        return number_format($bytes / BYTES_PER_KB / BYTES_PER_KB, 1, ',', '.') . ' MB';
    }
    return number_format($bytes / BYTES_PER_KB, 1, ',', '.') . ' KB';
}

/**
 * @param list<array<string, int|string>> $rows
 * @param array<string, string> $aspects
 * @return array<string, array{average:?float, distribution:array<int,int>}>
 */
function summarizeSurvey(array $rows, array $aspects): array
{
    $summary = [];
    foreach (array_keys($aspects) as $aspect) {
        $distribution = array_fill_keys(SURVEY_SCALE, 0);
        $values = [];
        foreach ($rows as $row) {
            $value = (int) ($row[$aspect] ?? 0);
            if (!isset($distribution[$value])) {
                continue;
            }
            $distribution[$value]++;
            $values[] = $value;
        }
        $summary[$aspect] = [
            'average' => $values ? round(array_sum($values) / count($values), 2) : null,
            'distribution' => $distribution,
        ];
    }
    return $summary;
}

function satisfactionLabel(?float $average): string
{
    if ($average === null) {
        return '-';
    }
    if ($average >= 4.2) {
        return 'Sangat Baik';
    }
    if ($average >= 3.4) {
        return 'Baik';
    }
    return $average >= 2.6 ? 'Cukup' : 'Kurang';
}

/** Grace window absorbs the delay between the browser auto-submitting and the request reaching the server. */
function isTimeExpired(int $startedAt, int $now, int $durationMinutes, int $graceSeconds): bool
{
    if ($durationMinutes <= 0) {
        return false;
    }
    return $now - $startedAt >= $durationMinutes * 60 - $graceSeconds;
}

function canViewReview(int $postAttemptsUsed): bool
{
    return $postAttemptsUsed > 0 && remainingAttempts('post', $postAttemptsUsed) === 0;
}

function isEligibleForCertificate(bool $hasPostTest, bool $hasSurvey): bool
{
    return $hasPostTest && $hasSurvey;
}

/**
 * Every active aspect needs a rating (1–5) and a comment; general feedback is mandatory too.
 * Error keys point at the form field (rating.{id}, comment.{id}, saran) so the page can highlight it.
 * @param list<array{id:int, label:string, comment_prompt:string}> $aspects
 * @param array<string, mixed> $input
 * @return array{errors: array<string,string>, data: array{answers: array<int, array{rating:int, comment:string}>, saran:string}}
 */
function validateSurveyInput(array $aspects, array $input): array
{
    $errors = [];
    $answers = [];
    foreach ($aspects as $aspect) {
        $id = (int) $aspect['id'];
        $rating = filter_var($input['rating'][$id] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => 5]]);
        $comment = trim((string) ($input['comment'][$id] ?? ''));
        if ($rating === false || $rating === null) {
            $errors["rating.{$id}"] = "Beri nilai 1–5 untuk \"{$aspect['label']}\".";
        }
        if (mb_strlen($comment) < MIN_COMMENT_LENGTH) {
            $errors["comment.{$id}"] = "Saran untuk \"{$aspect['label']}\" wajib diisi (minimal " . MIN_COMMENT_LENGTH . ' karakter).';
        } elseif (mb_strlen($comment) > MAX_COMMENT_LENGTH) {
            $errors["comment.{$id}"] = "Saran untuk \"{$aspect['label']}\" maksimal " . MAX_COMMENT_LENGTH . ' karakter.';
        }
        $answers[$id] = ['rating' => (int) $rating, 'comment' => $comment];
    }
    $saran = trim((string) ($input['saran'] ?? ''));
    if (mb_strlen($saran) < MIN_COMMENT_LENGTH) {
        $errors['saran'] = 'Kritik dan saran umum wajib diisi (minimal ' . MIN_COMMENT_LENGTH . ' karakter).';
    } elseif (mb_strlen($saran) > MAX_GENERAL_FEEDBACK_LENGTH) {
        $errors['saran'] = 'Kritik dan saran umum maksimal ' . MAX_GENERAL_FEEDBACK_LENGTH . ' karakter.';
    }
    return ['errors' => $errors, 'data' => ['answers' => $answers, 'saran' => $saran]];
}

/**
 * @param array<string, mixed> $input
 * @return array{errors: list<string>, data: array{label:string, comment_prompt:string}}
 */
function validateAspectInput(array $input): array
{
    $label = trim((string) ($input['label'] ?? ''));
    $prompt = trim((string) ($input['comment_prompt'] ?? ''));
    $errors = [];
    if ($label === '') {
        $errors[] = 'Pertanyaan wajib diisi.';
    } elseif (mb_strlen($label) > 200) {
        $errors[] = 'Pertanyaan maksimal 200 karakter.';
    }
    if (mb_strlen($prompt) > 200) {
        $errors[] = 'Petunjuk saran maksimal 200 karakter.';
    }
    return ['errors' => $errors, 'data' => ['label' => $label, 'comment_prompt' => $prompt === '' ? DEFAULT_COMMENT_PROMPT : $prompt]];
}
/** @param list<int> $failureTimestamps unix times of recent failed attempts */
function isRateLimited(array $failureTimestamps, int $now, int $maxFailures, int $windowSeconds): bool
{
    $recent = array_filter($failureTimestamps, static fn (int $time): bool => $now - $time < $windowSeconds);
    return count($recent) >= $maxFailures;
}
