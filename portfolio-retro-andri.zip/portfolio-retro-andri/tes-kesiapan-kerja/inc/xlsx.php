<?php
declare(strict_types=1);

/*
 * Minimal XLSX writer (Office Open XML) so exports open as proper columns in any Excel locale,
 * unlike CSV whose separator depends on the computer's regional settings.
 */

const XLSX_STYLE_TITLE = 1;
const XLSX_STYLE_HEADER = 2;
const XLSX_STYLE_TEXT = 3;
const XLSX_STYLE_INT = 4;
const XLSX_STYLE_DECIMAL = 5;
const XLSX_TYPE_STYLES = ['text' => XLSX_STYLE_TEXT, 'int' => XLSX_STYLE_INT, 'decimal' => XLSX_STYLE_DECIMAL];
const XLSX_MAX_SHEET_NAME = 31;

function columnLetter(int $index): string
{
    $letters = '';
    while ($index > 0) {
        $remainder = ($index - 1) % 26;
        $letters = chr(65 + $remainder) . $letters;
        $index = intdiv($index - 1, 26);
    }
    return $letters;
}

function sanitizeSheetName(string $name): string
{
    $clean = trim(preg_replace('/\s+/', ' ', str_replace(['\\', '/', '?', '*', '[', ']', ':'], ' ', $name)) ?? '');
    return mb_substr($clean === '' ? 'Sheet' : $clean, 0, XLSX_MAX_SHEET_NAME);
}

function xmlEscape(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES | ENT_XML1, 'UTF-8');
}

/**
 * @param string|int|float|null $value
 * @param 'text'|'int'|'decimal'|'auto' $type
 */
function xlsxCell(string $reference, mixed $value, string $type, ?int $style = null): string
{
    if ($type === 'auto') {
        $type = is_int($value) ? 'int' : (is_float($value) ? 'decimal' : 'text');
    }
    $style ??= XLSX_TYPE_STYLES[$type];
    if ($value === null || $value === '') {
        return "<c r=\"{$reference}\" s=\"{$style}\"/>";
    }
    if ($type !== 'text' && is_numeric($value)) {
        return "<c r=\"{$reference}\" s=\"{$style}\"><v>{$value}</v></c>";
    }
    return "<c r=\"{$reference}\" s=\"{$style}\" t=\"inlineStr\"><is><t xml:space=\"preserve\">" . xmlEscape((string) $value) . '</t></is></c>';
}

/** @param array{title?:string, columns:list<array{0:string,1:int,2:string}>, rows:list<list<mixed>>} $sheet */
function buildSheetXml(array $sheet): string
{
    $columns = $sheet['columns'];
    $lastColumn = columnLetter(count($columns));
    $headerRow = isset($sheet['title']) ? 2 : 1;
    $rowsXml = '';

    if (isset($sheet['title'])) {
        $rowsXml .= '<row r="1" ht="24" customHeight="1">' . xlsxCell('A1', $sheet['title'], 'text', XLSX_STYLE_TITLE) . '</row>';
    }
    $rowsXml .= "<row r=\"{$headerRow}\" ht=\"30\" customHeight=\"1\">";
    foreach ($columns as $index => [$label]) {
        $rowsXml .= xlsxCell(columnLetter($index + 1) . $headerRow, $label, 'text', XLSX_STYLE_HEADER);
    }
    $rowsXml .= '</row>';

    foreach ($sheet['rows'] as $offset => $row) {
        $rowNumber = $headerRow + 1 + $offset;
        $rowsXml .= "<row r=\"{$rowNumber}\">";
        foreach ($columns as $index => [, , $type]) {
            $rowsXml .= xlsxCell(columnLetter($index + 1) . $rowNumber, $row[$index] ?? null, $type);
        }
        $rowsXml .= '</row>';
    }

    $colsXml = '';
    foreach ($columns as $index => [, $width]) {
        $position = $index + 1;
        $colsXml .= "<col min=\"{$position}\" max=\"{$position}\" width=\"{$width}\" customWidth=\"1\"/>";
    }
    $lastRow = $headerRow + max(count($sheet['rows']), 1);
    $firstDataCell = 'A' . ($headerRow + 1);
    $mergeXml = isset($sheet['title']) ? "<mergeCells count=\"1\"><mergeCell ref=\"A1:{$lastColumn}1\"/></mergeCells>" : '';

    return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
        . "<sheetViews><sheetView workbookViewId=\"0\"><pane ySplit=\"{$headerRow}\" topLeftCell=\"{$firstDataCell}\" activePane=\"bottomLeft\" state=\"frozen\"/></sheetView></sheetViews>"
        . "<cols>{$colsXml}</cols><sheetData>{$rowsXml}</sheetData>"
        . "<autoFilter ref=\"A{$headerRow}:{$lastColumn}{$lastRow}\"/>{$mergeXml}"
        . '</worksheet>';
}

function xlsxStylesXml(): string
{
    $border = '<border><left style="thin"><color rgb="FFD7DBEA"/></left><right style="thin"><color rgb="FFD7DBEA"/></right>'
        . '<top style="thin"><color rgb="FFD7DBEA"/></top><bottom style="thin"><color rgb="FFD7DBEA"/></bottom><diagonal/></border>';
    return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
        . '<fonts count="3"><font><sz val="11"/><name val="Calibri"/></font>'
        . '<font><b/><sz val="14"/><color rgb="FF141D5C"/><name val="Calibri"/></font>'
        . '<font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font></fonts>'
        . '<fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill>'
        . '<fill><patternFill patternType="solid"><fgColor rgb="FF22307F"/><bgColor indexed="64"/></patternFill></fill></fills>'
        . '<borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border>' . $border . '</borders>'
        . '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
        . '<cellXfs count="6">'
        . '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
        . '<xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/>'
        . '<xf numFmtId="0" fontId="2" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>'
        . '<xf numFmtId="49" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf>'
        . '<xf numFmtId="1" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="top"/></xf>'
        . '<xf numFmtId="2" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="top"/></xf>'
        . '</cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>';
}

/**
 * Writes a workbook to a temporary file and returns its path.
 * @param array<string, array{title?:string, columns:list<array{0:string,1:int,2:string}>, rows:list<list<mixed>>}> $sheets
 */
function buildXlsxFile(array $sheets): string
{
    $path = tempnam(sys_get_temp_dir(), 'xlsx');
    $zip = new ZipArchive();
    if ($path === false || $zip->open($path, ZipArchive::OVERWRITE) !== true) {
        throw new RuntimeException('Failed to create xlsx archive');
    }
    $sheetEntries = '';
    $relationships = '';
    $overrides = '';
    $index = 0;
    foreach ($sheets as $name => $sheet) {
        $index++;
        $zip->addFromString("xl/worksheets/sheet{$index}.xml", buildSheetXml($sheet));
        $sheetEntries .= '<sheet name="' . xmlEscape(sanitizeSheetName($name)) . "\" sheetId=\"{$index}\" r:id=\"rId{$index}\"/>";
        $relationships .= "<Relationship Id=\"rId{$index}\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet{$index}.xml\"/>";
        $overrides .= "<Override PartName=\"/xl/worksheets/sheet{$index}.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>";
    }
    $stylesId = $index + 1;
    $zip->addFromString('[Content_Types].xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
        . '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
        . '<Default Extension="xml" ContentType="application/xml"/>'
        . '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
        . '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
        . $overrides . '</Types>');
    $zip->addFromString('_rels/.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        . '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>');
    $zip->addFromString('xl/workbook.xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
        . "<sheets>{$sheetEntries}</sheets></workbook>");
    $zip->addFromString('xl/_rels/workbook.xml.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' . $relationships
        . "<Relationship Id=\"rId{$stylesId}\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/></Relationships>");
    $zip->addFromString('xl/styles.xml', xlsxStylesXml());
    $zip->close();
    return $path;
}

/** @param array<string, array<string, mixed>> $sheets */
function sendXlsx(string $filename, array $sheets): never
{
    $path = buildXlsxFile($sheets);
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Content-Length: ' . filesize($path));
    readfile($path);
    unlink($path);
    exit;
}
