<?php
declare(strict_types=1);

/**
 * Pairs pre-test and post-test rows by normalized phone number, using each participant's best attempt.
 * @return list<array<string, mixed>>
 */
function buildParticipantRows(): array
{
    $rows = pickBestAttempts(db()->query('SELECT * FROM submissions ORDER BY created_at ASC')->fetchAll());
    usort($rows, static fn (array $left, array $right): int => strcmp($left['created_at'], $right['created_at']));
    $participants = [];
    foreach ($rows as $row) {
        $phone = $row['phone'];
        $participants[$phone] ??= [
            'phone' => $phone, 'name' => $row['name'], 'gender' => $row['gender'],
            'age' => (int) $row['age'], 'kelurahan' => $row['kelurahan'], 'pre' => null, 'post' => null,
        ];
        $participants[$phone][$row['test_type']] = [
            'id' => (int) $row['id'],
            'score' => (int) $row['score'],
            'by_topic' => json_decode($row['by_topic'], true) ?: [],
            'created_at' => $row['created_at'],
            'attempt_count' => $row['attempt_count'],
            'attempt_scores' => $row['attempt_scores'],
        ];
    }
    foreach ($participants as &$participant) {
        $participant['gain'] = ($participant['pre'] && $participant['post'])
            ? calculateNormalizedGain($participant['pre']['score'], $participant['post']['score'])
            : null;
    }
    unset($participant);
    return array_values($participants);
}

/**
 * @param list<array<string, mixed>> $participants
 * @return array<string, mixed>
 */
function summarizeParticipants(array $participants): array
{
    $preScores = [];
    $postScores = [];
    $gains = [];
    $categories = ['Tinggi' => 0, 'Sedang' => 0, 'Rendah' => 0];
    $topicSums = ['pre' => [], 'post' => []];

    foreach ($participants as $participant) {
        foreach (['pre', 'post'] as $type) {
            if (!$participant[$type]) {
                continue;
            }
            if ($type === 'pre') {
                $preScores[] = $participant[$type]['score'];
            } else {
                $postScores[] = $participant[$type]['score'];
            }
            foreach ($participant[$type]['by_topic'] as $topic => $value) {
                $topicSums[$type][$topic][] = (int) $value;
            }
        }
        if ($participant['gain'] !== null) {
            $gains[] = $participant['gain'];
            $categories[categorizeGain($participant['gain'])]++;
        }
    }

    $topicAverages = [];
    foreach (array_keys(TOPICS) as $topic) {
        $topicAverages[$topic] = [
            'pre' => averageOf($topicSums['pre'][$topic] ?? []),
            'post' => averageOf($topicSums['post'][$topic] ?? []),
        ];
    }

    return [
        'pre_count' => count($preScores),
        'post_count' => count($postScores),
        'paired_count' => count($gains),
        'pre_average' => averageOf($preScores),
        'post_average' => averageOf($postScores),
        'gain_average' => $gains ? round(array_sum($gains) / count($gains), 2) : null,
        'categories' => $categories,
        'topics' => $topicAverages,
    ];
}

/** @param list<int|float> $values */
function averageOf(array $values): ?float
{
    if (!$values) {
        return null;
    }
    return round(array_sum($values) / count($values), 1);
}

function formatNumber(?float $value, int $decimals = 1): string
{
    return $value === null ? '-' : number_format($value, $decimals, ',', '.');
}
