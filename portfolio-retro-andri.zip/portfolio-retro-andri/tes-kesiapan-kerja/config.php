<?php
declare(strict_types=1);

/*
 * Local development uses SQLite (no setup needed).
 * On cPanel: set DB_DRIVER to 'mysql' and fill in the MySQL credentials
 * created in cPanel → MySQL Databases.
 */
return [
    'db_driver' => getenv('DB_DRIVER') ?: 'sqlite',
    'sqlite_path' => __DIR__ . '/data/tes.sqlite',
    // Environment variables override these values, which lets the local MySQL test run without editing the file.
    'mysql' => [
        'host' => getenv('DB_HOST') ?: 'localhost',
        'name' => getenv('DB_NAME') ?: 'cpaneluser_tes',
        'user' => getenv('DB_USER') ?: 'cpaneluser_tes',
        'pass' => getenv('DB_PASS') !== false ? (string) getenv('DB_PASS') : 'GANTI_PASSWORD_DATABASE',
    ],
    // Generate with: php -r "echo password_hash('passwordBaru', PASSWORD_DEFAULT);"
    // Local test password below is: kt-4df5f843 — change it before going live.
    'admin_password_hash' => '$2y$10$ffSZTp7J6yn1z32G9ZQPnu9/Q5BMhfT7/tLcz0lZxAl8EehKxOtwG',
];
