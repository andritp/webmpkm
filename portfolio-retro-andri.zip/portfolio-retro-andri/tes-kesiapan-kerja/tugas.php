<?php
declare(strict_types=1);
require __DIR__ . '/inc/bootstrap.php';

const ASSIGNMENT_FILES = ['cv' => 'Curriculum Vitae (CV)', 'letter' => 'Surat lamaran kerja'];

$participant = requireParticipant();
$assignment = findAssignment($participant['phone']);
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $errors = saveAssignment($participant, $assignment);
    if (!$errors) {
        $_SESSION['flash_task'] = 'Tugas tersimpan. Panitia akan menilai hasil praktikmu.';
        redirect('tugas.php');
    }
}
$flash = $_SESSION['flash_task'] ?? '';
unset($_SESSION['flash_task']);
$isGraded = $assignment && ($assignment['score_cv'] !== null || $assignment['score_letter'] !== null || $assignment['score_linkedin'] !== null);

renderHeader('Setor Tugas — ' . APP_TITLE);
?>
<form method="post" enctype="multipart/form-data" class="card task-form">
  <?= csrfField() ?>
  <p class="kicker">Tugas praktik</p>
  <h1 class="page-title">Setor hasil praktik</h1>
  <p class="hint">Kirim link profil LinkedIn, CV, dan surat lamaran yang kamu buat saat pelatihan. Format file: PDF, DOC/DOCX, atau foto (JPG/PNG), maksimal <?= formatFileSize(MAX_UPLOAD_BYTES) ?>. File boleh diganti sampai panitia menilai.</p>
  <?php if ($flash): ?><div class="notice"><?= e($flash) ?></div><?php endif; ?>
  <?php if ($errors): ?><div class="alert"><ul><?php foreach ($errors as $error): ?><li><?= e($error) ?></li><?php endforeach; ?></ul></div><?php endif; ?>

  <label>Link profil LinkedIn
    <input name="linkedin_url" type="url" maxlength="255" value="<?= e($assignment['linkedin_url'] ?? '') ?>" placeholder="https://www.linkedin.com/in/nama-kamu">
  </label>

  <?php foreach (ASSIGNMENT_FILES as $field => $label): $stored = $assignment["{$field}_original"] ?? ''; ?>
    <div class="upload-field">
      <b><?= e($label) ?></b>
      <?php if ($stored !== ''): ?><small class="uploaded">✓ Terkirim: <?= e($stored) ?></small><?php endif; ?>
      <input type="file" name="<?= $field ?>" accept=".<?= implode(',.', ASSIGNMENT_EXTENSIONS) ?>" <?= $isGraded ? 'disabled' : '' ?>>
    </div>
  <?php endforeach; ?>

  <?php if ($isGraded): ?>
    <div class="grade-box">
      <h3>Penilaian panitia</h3>
      <ul>
        <li>CV: <b><?= $assignment['score_cv'] ?? '-' ?></b></li>
        <li>Surat lamaran: <b><?= $assignment['score_letter'] ?? '-' ?></b></li>
        <li>LinkedIn: <b><?= $assignment['score_linkedin'] ?? '-' ?></b> <?= (int) $assignment['linkedin_verified'] === 1 ? '<span class="tag tag-tinggi">Terverifikasi</span>' : '' ?></li>
      </ul>
      <?php if ($assignment['notes'] !== ''): ?><p><b>Catatan:</b> <?= e($assignment['notes']) ?></p><?php endif; ?>
    </div>
  <?php else: ?>
    <button class="btn btn-primary btn-lg" type="submit">Simpan tugas</button>
  <?php endif; ?>
  <p><a href="area.php">← Kembali ke Area Peserta</a></p>
</form>
<?php renderFooter();

/**
 * @param array{phone:string, name:string} $participant
 * @return list<string>
 */
function saveAssignment(array $participant, ?array $assignment): array
{
    if ($assignment && ($assignment['score_cv'] !== null || $assignment['score_letter'] !== null || $assignment['score_linkedin'] !== null)) {
        return ['Tugas sudah dinilai dan tidak bisa diubah lagi.'];
    }
    $errors = [];
    $linkedin = trim((string) ($_POST['linkedin_url'] ?? ''));
    if ($linkedin !== '' && !isValidLinkedinUrl($linkedin)) {
        $errors[] = 'Link LinkedIn tidak valid. Contoh: https://www.linkedin.com/in/nama-kamu';
    }
    $uploads = [];
    foreach (array_keys(ASSIGNMENT_FILES) as $field) {
        $file = $_FILES[$field] ?? ['error' => UPLOAD_ERR_NO_FILE];
        if (($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
            continue;
        }
        $error = validateUploadMeta($file, ASSIGNMENT_EXTENSIONS, MAX_UPLOAD_BYTES);
        if ($error !== null) {
            $errors[] = ASSIGNMENT_FILES[$field] . ': ' . $error;
            continue;
        }
        $uploads[$field] = $file;
    }
    if ($errors) {
        return $errors;
    }
    if ($linkedin === '' && !$uploads && !$assignment) {
        return ['Isi minimal satu: link LinkedIn, CV, atau surat lamaran.'];
    }

    $row = $assignment ?? ['linkedin_url' => '', 'cv_file' => '', 'cv_original' => '', 'letter_file' => '', 'letter_original' => ''];
    $row['linkedin_url'] = $linkedin === '' ? $row['linkedin_url'] : normalizeLinkedinUrl($linkedin);
    foreach ($uploads as $field => $file) {
        try {
            $storedName = storeUpload($file);
        } catch (RuntimeException $exception) {
            error_log('Assignment upload failed: ' . $exception->getMessage());
            return [ASSIGNMENT_FILES[$field] . ': upload gagal disimpan. Coba lagi.'];
        }
        deleteStoredFile($row["{$field}_file"]);
        $row["{$field}_file"] = $storedName;
        $row["{$field}_original"] = mb_substr(basename($file['name']), 0, 200);
    }
    $values = [$row['linkedin_url'], $row['cv_file'], $row['cv_original'], $row['letter_file'], $row['letter_original'], date('Y-m-d H:i:s')];
    if ($assignment) {
        db()->prepare('UPDATE assignments SET linkedin_url = ?, cv_file = ?, cv_original = ?, letter_file = ?, letter_original = ?, updated_at = ? WHERE phone = ?')
            ->execute([...$values, $participant['phone']]);
    } else {
        db()->prepare('INSERT INTO assignments (linkedin_url, cv_file, cv_original, letter_file, letter_original, updated_at, phone, name) VALUES (?, ?, ?, ?, ?, ?, ?, ?)')
            ->execute([...$values, $participant['phone'], $participant['name']]);
    }
    return [];
}
