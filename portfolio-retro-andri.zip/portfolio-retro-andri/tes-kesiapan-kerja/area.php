<?php
declare(strict_types=1);
require __DIR__ . '/inc/bootstrap.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    if (($_POST['action'] ?? '') === 'logout') {
        unset($_SESSION['participant']);
        redirect('area.php');
    }
    $identity = isLoginBlocked('area') ? false : findParticipantIdentity(normalizePhone((string) ($_POST['phone'] ?? '')), (string) ($_POST['name'] ?? ''));
    if ($identity === false) {
        $error = 'Terlalu banyak percobaan masuk. Tunggu 10 menit lalu coba lagi.';
    } elseif ($identity === null) {
        recordLoginFailure('area');
        $error = 'Data tidak ditemukan. Pastikan nama dan nomor WhatsApp sama seperti saat mengerjakan tes.';
    } else {
        clearLoginFailures('area');
        session_regenerate_id(true);
        $_SESSION['participant'] = $identity;
        redirect('area.php');
    }
}

$participant = currentParticipant();
renderHeader('Area Peserta — ' . APP_TITLE);

if ($participant === null): ?>
  <form method="post" class="card login-card">
    <?= csrfField() ?>
    <h1 class="page-title">Area Peserta</h1>
    <p class="hint">Cek nilai, isi kuesioner, unduh sertifikat, dan setor tugas. Masukkan data yang sama seperti saat mengerjakan tes.</p>
    <?php if ($error): ?><div class="alert"><?= e($error) ?></div><?php endif; ?>
    <label>Nama lengkap<input name="name" required maxlength="100" placeholder="Budi Santoso"></label>
    <label>Nomor WhatsApp<input name="phone" required inputmode="tel" maxlength="20" placeholder="0812xxxxxxxx"></label>
    <?= privacyNote() ?>
    <button class="btn btn-primary btn-lg" type="submit">Masuk</button>
  </form>
<?php renderFooter(); exit; endif;

$attempts = participantAttempts($participant['phone']);
$preScore = $attempts['pre'] ? (int) $attempts['pre'][0]['score'] : null;
$postScores = array_map(static fn (array $row): int => (int) $row['score'], $attempts['post']);
$bestPost = $postScores ? max($postScores) : null;
$gain = ($preScore !== null && $bestPost !== null) ? calculateNormalizedGain($preScore, $bestPost) : null;
$survey = findSurvey($participant['phone']);
$assignment = findAssignment($participant['phone']);
$hasPost = $bestPost !== null;
$certificateReady = isEligibleForCertificate($hasPost, $survey !== null);
$reviewReady = canViewReview(count($postScores));
$assignmentDone = $assignment && $assignment['linkedin_url'] !== '' && $assignment['cv_file'] !== '' && $assignment['letter_file'] !== '';

$steps = [
    ['label' => 'Pre-test', 'done' => $preScore !== null, 'href' => 'tes.php?type=pre', 'note' => $preScore !== null ? "Nilai {$preScore}" : 'Belum dikerjakan'],
    ['label' => 'Post-test', 'done' => $hasPost, 'href' => 'tes.php?type=post', 'note' => $hasPost ? "Terbaik {$bestPost} · " . count($postScores) . '/' . maxAttempts('post') . '×' : 'Belum dikerjakan'],
    ['label' => 'Kuesioner kepuasan', 'done' => $survey !== null, 'href' => 'kuesioner.php', 'note' => $survey ? 'Terkirim' : ($hasPost ? 'Isi sekarang' : 'Setelah post-test')],
    ['label' => 'Sertifikat', 'done' => $certificateReady, 'href' => 'sertifikat.php', 'note' => $certificateReady ? 'Siap diunduh' : 'Setelah kuesioner'],
    ['label' => 'Setor tugas praktik', 'done' => (bool) $assignmentDone, 'href' => 'tugas.php', 'note' => $assignmentDone ? 'Lengkap' : 'LinkedIn, CV, surat lamaran'],
];
?>
<section class="area-head card">
  <div>
    <p class="kicker">Area Peserta</p>
    <h1>Halo, <?= e($participant['name']) ?></h1>
    <p class="hint">Selesaikan langkah di bawah untuk mendapatkan sertifikat pelatihan.</p>
  </div>
  <form method="post"><?= csrfField() ?><input type="hidden" name="action" value="logout"><button class="btn" type="submit">Keluar</button></form>
</section>

<section class="score-summary">
  <div class="stat"><small>Pre-test</small><b><?= $preScore ?? '–' ?></b></div>
  <div class="stat"><small>Post-test terbaik</small><b><?= $bestPost ?? '–' ?></b></div>
  <div class="stat accent"><small>Peningkatan (N-gain)</small><b><?= $gain === null ? '–' : number_format($gain, 2, ',', '.') ?></b><em><?= e(categorizeGain($gain)) ?></em></div>
</section>

<section class="card">
  <h3>Langkah kamu</h3>
  <ol class="steps">
    <?php foreach ($steps as $index => $step): ?>
      <li class="<?= $step['done'] ? 'is-done' : '' ?>">
        <span class="step-dot"><?= $step['done'] ? '✓' : $index + 1 ?></span>
        <div><b><?= e($step['label']) ?></b><small><?= e($step['note']) ?></small></div>
        <a class="btn btn-sm" href="<?= $step['href'] ?>"><?= $step['done'] ? 'Lihat' : 'Buka' ?></a>
      </li>
    <?php endforeach; ?>
  </ol>
</section>

<?php if ($postScores): ?>
<section class="card">
  <h3>Riwayat post-test</h3>
  <div class="attempt-strip">
    <?php for ($attempt = 1; $attempt <= maxAttempts('post'); $attempt++): $score = $postScores[$attempt - 1] ?? null; ?>
      <div class="attempt <?= $score === null ? 'is-empty' : '' ?> <?= $score !== null && $score === $bestPost ? 'is-best' : '' ?>">
        <small>Percobaan <?= $attempt ?></small><b><?= $score ?? '–' ?></b>
        <?php if ($score !== null && $score === $bestPost): ?><em>Terbaik</em><?php endif; ?>
      </div>
    <?php endfor; ?>
  </div>
  <p class="center">
    <?php if ($reviewReady): ?>
      <a class="btn btn-primary" href="pembahasan.php">Lihat pembahasan jawaban</a>
    <?php else: ?>
      <span class="hint">Pembahasan jawaban terbuka setelah ketiga kesempatan post-test dipakai.</span>
    <?php endif; ?>
  </p>
</section>
<?php endif; ?>
<?php renderFooter();
