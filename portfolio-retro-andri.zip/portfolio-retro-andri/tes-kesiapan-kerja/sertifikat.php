<?php
declare(strict_types=1);
require __DIR__ . '/inc/bootstrap.php';

const MONTHS_ID = [1 => 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];

$participant = requireParticipant();
$hasPost = (bool) participantAttempts($participant['phone'])['post'];
if (!isEligibleForCertificate($hasPost, findSurvey($participant['phone']) !== null)) {
    renderHeader('Sertifikat — ' . APP_TITLE);
    echo '<div class="notice">Sertifikat tersedia setelah kamu mengerjakan post-test dan mengisi kuesioner kepuasan. <a href="area.php">Kembali ke Area Peserta</a></div>';
    renderFooter();
    exit;
}

$certificate = issueCertificate($participant['phone'], $participant['name']);
$issuedAt = strtotime($certificate['issued_at']);
$issuedDate = date('j', $issuedAt) . ' ' . MONTHS_ID[(int) date('n', $issuedAt)] . ' ' . date('Y', $issuedAt);
$signers = [
    ['name' => getSetting('signer1_name', 'Kurnen') ?: '( ................................ )', 'title' => getSetting('signer1_title', 'Ketua Kelompok 1 MK-PM Universitas Terbuka')],
    ['name' => getSetting('signer2_name', '') ?: '( ................................ )', 'title' => getSetting('signer2_title', 'Ketua Karang Taruna Kecamatan Jatisampurna')],
];
?>
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Sertifikat — <?= e($certificate['name']) ?></title>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@500;600;700;800&family=Great+Vibes&family=Cinzel:wght@600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="<?= e(asset('assets/certificate.css')) ?>">
</head>
<body>
  <div class="cert-toolbar">
    <a href="area.php" class="cert-btn ghost">← Area Peserta</a>
    <span>Pilih <b>Simpan sebagai PDF</b> pada jendela cetak.</span>
    <button type="button" class="cert-btn" onclick="window.print()">Unduh PDF</button>
  </div>

  <div class="cert-viewport" id="cert-viewport">
  <main class="certificate" id="certificate">
    <svg class="cert-wave" viewBox="0 0 400 800" preserveAspectRatio="none" aria-hidden="true">
      <defs>
        <linearGradient id="waveNavy" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stop-color="#2b3c9e"/><stop offset="1" stop-color="#0b1240"/>
        </linearGradient>
        <linearGradient id="waveLight" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stop-color="#5f7be0" stop-opacity=".55"/><stop offset="1" stop-color="#22307f" stop-opacity=".25"/>
        </linearGradient>
      </defs>
      <path d="M400 0 L292 0 C368 160 352 350 296 488 C250 600 150 712 0 800 L400 800 Z" fill="url(#waveLight)"/>
      <path d="M400 0 L330 0 C398 168 384 362 330 500 C284 614 190 720 52 800 L400 800 Z" fill="url(#waveNavy)"/>
      <path d="M312 0 C384 164 368 356 313 494 C267 607 170 716 26 800" fill="none" stroke="#ffc72c" stroke-width="5"/>
    </svg>
    <svg class="cert-wave-small" viewBox="0 0 300 160" preserveAspectRatio="none" aria-hidden="true">
      <path d="M0 160 L0 70 C70 40 150 120 300 160 Z" fill="#141d5c" fill-opacity=".9"/>
      <path d="M0 62 C70 32 150 112 300 154" fill="none" stroke="#ffc72c" stroke-width="4"/>
    </svg>
    <img class="cert-watermark" src="assets/logo-ut.png" alt="" aria-hidden="true">
    <a class="cert-support" href="https://aytindeso.com/" target="_blank" rel="noopener"><span>Supported by</span><img src="assets/logo-aytindeso-light.png" alt="AYTINDESO"></a>

    <section class="cert-content">
      <header class="cert-header">
        <div class="cert-logos">
          <img src="assets/logo-ut.png" alt="Universitas Terbuka">
          <img src="assets/logo-karang-taruna.png" alt="Karang Taruna">
        </div>
      </header>

      <p class="cert-kicker">Program Pemberdayaan Masyarakat</p>
      <h1 class="cert-title">Sertifikat</h1>
      <p class="cert-number">No. <?= e($certificate['number']) ?></p>
      <p class="cert-given">diberikan kepada</p>
      <h2 class="cert-name"><?= e($certificate['name']) ?></h2>
      <p class="cert-desc">
        atas partisipasinya sebagai <b>Peserta</b> dalam
        <b>Program Pelatihan Kesiapan Kerja bagi Pemuda Karang Taruna melalui Pengenalan Dunia Kerja
        di Kecamatan Jatisampurna Kota Bekasi</b>, yang diselenggarakan oleh Kelompok 1 MK-PM
        Universitas Terbuka pada September – Desember 2026.
      </p>
      <p class="cert-date">Bekasi, <?= e($issuedDate) ?></p>

      <footer class="cert-signs">
        <?php foreach ($signers as $signer): ?>
          <div class="cert-sign">
            <small class="sign-role"><?= e($signer['title']) ?></small>
            <div class="sign-space"></div>
            <b><?= e($signer['name']) ?></b>
          </div>
        <?php endforeach; ?>
      </footer>
      <p class="cert-motto">Belajar Bersama, Tumbuh Bersama</p>
    </section>
  </main>
  </div>
  <script>
    // Scales the fixed A4 sheet down to fit narrow screens; printing always uses the real size.
    (function fitCertificate() {
      const sheet = document.getElementById('certificate');
      const viewport = document.getElementById('cert-viewport');
      function fit() {
        const scale = Math.min(1, (window.innerWidth - 16) / (sheet.offsetWidth + 48));
        sheet.style.transform = scale < 1 ? `scale(${scale})` : '';
        sheet.style.transformOrigin = 'top left';
        viewport.style.height = scale < 1 ? `${(sheet.offsetHeight + 48) * scale}px` : '';
        sheet.style.marginLeft = scale < 1 ? '8px' : '';
      }
      window.addEventListener('resize', fit);
      fit();
    })();
  </script>
</body>
</html>
