<?php
declare(strict_types=1);
require __DIR__ . '/inc/bootstrap.php';

const FILE_ICONS = ['pdf' => 'PDF', 'doc' => 'DOC', 'docx' => 'DOC', 'ppt' => 'PPT', 'pptx' => 'PPT', 'xls' => 'XLS', 'xlsx' => 'XLS', 'jpg' => 'IMG', 'jpeg' => 'IMG', 'png' => 'IMG', 'zip' => 'ZIP'];

if (isset($_GET['unduh'])) {
    $statement = db()->prepare('SELECT * FROM materials WHERE id = ?');
    $statement->execute([(int) $_GET['unduh']]);
    $material = $statement->fetch();
    if (!$material) {
        http_response_code(404);
        exit('Materi tidak ditemukan.');
    }
    db()->prepare('UPDATE materials SET download_count = download_count + 1 WHERE id = ?')->execute([$material['id']]);
    sendStoredFile($material['stored_name'], $material['original_name']);
}

$materials = db()->query('SELECT * FROM materials ORDER BY id DESC')->fetchAll();
renderHeader('Materi — ' . APP_TITLE);
?>
<section class="hero hero-sm">
  <p class="kicker">Pusat materi</p>
  <h1>Bekal <span class="hl">Menuju Dunia Kerja</span></h1>
  <p class="lead">Unduh buku saku, template CV, template surat lamaran, dan panduan LinkedIn dari pelatihan.</p>
</section>

<?php if (!$materials): ?>
  <div class="card center"><p class="hint">Materi akan segera diunggah oleh panitia.</p></div>
<?php else: ?>
  <section class="material-grid">
    <?php foreach ($materials as $material): $extension = fileExtension($material['original_name']); ?>
      <article class="material-card">
        <span class="file-badge file-<?= e(strtolower(FILE_ICONS[$extension] ?? 'FILE')) ?>"><?= e(FILE_ICONS[$extension] ?? 'FILE') ?></span>
        <div class="material-body">
          <h3><?= e($material['title']) ?></h3>
          <?php if ($material['description'] !== ''): ?><p><?= e($material['description']) ?></p><?php endif; ?>
          <small><?= e(formatFileSize((int) $material['size'])) ?> · <?= (int) $material['download_count'] ?>× diunduh</small>
        </div>
        <a class="btn btn-primary btn-sm" href="materi.php?unduh=<?= (int) $material['id'] ?>">Unduh</a>
      </article>
    <?php endforeach; ?>
  </section>
<?php endif; ?>
<?php renderFooter();
