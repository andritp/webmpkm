<?php
declare(strict_types=1);
require __DIR__ . '/inc/bootstrap.php';

$participant = requireParticipant();
$attempts = participantAttempts($participant['phone'])['post'];
if (!canViewReview(count($attempts))) {
    redirect('area.php');
}

$best = pickBestAttempts($attempts)[0];
$answers = array_map('strval', json_decode($best['answers'], true) ?: []);
$questions = array_values(array_filter(getAllQuestions(), static fn (array $question): bool => isset($answers[$question['id']])));
$wrongCount = count(array_filter($questions, static fn (array $question): bool => $answers[$question['id']] !== $question['answer']));

renderHeader('Pembahasan — ' . APP_TITLE);
?>
<section class="card">
  <p class="kicker">Pembahasan post-test</p>
  <h1 class="page-title">Percobaan terbaik: nilai <?= (int) $best['score'] ?></h1>
  <p class="hint"><?= count($questions) - $wrongCount ?> benar, <?= $wrongCount ?> salah. Pelajari kembali soal yang salah agar makin siap kerja.</p>
  <div class="review-filter">
    <label class="chip"><input type="checkbox" id="only-wrong"> Tampilkan yang salah saja</label>
  </div>
</section>

<?php foreach ($questions as $index => $question):
    $chosen = $answers[$question['id']];
    $isCorrect = $chosen === $question['answer'];
?>
  <article class="card review-item <?= $isCorrect ? 'is-correct' : 'is-wrong' ?>">
    <div class="review-head">
      <span class="q-num"><?= $index + 1 ?></span>
      <small><?= e(TOPICS[$question['topic']] ?? '') ?></small>
      <span class="tag <?= $isCorrect ? 'tag-tinggi' : 'tag-rendah' ?>"><?= $isCorrect ? 'Benar' : 'Salah' ?></span>
    </div>
    <p class="q-text"><?= e($question['text']) ?></p>
    <ul class="review-options">
      <?php foreach ($question['options'] as $key => $option):
          $classes = [];
          if ($key === $question['answer']) { $classes[] = 'is-key'; }
          if ($key === $chosen && !$isCorrect) { $classes[] = 'is-chosen-wrong'; }
      ?>
        <li class="<?= implode(' ', $classes) ?>">
          <?= e($option) ?>
          <?php if ($key === $question['answer']): ?><em>Jawaban benar</em><?php elseif ($key === $chosen): ?><em>Jawaban kamu</em><?php endif; ?>
        </li>
      <?php endforeach; ?>
    </ul>
  </article>
<?php endforeach; ?>

<p class="center"><a class="btn" href="area.php">← Kembali ke Area Peserta</a></p>
<script>
document.getElementById('only-wrong').addEventListener('change', (event) => {
  document.querySelectorAll('.review-item.is-correct').forEach((item) => { item.hidden = event.target.checked; });
});
</script>
<?php renderFooter();
