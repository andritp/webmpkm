<?php
declare(strict_types=1);
require __DIR__ . '/inc/bootstrap.php';

const ATTENDANCE_REDIRECT_SECONDS = 5;

$openSessions = db()->query('SELECT * FROM attendance_sessions WHERE is_open = 1 ORDER BY session_date, id')->fetchAll();
$errors = [];
$success = $_SESSION['flash_attendance'] ?? null;
unset($_SESSION['flash_attendance']);
$participant = currentParticipant();
$old = ['name' => $participant['name'] ?? '', 'phone' => $participant['phone'] ?? '', 'kelurahan' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $old = ['name' => trim((string) ($_POST['name'] ?? '')), 'phone' => trim((string) ($_POST['phone'] ?? '')), 'kelurahan' => trim((string) ($_POST['kelurahan'] ?? ''))];
    $sessionId = (int) ($_POST['session_id'] ?? 0);
    $phone = normalizePhone($old['phone']);
    $openIds = array_map(static fn (array $session): int => (int) $session['id'], $openSessions);

    if (!in_array($sessionId, $openIds, true)) {
        $errors[] = 'Sesi tidak tersedia atau sudah ditutup.';
    }
    if ($old['name'] === '' || mb_strlen($old['name']) > 100) {
        $errors[] = 'Nama lengkap wajib diisi.';
    }
    if (strlen($phone) < 10) {
        $errors[] = 'Nomor WhatsApp tidak valid.';
    }
    if ($old['kelurahan'] === '') {
        $errors[] = 'Kelurahan wajib diisi.';
    }
    if (!$errors) {
        $existing = db()->prepare('SELECT 1 FROM attendance WHERE session_id = ? AND phone = ?');
        $existing->execute([$sessionId, $phone]);
        if ($existing->fetchColumn()) {
            $errors[] = 'Kamu sudah tercatat hadir di sesi ini.';
        }
    }
    if (!$errors) {
        db()->prepare('INSERT INTO attendance (session_id, phone, name, kelurahan, created_at) VALUES (?, ?, ?, ?, ?)')
            ->execute([$sessionId, $phone, $old['name'], mb_substr($old['kelurahan'], 0, 60), date('Y-m-d H:i:s')]);
        $_SESSION['flash_attendance'] = ['name' => $old['name']] + attendanceNextStep($phone, $old['name']);
        redirect('hadir.php');
    }
}

renderHeader('Daftar Hadir — ' . APP_TITLE);
?>
<form method="post" class="card login-card">
  <?= csrfField() ?>
  <p class="kicker">Daftar hadir digital</p>
  <h1 class="page-title">Isi daftar hadir</h1>
  <?php if ($errors): ?><div class="alert"><ul><?php foreach ($errors as $error): ?><li><?= e($error) ?></li><?php endforeach; ?></ul></div><?php endif; ?>

  <?php if (!$openSessions): ?>
    <p class="hint">Belum ada sesi yang dibuka. Daftar hadir akan dibuka panitia saat kegiatan berlangsung.</p>
  <?php else: ?>
    <fieldset class="session-pick">
      <legend>Pilih sesi</legend>
      <?php foreach ($openSessions as $index => $session): ?>
        <label class="option">
          <input type="radio" name="session_id" value="<?= (int) $session['id'] ?>" required <?= $index === 0 ? 'checked' : '' ?>>
          <span class="opt-letter"><?= $index + 1 ?></span>
          <span><b><?= e($session['title']) ?></b><br><small><?= e($session['session_date']) ?></small></span>
        </label>
      <?php endforeach; ?>
    </fieldset>
    <label>Nama lengkap<input name="name" required maxlength="100" value="<?= e($old['name']) ?>" placeholder="Budi Santoso"></label>
    <label>Nomor WhatsApp<input name="phone" required inputmode="tel" maxlength="20" value="<?= e($old['phone']) ?>" placeholder="0812xxxxxxxx"></label>
    <label>Kelurahan<input name="kelurahan" required maxlength="60" value="<?= e($old['kelurahan']) ?>" placeholder="Jatisampurna"></label>
    <?= privacyNote() ?>
    <button class="btn btn-primary btn-lg" type="submit">Saya hadir</button>
  <?php endif; ?>
</form>
<?php if ($success): ?>
  <div class="overlay" id="attendance-success">
    <div class="modal success-modal" role="dialog" aria-modal="true" aria-labelledby="success-title">
      <div class="success-check"><svg viewBox="0 0 52 52" aria-hidden="true"><circle cx="26" cy="26" r="24"/><path d="M15 27l7 7 15-15"/></svg></div>
      <h2 id="success-title">Kehadiranmu berhasil tersimpan</h2>
      <p class="modal-name">Terima kasih, <b><?= e($success['name']) ?></b>!</p>
      <p class="hint">Sistem akan melanjutkan ke <b><?= e($success['label']) ?></b> dalam <b id="redirect-seconds"><?= ATTENDANCE_REDIRECT_SECONDS ?></b> detik…</p>
      <div class="redirect-bar"><span style="animation-duration: <?= ATTENDANCE_REDIRECT_SECONDS ?>s"></span></div>
      <div class="modal-actions">
        <a class="btn btn-primary btn-lg" id="redirect-now" href="<?= e($success['href']) ?>">Lanjut ke <?= e($success['label']) ?> →</a>
      </div>
    </div>
  </div>
  <script>
    (function redirectAfterAttendance() {
      const target = document.getElementById('redirect-now').href;
      const counter = document.getElementById('redirect-seconds');
      let remaining = <?= ATTENDANCE_REDIRECT_SECONDS ?>;
      const timer = setInterval(() => {
        remaining--;
        counter.textContent = String(Math.max(remaining, 0));
        if (remaining > 0) return;
        clearInterval(timer);
        window.location.href = target;
      }, 1000);
    })();
  </script>
<?php endif; ?>
<?php renderFooter();

/**
 * Participants who already took a test are signed in and sent to Area Peserta;
 * new participants are sent to the pre-test instead, since Area Peserta needs a test record.
 * @return array{href:string, label:string}
 */
function attendanceNextStep(string $phone, string $name): array
{
    $identity = findParticipantIdentity($phone, $name);
    if ($identity !== null) {
        session_regenerate_id(true);
        $_SESSION['participant'] = $identity;
        return ['href' => 'area.php', 'label' => 'Area Peserta'];
    }
    if (isTestOpen('pre')) {
        // One-shot prefill: consumed by the next tes.php load, so it does not linger on shared devices.
        $_SESSION['form_old'] = ['name' => $name, 'phone' => $phone, 'kelurahan' => trim((string) ($_POST['kelurahan'] ?? ''))];
        return ['href' => 'tes.php?type=pre', 'label' => 'Pre-test'];
    }
    return ['href' => 'index.php', 'label' => 'Beranda'];
}