<?php
declare(strict_types=1);
require __DIR__ . '/inc/bootstrap.php';

header('Content-Type: application/json; charset=utf-8');

/** @param array<string, mixed>|null $data */
function respond(bool $success, ?array $data = null, ?string $error = null, int $status = 200): never
{
    http_response_code($status);
    echo json_encode(array_filter(
        ['success' => $success, 'data' => $data, 'error' => $error],
        static fn ($value) => $value !== null
    ));
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respond(false, null, 'Metode tidak diizinkan.', 405);
}
if (!hash_equals(csrfToken(), (string) ($_POST['csrf'] ?? ''))) {
    respond(false, null, 'Sesi tidak valid. Muat ulang halaman.', 400);
}

$testType = (string) ($_POST['type'] ?? '');
if (!array_key_exists($testType, TEST_TYPES) || !isTestOpen($testType)) {
    respond(false, null, 'Tes belum dibuka oleh panitia.', 403);
}

// Called when the participant presses MULAI. Keeps the first start time so reloading the page cannot reset the timer.
if (($_POST['action'] ?? '') === 'start') {
    $_SESSION['test_started'][$testType] ??= time();
    $durationSeconds = testDurationMinutes() * 60;
    $elapsed = time() - $_SESSION['test_started'][$testType];
    respond(true, [
        'durationMinutes' => testDurationMinutes(),
        'remainingSeconds' => $durationSeconds > 0 ? max(0, $durationSeconds - $elapsed) : null,
    ]);
}

$phone = normalizePhone((string) ($_POST['phone'] ?? ''));
if ($phone === '') {
    respond(false, null, 'Nomor WhatsApp tidak valid.', 422);
}

$attemptsUsed = countAttempts($phone, $testType);
$remaining = remainingAttempts($testType, $attemptsUsed);
respond(true, [
    'attemptsUsed' => $attemptsUsed,
    'maxAttempts' => maxAttempts($testType),
    'remaining' => $remaining,
    'alreadySubmitted' => $remaining === 0,
    'message' => $remaining === 0 ? attemptsExhaustedMessage($testType) : null,
]);
