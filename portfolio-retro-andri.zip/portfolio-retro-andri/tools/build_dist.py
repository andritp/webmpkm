"""Builds dist/siapkerja.zip: the web app without local data, tests or dev files, configured for MySQL."""
import os
import re
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SOURCE = os.path.join(ROOT, "tes-kesiapan-kerja")
OUTPUT = os.path.join(ROOT, "dist", "siapkerja.zip")
SKIP_TOP_LEVEL = {".claude", ".omc", "data", "tests"}


def production_config(text: str) -> str:
    text = text.replace("'db_driver' => getenv('DB_DRIVER') ?: 'sqlite',", "'db_driver' => getenv('DB_DRIVER') ?: 'mysql',")
    text = text.replace("getenv('DB_NAME') ?: 'cpaneluser_tes'", "getenv('DB_NAME') ?: 'aytindes_siapkerja'")
    text = text.replace("getenv('DB_USER') ?: 'cpaneluser_tes'", "getenv('DB_USER') ?: 'aytindes_siapkerja'")
    text = re.sub(r"    // Local test password below is: .*\n",
                  "    // Temporary admin password: same as the local test password. Change it right after the first login (Pengaturan).\n", text)
    return text.replace("Local development uses SQLite (no setup needed).", "Production package: MySQL. Fill in the database password below.")


def main() -> None:
    os.makedirs(os.path.dirname(OUTPUT), exist_ok=True)
    count = 0
    with zipfile.ZipFile(OUTPUT, "w", zipfile.ZIP_DEFLATED) as archive:
        for folder, subfolders, files in os.walk(SOURCE):
            relative_folder = os.path.relpath(folder, SOURCE).replace("\\", "/")
            if relative_folder.split("/")[0] in SKIP_TOP_LEVEL:
                subfolders[:] = []
                continue
            for name in files:
                relative = name if relative_folder == "." else f"{relative_folder}/{name}"
                if relative.startswith("uploads/") and name != ".htaccess":
                    continue
                with open(os.path.join(folder, name), "rb") as handle:
                    data = handle.read()
                if relative == "config.php":
                    data = production_config(data.decode("utf-8")).encode("utf-8")
                archive.writestr(relative, data)
                count += 1
    print(f"{OUTPUT}: {count} files")


if __name__ == "__main__":
    main()
