'use strict';

const TYPING_DELAY_MS = 32;
const BOOT_LINE_DELAY_MS = 140;
const SKILL_TICK_MS = 70;
const SKILL_BAR_WIDTH = 10;
const PREFERS_REDUCED_MOTION = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

const BOOT_LINES = [
  'ANDRI-BIOS v2.0  (c) 1986-2026',
  'CPU: HUMAN-02 @ 07.01.2002 ........ OK',
  'MEMORY TEST: 640K ................. OK',
  'LOADING sains_data.sys ............ OK',
  'LOADING network_admin.drv ......... OK',
  'MOUNTING portfolio.dat ............ OK',
  '',
  'BOOTING DATA_LAB.EXE...',
];

const TERMINAL_LINES = [
  { text: 'C:\\> whoami', cls: 'dim' },
  { text: 'ANDRI_', cls: 'big' },
  { text: 'DATA SCIENCE STUDENT' },
  { text: '// WEB DEV // NETWORK ADMIN' },
  { text: '> loading profile... [##########] 100%', cls: 'dim' },
  { text: '> cert: BNSP Junior Network Admin', cls: 'dim' },
  { text: '> status: OPEN TO WORK', cls: 'dim' },
];

const TIMELINE = [
  { year: '2017', label: 'Masuk SMK KGB 2 — Teknik Komputer dan Jaringan', type: 'edu' },
  { year: '2019', label: 'PKL Teknisi — PT Lintas Jaringan Nusantara', type: 'work' },
  { year: '2020', label: 'Lulus SMK (nilai 82) + Sertifikasi BNSP', type: 'edu' },
  { year: '2020', label: 'IT Support — TJS (Mikrotik, CCTV)', type: 'work' },
  { year: '2020', label: 'Launch aytindeso.com', type: 'work' },
  { year: '2021', label: "Crew — McDonald's", type: 'work' },
  { year: '2022', label: "Store Junior Leader — McDonald's", type: 'work' },
  { year: '2024', label: 'Kuliah Sains Data — Universitas Terbuka', type: 'edu' },
  { year: '2026', label: 'Website OSIS SMK KGB 2', type: 'work' },
];

const COMPETENCY_SCORES = [
  { key: 'U1', score: 90, name: 'Spesifikasi jaringan nirkabel' },
  { key: 'U2', score: 90, name: 'Memasang jaringan nirkabel' },
  { key: 'U3', score: 90, name: 'Merancang topologi jaringan' },
  { key: 'U4', score: 90, name: 'Merancang pengalamatan jaringan' },
  { key: 'U5', score: 90, name: 'Konfigurasi switch' },
  { key: 'U6', score: 80, name: 'Memasang perangkat jaringan' },
  { key: 'U7', score: 80, name: 'Konfigurasi routing (satu AS)' },
  { key: 'U8', score: 90, name: 'Keamanan dan akun pengguna' },
  { key: 'U9', score: 90, name: 'Mengganti perangkat jaringan' },
];
const COMPETENCY_AXIS_MIN = 50;
const COMPETENCY_AXIS_MAX = 100;

const ARTICLE_CATEGORIES = [
  { name: 'Artikel IT', count: 9 },
  { name: 'Source Code', count: 7 },
  { name: 'Pemrograman', count: 2 },
  { name: 'Cisco', count: 2 },
  { name: 'Mikrotik', count: 1 },
  { name: 'Bahasa C', count: 1 },
  { name: 'Info Karir', count: 1 },
];

const OSIS_SEKBID = [
  'Ketuhanan', 'Nasionalisme', 'Kepemimpinan', 'Wirausaha', 'Jasmani',
  'Seni', 'Lingkungan', 'TIK', 'Humas', 'Organisasi',
];

const SKILLS = [
  { name: 'NETWORKING', level: 90 },
  { name: 'MS OFFICE ', level: 90 },
  { name: 'WEB DEV   ', level: 75 },
  { name: 'MYSQL     ', level: 70 },
  { name: 'PYTHON    ', level: 50 },
  { name: 'DATA ANLYS', level: 50 },
];

const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

function escapeHtml(text) {
  return text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

async function runBootScreen() {
  const bootElement = document.getElementById('boot');
  const bootText = document.getElementById('boot-text');
  if (PREFERS_REDUCED_MOTION || sessionStorageGet('booted')) {
    bootElement.remove();
    return;
  }
  for (const line of BOOT_LINES) {
    bootText.textContent += line + '\n';
    await wait(BOOT_LINE_DELAY_MS);
  }
  await wait(400);
  bootElement.classList.add('done');
  sessionStorageSet('booted', '1');
  setTimeout(() => bootElement.remove(), 600);
}

function sessionStorageGet(key) {
  try { return sessionStorage.getItem(key); } catch (error) { console.warn('sessionStorage read failed', error); return null; }
}

function sessionStorageSet(key, value) {
  try { sessionStorage.setItem(key, value); } catch (error) { console.warn('sessionStorage write failed', error); }
}

function renderTerminalLines(lines, visibleChars) {
  let remaining = visibleChars;
  const html = [];
  for (const line of lines) {
    if (remaining <= 0) break;
    const shown = line.text.slice(0, remaining);
    remaining -= line.text.length + 1;
    html.push(`<div class="${line.cls || ''}">${escapeHtml(shown) || '&nbsp;'}</div>`);
  }
  return html.join('');
}

async function typeTerminal() {
  const terminal = document.getElementById('terminal');
  const totalChars = TERMINAL_LINES.reduce((sum, line) => sum + line.text.length + 1, 0);
  const cursor = '<span class="cursor"></span>';
  if (PREFERS_REDUCED_MOTION) {
    terminal.innerHTML = renderTerminalLines(TERMINAL_LINES, totalChars) + cursor;
    return;
  }
  for (let visible = 0; visible <= totalChars; visible++) {
    terminal.innerHTML = renderTerminalLines(TERMINAL_LINES, visible) + cursor;
    await wait(TYPING_DELAY_MS);
  }
}

function renderTimeline() {
  const list = document.getElementById('timeline');
  list.innerHTML = TIMELINE.map((item) =>
    `<li class="${item.type}"><b>${item.year}</b> ${escapeHtml(item.label)}</li>`
  ).join('');
}

function renderCompetencyChart() {
  const chart = document.getElementById('competency-chart');
  const range = COMPETENCY_AXIS_MAX - COMPETENCY_AXIS_MIN;
  chart.innerHTML = COMPETENCY_SCORES.map((unit, index) => {
    const heightPercent = ((unit.score - COMPETENCY_AXIS_MIN) / range) * 100;
    const lowClass = unit.score < COMPETENCY_AXIS_MAX - 10 ? ' low' : '';
    return `<div class="bar-col" title="${escapeHtml(unit.name)}: ${unit.score}">
      <span class="bar-val">${unit.score}</span>
      <div class="bar${lowClass}" style="height:${heightPercent}%;transition-delay:${index * 80}ms"></div>
      <span class="bar-key">${unit.key}</span>
    </div>`;
  }).join('');
}

function renderCategoryChart() {
  const chart = document.getElementById('category-chart');
  const maxCount = Math.max(...ARTICLE_CATEGORIES.map((category) => category.count));
  chart.innerHTML = ARTICLE_CATEGORIES.map((category, index) => {
    const widthPercent = (category.count / maxCount) * 100;
    return `<span>${escapeHtml(category.name)}</span>
      <div class="hbar-track"><div class="hbar" style="width:${widthPercent}%;transition-delay:${index * 90}ms"></div></div>
      <b>${category.count}</b>`;
  }).join('');
}

function renderSekbidChart() {
  const chart = document.getElementById('sekbid-chart');
  chart.innerHTML = OSIS_SEKBID.map((name, index) =>
    `<div class="dot-cell" style="transition-delay:${index * 70}ms"><b>${String(index + 1).padStart(2, '0')}</b>${escapeHtml(name)}</div>`
  ).join('');
}

function formatSkillBar(level, filledBlocks) {
  const targetBlocks = Math.round(level / SKILL_BAR_WIDTH);
  const bar = '█'.repeat(filledBlocks) + '░'.repeat(SKILL_BAR_WIDTH - filledBlocks);
  const percent = filledBlocks >= targetBlocks ? level : filledBlocks * SKILL_BAR_WIDTH;
  return `[${bar}] ${String(percent).padStart(3)}%`;
}

function animateSkills() {
  const list = document.getElementById('skill-list');
  list.innerHTML = SKILLS.map((skill, index) =>
    `<li><span>${escapeHtml(skill.name)}</span><span id="skill-${index}">${formatSkillBar(skill.level, 0)}</span></li>`
  ).join('');
  SKILLS.forEach((skill, index) => {
    const target = document.getElementById(`skill-${index}`);
    const targetBlocks = Math.round(skill.level / SKILL_BAR_WIDTH);
    if (PREFERS_REDUCED_MOTION) {
      target.textContent = formatSkillBar(skill.level, targetBlocks);
      return;
    }
    let filled = 0;
    const timer = setInterval(() => {
      filled++;
      target.textContent = formatSkillBar(skill.level, filled);
      if (filled >= targetBlocks) clearInterval(timer);
    }, SKILL_TICK_MS);
  });
}

function observeReveals() {
  const sections = document.querySelectorAll('.reveal');
  const onReveal = (section) => {
    section.classList.add('in-view');
    if (section.id === 'skills') animateSkills();
  };
  if (!('IntersectionObserver' in window)) {
    sections.forEach(onReveal);
    return;
  }
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (!entry.isIntersecting) return;
      onReveal(entry.target);
      observer.unobserve(entry.target);
    });
  }, { threshold: 0.2 });
  sections.forEach((section) => observer.observe(section));
}

async function init() {
  document.getElementById('year').textContent = String(new Date().getFullYear());
  renderTimeline();
  renderCompetencyChart();
  renderCategoryChart();
  renderSekbidChart();
  await runBootScreen();
  observeReveals();
  await typeTerminal();
}

init().catch((error) => console.error('Failed to initialize portfolio', error));
